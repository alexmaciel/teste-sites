import {
  TranslateModule,
  TranslateService
} from "./chunk-B2NWSZPO.js";
import {
  ActivatedRoute,
  NavigationCancel,
  NavigationStart,
  PRIMARY_OUTLET,
  ROUTES,
  RouteReuseStrategy,
  Router,
  RouterModule,
  ɵEmptyOutletComponent
} from "./chunk-V4VXQCYH.js";
import {
  HttpParams
} from "./chunk-QFNOSN6A.js";
import {
  CommonModule,
  Location,
  isPlatformBrowser
} from "./chunk-26O3BCNQ.js";
import {
  APP_INITIALIZER,
  ChangeDetectorRef,
  Compiler,
  Inject,
  Injectable,
  InjectionToken,
  Injector,
  NgModule,
  NgModuleFactory$1,
  Optional,
  PLATFORM_ID,
  Pipe,
  SkipSelf,
  inject,
  setClassMetadata,
  ɵɵdefineInjectable,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdefinePipe,
  ɵɵdirectiveInject,
  ɵɵgetInheritedFactory,
  ɵɵinject
} from "./chunk-5BURAC2Z.js";
import {
  firstValueFrom,
  isObservable
} from "./chunk-EC6BZIDR.js";
import {
  ConnectableObservable,
  Observable,
  ReplaySubject,
  Subject,
  filter,
  finalize,
  from,
  map,
  mergeMap,
  of,
  pairwise,
  refCount
} from "./chunk-CJ77FWBK.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-KZQQXEH6.js";

// node_modules/@gilsdav/ngx-translate-router/fesm2022/gilsdav-ngx-translate-router.mjs
var LOCALIZE_ROUTER_FORROOT_GUARD = new InjectionToken("LOCALIZE_ROUTER_FORROOT_GUARD");
var RAW_ROUTES = new InjectionToken("RAW_ROUTES");
var CacheMechanism;
(function(CacheMechanism2) {
  CacheMechanism2["LocalStorage"] = "LocalStorage";
  CacheMechanism2["SessionStorage"] = "SessionStorage";
  CacheMechanism2["Cookie"] = "Cookie";
})(CacheMechanism || (CacheMechanism = {}));
var USE_CACHED_LANG = new InjectionToken("USE_CACHED_LANG");
var CACHE_MECHANISM = new InjectionToken("CACHE_MECHANISM");
var CACHE_NAME = new InjectionToken("CACHE_NAME");
var COOKIE_FORMAT = new InjectionToken("COOKIE_FORMAT");
var INITIAL_NAVIGATION = new InjectionToken("INITIAL_NAVIGATION");
var DEFAULT_LANG_FUNCTION = new InjectionToken("DEFAULT_LANG_FUNCTION");
var ALWAYS_SET_PREFIX = new InjectionToken("ALWAYS_SET_PREFIX");
var LOCALIZE_CACHE_NAME = "LOCALIZE_DEFAULT_LANGUAGE";
var DEFAULT_COOKIE_FORMAT = "{{value}};{{expires}}";
var DEFAULT_INITIAL_NAVIGATION = false;
var LocalizeRouterSettings = class _LocalizeRouterSettings {
  /**
   * Settings for localize router
   */
  constructor(useCachedLang = true, alwaysSetPrefix = true, cacheMechanism = CacheMechanism.LocalStorage, cacheName = LOCALIZE_CACHE_NAME, defaultLangFunction = void 0, cookieFormat = DEFAULT_COOKIE_FORMAT, initialNavigation = DEFAULT_INITIAL_NAVIGATION) {
    this.useCachedLang = useCachedLang;
    this.alwaysSetPrefix = alwaysSetPrefix;
    this.cacheName = cacheName;
    this.cookieFormat = cookieFormat;
    this.initialNavigation = initialNavigation;
    this.cacheMechanism = cacheMechanism;
    this.defaultLangFunction = defaultLangFunction;
  }
  static {
    this.ɵfac = function LocalizeRouterSettings_Factory(t) {
      return new (t || _LocalizeRouterSettings)(ɵɵinject(USE_CACHED_LANG), ɵɵinject(ALWAYS_SET_PREFIX), ɵɵinject(CACHE_MECHANISM), ɵɵinject(CACHE_NAME), ɵɵinject(DEFAULT_LANG_FUNCTION), ɵɵinject(COOKIE_FORMAT), ɵɵinject(INITIAL_NAVIGATION));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _LocalizeRouterSettings,
      factory: _LocalizeRouterSettings.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LocalizeRouterSettings, [{
    type: Injectable
  }], () => [{
    type: void 0,
    decorators: [{
      type: Inject,
      args: [USE_CACHED_LANG]
    }]
  }, {
    type: void 0,
    decorators: [{
      type: Inject,
      args: [ALWAYS_SET_PREFIX]
    }]
  }, {
    type: void 0,
    decorators: [{
      type: Inject,
      args: [CACHE_MECHANISM]
    }]
  }, {
    type: void 0,
    decorators: [{
      type: Inject,
      args: [CACHE_NAME]
    }]
  }, {
    type: void 0,
    decorators: [{
      type: Inject,
      args: [DEFAULT_LANG_FUNCTION]
    }]
  }, {
    type: void 0,
    decorators: [{
      type: Inject,
      args: [COOKIE_FORMAT]
    }]
  }, {
    type: void 0,
    decorators: [{
      type: Inject,
      args: [INITIAL_NAVIGATION]
    }]
  }], null);
})();
var COOKIE_EXPIRY = 30;
var LocalizeParser = class _LocalizeParser {
  /**
   * Loader constructor
   */
  constructor(translate, location, settings) {
    this.translate = translate;
    this.location = location;
    this.settings = settings;
  }
  /**
  * Prepare routes to be fully usable by ngx-translate-router
  * @param routes
  */
  /* private initRoutes(routes: Routes, prefix = '') {
    routes.forEach(route => {
      if (route.path !== '**') {
        const routeData: any = route.data = route.data || {};
        routeData.localizeRouter = {};
        routeData.localizeRouter.fullPath = `${prefix}/${route.path}`;
        if (route.children && route.children.length > 0) {
          this.initRoutes(route.children, routeData.localizeRouter.fullPath);
        }
      }
    });
  } */
  /**
   * Initialize language and routes
   */
  init(routes) {
    let selectedLanguage;
    this.routes = routes;
    if (!this.locales || !this.locales.length) {
      return Promise.resolve();
    }
    const locationLang = this.getLocationLang();
    const browserLang = this._getBrowserLang();
    if (this.settings.defaultLangFunction) {
      this.defaultLang = this.settings.defaultLangFunction(this.locales, this._cachedLang, browserLang);
    } else {
      this.defaultLang = this._cachedLang || browserLang || this.locales[0];
    }
    selectedLanguage = locationLang || this.defaultLang;
    this.translate.setDefaultLang(this.defaultLang);
    let children = [];
    if (this.settings.alwaysSetPrefix) {
      const baseRoute = {
        path: "",
        redirectTo: this.defaultLang,
        pathMatch: "full"
      };
      const wildcardIndex = routes.findIndex((route) => route.path === "**");
      if (wildcardIndex !== -1) {
        this._wildcardRoute = routes.splice(wildcardIndex, 1)[0];
      }
      children = this.routes.splice(0, this.routes.length, baseRoute);
    } else {
      children = [...this.routes];
    }
    for (let i = children.length - 1; i >= 0; i--) {
      if (children[i].data && children[i].data["skipRouteLocalization"]) {
        if (this.settings.alwaysSetPrefix) {
          this.routes.push(children[i]);
        }
        if (children[i].redirectTo === void 0 || !children[i].data["skipRouteLocalization"]["localizeRedirectTo"] || typeof children[i].redirectTo === "function") {
          children.splice(i, 1);
        }
      }
    }
    if (children && children.length) {
      if (this.locales.length > 1 || this.settings.alwaysSetPrefix) {
        this._languageRoute = {
          children
        };
        this.routes.unshift(this._languageRoute);
      }
    }
    if (this._wildcardRoute && this.settings.alwaysSetPrefix) {
      this.routes.push(this._wildcardRoute);
    }
    return firstValueFrom(this.translateRoutes(selectedLanguage));
  }
  initChildRoutes(routes) {
    this._translateRouteTree(routes);
    return routes;
  }
  /**
   * Translate routes to selected language
   */
  translateRoutes(language) {
    return new Observable((observer) => {
      this._cachedLang = language;
      if (this._languageRoute) {
        this._languageRoute.path = language;
      }
      this.translate.use(language).subscribe((translations) => {
        this._translationObject = translations;
        this.currentLang = language;
        if (this._languageRoute) {
          this._translateRouteTree(this._languageRoute.children, true);
          if (this._wildcardRoute && this._wildcardRoute.redirectTo) {
            this._translateProperty(this._wildcardRoute, "redirectTo", true);
          }
        } else {
          this._translateRouteTree(this.routes, true);
        }
        observer.next(void 0);
        observer.complete();
      });
    });
  }
  /**
   * Translate the route node and recursively call for all it's children
   */
  _translateRouteTree(routes, isRootTree) {
    routes.forEach((route) => {
      const skipRouteLocalization = route.data && route.data["skipRouteLocalization"];
      const localizeRedirection = !skipRouteLocalization || skipRouteLocalization["localizeRedirectTo"];
      if (route.redirectTo && localizeRedirection && !(typeof route.redirectTo === "function")) {
        const prefixLang = route.redirectTo.indexOf("/") === 0 || isRootTree;
        this._translateProperty(route, "redirectTo", prefixLang);
      }
      if (skipRouteLocalization) {
        return;
      }
      if (route.path !== null && route.path !== void 0) {
        this._translateProperty(route, "path");
      }
      if (route.children) {
        this._translateRouteTree(route.children);
      }
      if (route.loadChildren && route._loadedRoutes?.length) {
        this._translateRouteTree(route._loadedRoutes);
      }
    });
  }
  /**
   * Translate property
   * If first time translation then add original to route data object
   */
  _translateProperty(route, property, prefixLang) {
    const routeData = route.data = route.data || {};
    if (!routeData.localizeRouter) {
      routeData.localizeRouter = {};
    }
    if (!routeData.localizeRouter[property]) {
      routeData.localizeRouter = __spreadProps(__spreadValues({}, routeData.localizeRouter), {
        [property]: route[property]
      });
    }
    const result = this.translateRoute(routeData.localizeRouter[property]);
    route[property] = prefixLang ? this.addPrefixToUrl(result) : result;
  }
  get urlPrefix() {
    if (this.settings.alwaysSetPrefix || this.currentLang !== this.defaultLang) {
      return this.currentLang ? this.currentLang : this.defaultLang;
    } else {
      return "";
    }
  }
  /**
   * Add current lang as prefix to given url.
   */
  addPrefixToUrl(url) {
    const splitUrl = url.split("?");
    const isRootPath = splitUrl[0].length === 1 && splitUrl[0] === "/";
    splitUrl[0] = splitUrl[0].replace(/\/$/, "");
    const joinedUrl = splitUrl.join("?");
    if (this.urlPrefix === "") {
      return joinedUrl;
    }
    if (!joinedUrl.startsWith("/") && !isRootPath) {
      return `${this.urlPrefix}/${joinedUrl}`;
    }
    return `/${this.urlPrefix}${joinedUrl}`;
  }
  /**
   * Translate route and return observable
   */
  translateRoute(path) {
    const queryParts = path.split("?");
    if (queryParts.length > 2) {
      throw Error("There should be only one query parameter block in the URL");
    }
    const pathSegments = queryParts[0].split("/");
    return pathSegments.map((part) => part.length ? this.translateText(part) : part).join("/") + (queryParts.length > 1 ? `?${queryParts[1]}` : "");
  }
  /**
   * Get language from url
   */
  getLocationLang(url) {
    const queryParamSplit = (url || this.location.path()).split(/[\?;]/);
    let pathSlices = [];
    if (queryParamSplit.length > 0) {
      pathSlices = queryParamSplit[0].split("/");
    }
    if (pathSlices.length > 1 && this.locales.indexOf(pathSlices[1]) !== -1) {
      return pathSlices[1];
    }
    if (pathSlices.length && this.locales.indexOf(pathSlices[0]) !== -1) {
      return pathSlices[0];
    }
    return null;
  }
  /**
   * Get user's language set in the browser
   */
  _getBrowserLang() {
    return this._returnIfInLocales(this.translate.getBrowserLang());
  }
  /**
   * Get language from local storage or cookie
   */
  get _cachedLang() {
    if (!this.settings.useCachedLang) {
      return;
    }
    if (this.settings.cacheMechanism === CacheMechanism.LocalStorage) {
      return this._cacheWithLocalStorage();
    }
    if (this.settings.cacheMechanism === CacheMechanism.SessionStorage) {
      return this._cacheWithSessionStorage();
    }
    if (this.settings.cacheMechanism === CacheMechanism.Cookie) {
      return this._cacheWithCookies();
    }
  }
  /**
   * Save language to local storage or cookie
   */
  set _cachedLang(value) {
    if (!this.settings.useCachedLang) {
      return;
    }
    if (this.settings.cacheMechanism === CacheMechanism.LocalStorage) {
      this._cacheWithLocalStorage(value);
    }
    if (this.settings.cacheMechanism === CacheMechanism.SessionStorage) {
      this._cacheWithSessionStorage(value);
    }
    if (this.settings.cacheMechanism === CacheMechanism.Cookie) {
      this._cacheWithCookies(value);
    }
  }
  /**
   * Cache value to local storage
   */
  _cacheWithLocalStorage(value) {
    try {
      if (typeof window === "undefined" || typeof window.localStorage === "undefined") {
        return;
      }
      if (value) {
        window.localStorage.setItem(this.settings.cacheName, value);
        return;
      }
      return this._returnIfInLocales(window.localStorage.getItem(this.settings.cacheName));
    } catch (e) {
      return;
    }
  }
  /**
   * Cache value to session storage
   */
  _cacheWithSessionStorage(value) {
    try {
      if (typeof window === "undefined" || typeof window.sessionStorage === "undefined") {
        return;
      }
      if (value) {
        window.sessionStorage.setItem(this.settings.cacheName, value);
        return;
      }
      return this._returnIfInLocales(window.sessionStorage.getItem(this.settings.cacheName));
    } catch (e) {
      return;
    }
  }
  /**
   * Cache value via cookies
   */
  _cacheWithCookies(value) {
    try {
      if (typeof document === "undefined" || typeof document.cookie === "undefined") {
        return;
      }
      const name = encodeURIComponent(this.settings.cacheName);
      if (value) {
        let cookieTemplate = `${this.settings.cookieFormat}`;
        cookieTemplate = cookieTemplate.replace("{{value}}", `${name}=${encodeURIComponent(value)}`).replace(/{{expires:?(\d+)?}}/g, (fullMatch, groupMatch) => {
          const days = groupMatch === void 0 ? COOKIE_EXPIRY : parseInt(groupMatch, 10);
          const date = /* @__PURE__ */ new Date();
          date.setTime(date.getTime() + days * 864e5);
          return `expires=${date.toUTCString()}`;
        });
        document.cookie = cookieTemplate;
        return;
      }
      const regexp = new RegExp("(?:^" + name + "|;\\s*" + name + ")=(.*?)(?:;|$)", "g");
      const result = regexp.exec(document.cookie);
      return decodeURIComponent(result[1]);
    } catch (e) {
      return;
    }
  }
  /**
   * Check if value exists in locales list
   */
  _returnIfInLocales(value) {
    if (value && this.locales.indexOf(value) !== -1) {
      return value;
    }
    return null;
  }
  /**
   * Get translated value
   */
  translateText(key) {
    if (this.escapePrefix && key.startsWith(this.escapePrefix)) {
      return key.replace(this.escapePrefix, "");
    } else {
      if (!this._translationObject) {
        return key;
      }
      const fullKey = this.prefix + key;
      const res = this.translate.getParsedResult(this._translationObject, fullKey);
      return res !== fullKey ? res : key;
    }
  }
  /**
   * Strategy to choose between new or old queryParams
   * @param newExtras extras that containes new QueryParams
   * @param currentQueryParams current query params
   */
  chooseQueryParams(newExtras, currentQueryParams) {
    let queryParamsObj;
    if (newExtras && newExtras.queryParams) {
      queryParamsObj = newExtras.queryParams;
    } else if (currentQueryParams) {
      queryParamsObj = currentQueryParams;
    }
    return queryParamsObj;
  }
  /**
   * Format query params from object to string.
   * Exemple of result: `param=value&param2=value2`
   * @param params query params object
   */
  formatQueryParams(params) {
    return new HttpParams({
      fromObject: params
    }).toString();
  }
  /**
   * Get translation key prefix from config
   */
  getPrefix() {
    return this.prefix;
  }
  /**
   * Get escape translation prefix from config
   */
  getEscapePrefix() {
    return this.escapePrefix;
  }
  static {
    this.ɵfac = function LocalizeParser_Factory(t) {
      return new (t || _LocalizeParser)(ɵɵinject(TranslateService), ɵɵinject(Location), ɵɵinject(LocalizeRouterSettings));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _LocalizeParser,
      factory: _LocalizeParser.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LocalizeParser, [{
    type: Injectable
  }], () => [{
    type: TranslateService,
    decorators: [{
      type: Inject,
      args: [TranslateService]
    }]
  }, {
    type: Location,
    decorators: [{
      type: Inject,
      args: [Location]
    }]
  }, {
    type: LocalizeRouterSettings,
    decorators: [{
      type: Inject,
      args: [LocalizeRouterSettings]
    }]
  }], null);
})();
var ManualParserLoader = class extends LocalizeParser {
  /**
   * CTOR
   */
  constructor(translate, location, settings, locales = ["en"], prefix = "ROUTES.", escapePrefix = "") {
    super(translate, location, settings);
    this.locales = locales;
    this.prefix = prefix || "";
    this.escapePrefix = escapePrefix || "";
  }
  /**
   * Initialize or append routes
   */
  load(routes) {
    return new Promise((resolve) => {
      this.init(routes).then(resolve);
    });
  }
};
var DummyLocalizeParser = class _DummyLocalizeParser extends LocalizeParser {
  load(routes) {
    return new Promise((resolve) => {
      this.init(routes).then(resolve);
    });
  }
  static {
    this.ɵfac = /* @__PURE__ */ (() => {
      let ɵDummyLocalizeParser_BaseFactory;
      return function DummyLocalizeParser_Factory(t) {
        return (ɵDummyLocalizeParser_BaseFactory || (ɵDummyLocalizeParser_BaseFactory = ɵɵgetInheritedFactory(_DummyLocalizeParser)))(t || _DummyLocalizeParser);
      };
    })();
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _DummyLocalizeParser,
      factory: _DummyLocalizeParser.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DummyLocalizeParser, [{
    type: Injectable
  }], null, null);
})();
function equals(o1, o2) {
  if (o1 === o2) {
    return true;
  }
  if (o1 === null || o2 === null) {
    return false;
  }
  if (o1 !== o1 && o2 !== o2) {
    return true;
  }
  const t1 = typeof o1, t2 = typeof o2;
  let length, key, keySet;
  if (t1 === t2 && t1 === "object") {
    if (Array.isArray(o1)) {
      if (!Array.isArray(o2)) {
        return false;
      }
      if ((length = o1.length) === o2.length) {
        for (key = 0; key < length; key++) {
          if (!equals(o1[key], o2[key])) {
            return false;
          }
        }
        return true;
      }
    } else {
      if (Array.isArray(o2)) {
        return false;
      }
      keySet = /* @__PURE__ */ Object.create(null);
      for (key in o1) {
        if (o1.hasOwnProperty(key)) {
          if (!equals(o1[key], o2[key])) {
            return false;
          }
          keySet[key] = true;
        }
      }
      for (key in o2) {
        if (o2.hasOwnProperty(key)) {
          if (!(key in keySet) && typeof o2[key] !== "undefined") {
            return false;
          }
        }
      }
      return true;
    }
  }
  return false;
}
function isPromise(obj) {
  return !!obj && typeof obj.then === "function";
}
function deepCopy(object) {
  const output = Array.isArray(object) ? [] : {};
  for (const data in object) {
    if (data) {
      const value = object[data];
      output[data] = typeof value === "object" ? deepCopy(value) : value;
    }
  }
  return output;
}
var LocalizeRouterService = class _LocalizeRouterService {
  /**
   * CTOR
   */
  constructor(parser, settings, router, route) {
    this.parser = parser;
    this.settings = settings;
    this.router = router;
    this.route = route;
    this.routerEvents = new Subject();
    const initializedSubject = new ReplaySubject(1);
    this.hooks = {
      _initializedSubject: initializedSubject,
      initialized: initializedSubject.asObservable()
    };
  }
  /**
   * Start up the service
   */
  init() {
    this.applyConfigToRouter(this.parser.routes);
    this.router.events.pipe(filter((event) => event instanceof NavigationStart), pairwise()).subscribe(this._routeChanged());
    if (this.settings.initialNavigation) {
      this.router.initialNavigation();
    }
  }
  /**
   * Change language and navigate to translated route
   */
  changeLanguage(lang, extras, useNavigateMethod) {
    if (lang !== this.parser.currentLang) {
      const rootSnapshot = this.router.routerState.snapshot.root;
      this.parser.translateRoutes(lang).subscribe(() => {
        let url = this.traverseRouteSnapshot(rootSnapshot);
        url = this.translateRoute(url);
        if (!this.settings.alwaysSetPrefix) {
          let urlSegments = url.split("/");
          const languageSegmentIndex = urlSegments.indexOf(this.parser.currentLang);
          if (this.parser.currentLang === this.parser.defaultLang) {
            if (languageSegmentIndex === 0 || languageSegmentIndex === 1 && urlSegments[0] === "") {
              urlSegments = urlSegments.slice(0, languageSegmentIndex).concat(urlSegments.slice(languageSegmentIndex + 1));
            }
          } else {
            if (languageSegmentIndex === -1) {
              const injectionIndex = urlSegments[0] === "" ? 1 : 0;
              urlSegments = urlSegments.slice(0, injectionIndex).concat(this.parser.currentLang, urlSegments.slice(injectionIndex));
            }
          }
          url = urlSegments.join("/");
        }
        url = url.replace(/\/+/g, "/");
        const lastSlashIndex = url.lastIndexOf("/");
        if (lastSlashIndex > 0 && lastSlashIndex === url.length - 1) {
          url = url.slice(0, -1);
        }
        const queryParamsObj = this.parser.chooseQueryParams(extras, this.route.snapshot.queryParams);
        this.applyConfigToRouter(this.parser.routes);
        this.lastExtras = extras;
        if (useNavigateMethod) {
          const extrasToApply = extras ? __spreadValues({}, extras) : {};
          if (queryParamsObj) {
            extrasToApply.queryParams = queryParamsObj;
          }
          this.router.navigate([url], extrasToApply);
        } else {
          let queryParams = this.parser.formatQueryParams(queryParamsObj);
          queryParams = queryParams ? `?${queryParams}` : "";
          this.router.navigateByUrl(`${url}${queryParams}`, extras);
        }
      });
    }
  }
  /**
   * Traverses through the tree to assemble new translated url
   */
  traverseRouteSnapshot(snapshot) {
    if (snapshot.firstChild && snapshot.routeConfig) {
      return `${this.parseSegmentValue(snapshot)}/${this.traverseRouteSnapshot(snapshot.firstChild)}`;
    } else if (snapshot.firstChild) {
      return this.traverseRouteSnapshot(snapshot.firstChild);
    } else {
      return this.parseSegmentValue(snapshot);
    }
  }
  /**
   * Build URL from segments and snapshot (for params)
   */
  buildUrlFromSegments(snapshot, segments) {
    return segments.map((s, i) => s.indexOf(":") === 0 ? snapshot.url[i].path : s).join("/");
  }
  /**
   * Extracts new segment value based on routeConfig and url
   */
  parseSegmentValue(snapshot) {
    if (snapshot.routeConfig && snapshot.routeConfig.matcher) {
      const subPathMatchedSegments = this.parseSegmentValueMatcher(snapshot);
      return this.buildUrlFromSegments(snapshot, subPathMatchedSegments);
    } else if (snapshot.data.localizeRouter) {
      const path = snapshot.data.localizeRouter.path;
      const subPathSegments = path.split("/");
      return this.buildUrlFromSegments(snapshot, subPathSegments);
    } else if (snapshot.parent && snapshot.parent.parent) {
      const path = snapshot.routeConfig.path;
      const subPathSegments = path.split("/");
      return this.buildUrlFromSegments(snapshot, subPathSegments);
    } else {
      return "";
    }
  }
  parseSegmentValueMatcher(snapshot) {
    const localizeMatcherParams = snapshot.data && snapshot.data.localizeMatcher && snapshot.data.localizeMatcher.params || {};
    const subPathSegments = snapshot.url.map((segment) => {
      const currentPath = segment.path;
      const matchedParamName = segment.localizedParamName;
      const val = matchedParamName && localizeMatcherParams[matchedParamName] ? localizeMatcherParams[matchedParamName](currentPath) : null;
      return val || `${this.parser.getEscapePrefix()}${currentPath}`;
    });
    return subPathSegments;
  }
  /**
   * Translate route to current language
   * If new language is explicitly provided then replace language part in url with new language
   */
  translateRoute(path) {
    if (typeof path === "string") {
      const url = this.parser.translateRoute(path);
      return !path.indexOf("/") ? this.parser.addPrefixToUrl(url) : url;
    }
    const result = [];
    path.forEach((segment, index) => {
      if (typeof segment === "string") {
        const res = this.parser.translateRoute(segment);
        if (!index && !segment.indexOf("/")) {
          result.push(this.parser.addPrefixToUrl(res));
        } else {
          result.push(res);
        }
      } else {
        result.push(segment);
      }
    });
    return result;
  }
  /**
   * Event handler to react on route change
   */
  _routeChanged() {
    return ([previousEvent, currentEvent]) => {
      const previousLang = this.parser.getLocationLang(previousEvent.url) || this.parser.defaultLang;
      const currentLang = this.parser.getLocationLang(currentEvent.url) || this.parser.defaultLang;
      const lastExtras = this.lastExtras;
      if (currentLang !== previousLang && this.latestUrl !== currentEvent.url) {
        this.latestUrl = currentEvent.url;
        this.cancelCurrentNavigation();
        this.parser.translateRoutes(currentLang).subscribe(() => {
          this.applyConfigToRouter(this.parser.routes);
          this.lastExtras = void 0;
          this.router.navigateByUrl(currentEvent.url, lastExtras);
          this.routerEvents.next(currentLang);
        });
      }
      this.latestUrl = currentEvent.url;
    };
  }
  /**
   * Drop the current Navigation
   */
  cancelCurrentNavigation() {
    const currentNavigation = this.router.getCurrentNavigation();
    const url = this.router.serializeUrl(currentNavigation.extractedUrl);
    this.router.events.next(new NavigationCancel(currentNavigation.id, url, ""));
    this.router.navigationTransitions.transitions.next(__spreadProps(__spreadValues({}, this.router.navigationTransitions.transitions.getValue()), {
      id: 0
    }));
  }
  /**
   * Apply config to Angular RouterModule
   * @param config routes to apply
   */
  applyConfigToRouter(config) {
    this.router.resetConfig(deepCopy(config));
  }
  static {
    this.ɵfac = function LocalizeRouterService_Factory(t) {
      return new (t || _LocalizeRouterService)(ɵɵinject(LocalizeParser), ɵɵinject(LocalizeRouterSettings), ɵɵinject(Router), ɵɵinject(ActivatedRoute));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _LocalizeRouterService,
      factory: _LocalizeRouterService.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LocalizeRouterService, [{
    type: Injectable
  }], () => [{
    type: LocalizeParser,
    decorators: [{
      type: Inject,
      args: [LocalizeParser]
    }]
  }, {
    type: LocalizeRouterSettings,
    decorators: [{
      type: Inject,
      args: [LocalizeRouterSettings]
    }]
  }, {
    type: Router,
    decorators: [{
      type: Inject,
      args: [Router]
    }]
  }, {
    type: ActivatedRoute,
    decorators: [{
      type: Inject,
      args: [ActivatedRoute]
    }]
  }], null);
})();
var VIEW_DESTROYED_STATE = 128;
var LocalizeRouterPipe = class _LocalizeRouterPipe {
  /**
   * CTOR
   */
  constructor(localize, _ref) {
    this.localize = localize;
    this._ref = _ref;
    this.value = "";
    this.subscription = this.localize.routerEvents.subscribe(() => {
      this.transform(this.lastKey);
    });
  }
  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
  /**
   * Transform current url to localized one
   */
  transform(query) {
    if (!query || query.length === 0 || !this.localize.parser.currentLang) {
      return query;
    }
    if (equals(query, this.lastKey) && equals(this.lastLanguage, this.localize.parser.currentLang)) {
      return this.value;
    }
    this.lastKey = query;
    this.lastLanguage = this.localize.parser.currentLang;
    this.value = this.localize.translateRoute(query);
    this.lastKey = query;
    const view = this._ref._view;
    if (view && view.state & VIEW_DESTROYED_STATE) {
      return this.value;
    }
    setTimeout(() => {
      this._ref.detectChanges();
    }, 0);
    return this.value;
  }
  static {
    this.ɵfac = function LocalizeRouterPipe_Factory(t) {
      return new (t || _LocalizeRouterPipe)(ɵɵdirectiveInject(LocalizeRouterService, 16), ɵɵdirectiveInject(ChangeDetectorRef, 16));
    };
  }
  static {
    this.ɵpipe = ɵɵdefinePipe({
      name: "localize",
      type: _LocalizeRouterPipe,
      pure: false,
      standalone: true
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LocalizeRouterPipe, [{
    type: Pipe,
    args: [{
      name: "localize",
      pure: false,
      // required to update the value when the promise is resolved
      standalone: true
    }]
  }], () => [{
    type: LocalizeRouterService
  }, {
    type: ChangeDetectorRef
  }], null);
})();
var GilsdavReuseStrategy = class {
  // private handlers: {[key: string]: DetachedRouteHandle} = {};
  constructor() {
  }
  shouldDetach(route) {
    return false;
  }
  store(route, handle) {
  }
  shouldAttach(route) {
    return false;
  }
  retrieve(route) {
    return null;
  }
  shouldReuseRoute(future, curr) {
    return future && curr ? this.getKey(future) === this.getKey(curr) : false;
  }
  getKey(route) {
    if (route.firstChild && route.firstChild.routeConfig && route.firstChild.routeConfig.path && route.firstChild.routeConfig.path.indexOf("**") !== -1) {
      return "WILDCARD";
    } else if (!route.data.localizeRouter && (!route.parent || !route.parent.parent) && !route.data.skipRouteLocalization) {
      return "LANG";
    } else if (route.routeConfig.matcher) {
      let keyM = `${this.getKey(route.parent)}/${route.routeConfig.matcher.name}`;
      if (route.data.discriminantPathKey) {
        keyM = `${keyM}-${route.data.discriminantPathKey}`;
      }
      return keyM;
    } else if (route.data.localizeRouter) {
      let key = `${this.getKey(route.parent)}/${route.data.localizeRouter.path}`;
      if (route.data.discriminantPathKey) {
        key = `${key}-${route.data.discriminantPathKey}`;
      }
      return key;
    } else {
      let key = route.routeConfig.path;
      if (route.parent) {
        key = `${this.getKey(route.parent)}/${route.routeConfig.path}`;
      }
      if (route.data.discriminantPathKey) {
        key = `${key}-${route.data.discriminantPathKey}`;
      }
      return key;
    }
  }
};
var LocalizedRouter = class _LocalizedRouter extends Router {
  constructor() {
    super();
    this.platformId = inject(PLATFORM_ID);
    this.compiler = inject(Compiler);
    this.localize = inject(LocalizeParser);
    this.childrenLoaders = /* @__PURE__ */ new WeakMap();
    this.loadModuleFactoryOrRoutes = (parentInjector, route) => {
      return wrapIntoObservable(route.loadChildren()).pipe(map(maybeUnwrapDefaultExport), mergeMap((t) => {
        if (t instanceof NgModuleFactory$1 || Array.isArray(t)) {
          return of(t);
        } else {
          return from(this.compiler.compileModuleAsync(t));
        }
      }), map((factoryOrRoutes) => {
        if (this.onLoadEndListener) {
          this.onLoadEndListener(route);
        }
        let injector;
        let rawRoutes;
        if (Array.isArray(factoryOrRoutes)) {
          rawRoutes = this.localize.initChildRoutes([].concat(...factoryOrRoutes));
        } else {
          injector = factoryOrRoutes.create(parentInjector).injector;
          const getMethod = injector.get.bind(injector);
          injector["get"] = (token, notFoundValue, flags) => {
            const getResult = getMethod(token, notFoundValue, flags);
            if (token === ROUTES) {
              return this.localize.initChildRoutes([].concat(...getResult));
            } else {
              return getResult;
            }
          };
          rawRoutes = injector.get(ROUTES, [], {
            optional: true,
            self: true
          }).reduce((acc, routes2) => acc.concat(routes2), []);
        }
        const routes = rawRoutes.map(standardizeConfig);
        return {
          routes,
          injector
        };
      }));
    };
    const isBrowser = isPlatformBrowser(this.platformId);
    const configLoader = isBrowser ? this.navigationTransitions.configLoader.__proto__ : this.navigationTransitions.configLoader;
    configLoader.loadChildren = (parentInjector, route) => {
      if (this.childrenLoaders.get(route)) {
        return this.childrenLoaders.get(route);
      } else if (route._loadedRoutes) {
        return of({
          routes: route._loadedRoutes,
          injector: route._loadedInjector
        });
      }
      if (this.onLoadStartListener) {
        this.onLoadStartListener(route);
      }
      const moduleFactoryOrRoutes$ = this.loadModuleFactoryOrRoutes(parentInjector, route);
      const loadRunner = moduleFactoryOrRoutes$.pipe(finalize(() => {
        this.childrenLoaders.delete(route);
      }));
      const loader = new ConnectableObservable(loadRunner, () => new Subject()).pipe(refCount());
      this.childrenLoaders.set(route, loader);
      return loader;
    };
  }
  static {
    this.ɵfac = function LocalizedRouter_Factory(t) {
      return new (t || _LocalizedRouter)();
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _LocalizedRouter,
      factory: _LocalizedRouter.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LocalizedRouter, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [], null);
})();
function standardizeConfig(r) {
  const children = r.children && r.children.map(standardizeConfig);
  const c = children ? __spreadProps(__spreadValues({}, r), {
    children
  }) : __spreadValues({}, r);
  if (!c.component && !c.loadComponent && (children || c.loadChildren) && c.outlet && c.outlet !== PRIMARY_OUTLET) {
    c.component = ɵEmptyOutletComponent;
  }
  return c;
}
function isWrappedDefaultExport(value) {
  return value && typeof value === "object" && "default" in value;
}
function maybeUnwrapDefaultExport(input) {
  return isWrappedDefaultExport(input) ? input["default"] : input;
}
function wrapIntoObservable(value) {
  if (isObservable(value)) {
    return value;
  }
  if (isPromise(value)) {
    return from(Promise.resolve(value));
  }
  return of(value);
}
var ParserInitializer = class _ParserInitializer {
  /**
   * CTOR
   */
  constructor(injector) {
    this.injector = injector;
  }
  appInitializer() {
    const res = this.parser.load(this.routes);
    return res.then(() => {
      const localize = this.injector.get(LocalizeRouterService);
      const router = this.injector.get(Router);
      const settings = this.injector.get(LocalizeRouterSettings);
      localize.init();
      if (settings.initialNavigation) {
        return new Promise((resolve) => {
          const oldAfterPreactivation = router.navigationTransitions.afterPreactivation;
          let firstInit = true;
          router.navigationTransitions.afterPreactivation = () => {
            if (firstInit) {
              resolve();
              firstInit = false;
              localize.hooks._initializedSubject.next(true);
              localize.hooks._initializedSubject.complete();
            }
            return oldAfterPreactivation();
          };
        });
      } else {
        localize.hooks._initializedSubject.next(true);
        localize.hooks._initializedSubject.complete();
      }
    });
  }
  generateInitializer(parser, routes) {
    this.parser = parser;
    this.routes = routes.reduce((a, b) => a.concat(b));
    return this.appInitializer;
  }
  static {
    this.ɵfac = function ParserInitializer_Factory(t) {
      return new (t || _ParserInitializer)(ɵɵinject(Injector));
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _ParserInitializer,
      factory: _ParserInitializer.ɵfac
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ParserInitializer, [{
    type: Injectable
  }], () => [{
    type: Injector
  }], null);
})();
function getAppInitializer(p, parser, routes) {
  const routesCopy = deepCopy(routes);
  return p.generateInitializer(parser, routesCopy).bind(p);
}
function createLocalizeRouterProviders(routes, config) {
  return [{
    provide: Router,
    useClass: LocalizedRouter
  }, {
    provide: LOCALIZE_ROUTER_FORROOT_GUARD,
    useFactory: provideForRootGuard,
    deps: [[LocalizeRouterModule, new Optional(), new SkipSelf()]]
  }, {
    provide: USE_CACHED_LANG,
    useValue: config.useCachedLang
  }, {
    provide: ALWAYS_SET_PREFIX,
    useValue: config.alwaysSetPrefix
  }, {
    provide: CACHE_NAME,
    useValue: config.cacheName
  }, {
    provide: CACHE_MECHANISM,
    useValue: config.cacheMechanism
  }, {
    provide: DEFAULT_LANG_FUNCTION,
    useValue: config.defaultLangFunction
  }, {
    provide: COOKIE_FORMAT,
    useValue: config.cookieFormat
  }, {
    provide: INITIAL_NAVIGATION,
    useValue: config.initialNavigation
  }, LocalizeRouterSettings, config.parser || {
    provide: LocalizeParser,
    useClass: DummyLocalizeParser
  }, {
    provide: RAW_ROUTES,
    multi: true,
    useValue: routes
  }, LocalizeRouterService, ParserInitializer, {
    provide: APP_INITIALIZER,
    multi: true,
    useFactory: getAppInitializer,
    deps: [ParserInitializer, LocalizeParser, RAW_ROUTES]
  }, {
    provide: RouteReuseStrategy,
    useClass: GilsdavReuseStrategy
  }];
}
var LocalizeRouterModule = class _LocalizeRouterModule {
  static forRoot(routes, config = {}) {
    return {
      ngModule: _LocalizeRouterModule,
      providers: createLocalizeRouterProviders(routes, config)
    };
  }
  static forChild(routes) {
    return {
      ngModule: _LocalizeRouterModule,
      providers: [{
        provide: RAW_ROUTES,
        multi: true,
        useValue: routes
      }]
    };
  }
  static {
    this.ɵfac = function LocalizeRouterModule_Factory(t) {
      return new (t || _LocalizeRouterModule)();
    };
  }
  static {
    this.ɵmod = ɵɵdefineNgModule({
      type: _LocalizeRouterModule,
      imports: [CommonModule, RouterModule, TranslateModule, LocalizeRouterPipe],
      exports: [LocalizeRouterPipe]
    });
  }
  static {
    this.ɵinj = ɵɵdefineInjector({
      imports: [CommonModule, RouterModule, TranslateModule]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LocalizeRouterModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, RouterModule, TranslateModule, LocalizeRouterPipe],
      exports: [LocalizeRouterPipe]
    }]
  }], null, null);
})();
function provideForRootGuard(localizeRouterModule) {
  if (localizeRouterModule) {
    throw new Error(`LocalizeRouterModule.forRoot() called twice. Lazy loaded modules should use LocalizeRouterModule.forChild() instead.`);
  }
  return "guarded";
}
function withLocalizeRouter(routes, config = {}) {
  return {
    ɵkind: "LocalizeRouter",
    ɵproviders: createLocalizeRouterProviders(routes, config)
  };
}
var LocalizeNgModuleFactory = class extends NgModuleFactory$1 {
  constructor(moduleType) {
    super();
    this.moduleType = moduleType;
    this.create = (parentInjector) => {
      const compiler = parentInjector.get(Compiler);
      const localize = parentInjector.get(LocalizeParser);
      const compiled = compiler.compileModuleAndAllComponentsSync(this.moduleType);
      const moduleRef = compiled.ngModuleFactory.create(parentInjector);
      const getMethod = moduleRef.injector.get.bind(moduleRef.injector);
      moduleRef.injector["get"] = (token, notFoundValue) => {
        const getResult = getMethod(token, notFoundValue);
        if (token === ROUTES) {
          return localize.initChildRoutes([].concat(...getResult));
        } else {
          return getResult;
        }
      };
      return moduleRef;
    };
  }
};
function translateModule(moduleType) {
  return new LocalizeNgModuleFactory(moduleType);
}

export {
  LOCALIZE_ROUTER_FORROOT_GUARD,
  RAW_ROUTES,
  CacheMechanism,
  USE_CACHED_LANG,
  CACHE_MECHANISM,
  CACHE_NAME,
  COOKIE_FORMAT,
  INITIAL_NAVIGATION,
  DEFAULT_LANG_FUNCTION,
  ALWAYS_SET_PREFIX,
  LocalizeRouterSettings,
  LocalizeParser,
  ManualParserLoader,
  DummyLocalizeParser,
  LocalizeRouterService,
  LocalizeRouterPipe,
  GilsdavReuseStrategy,
  LocalizedRouter,
  standardizeConfig,
  wrapIntoObservable,
  ParserInitializer,
  getAppInitializer,
  LocalizeRouterModule,
  provideForRootGuard,
  withLocalizeRouter,
  LocalizeNgModuleFactory,
  translateModule
};
//# sourceMappingURL=chunk-NJHX4NLE.js.map
