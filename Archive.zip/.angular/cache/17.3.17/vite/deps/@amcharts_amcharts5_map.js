import {
  Color,
  Component,
  Container,
  DEGREES,
  DataItem,
  Graphics,
  Label,
  ListTemplate,
  Percent,
  RADIANS,
  Rectangle,
  SerialChart,
  Series,
  ZoomTools,
  circlesOverlap,
  cubic,
  fitToRange,
  getAngle,
  isLocalEvent,
  mergeTags,
  out,
  registry,
  round,
  sameBounds,
  setColor,
  spiralPoints
} from "./chunk-KALW7GAD.js";
import {
  Template,
  Theme,
  each,
  each2,
  find,
  isNumber,
  keys,
  move,
  numberToString,
  pushAll,
  remove,
  removeFirst,
  softCopyProperties
} from "./chunk-OKK4C562.js";
import "./chunk-ZA2DQWUL.js";
import {
  __commonJS,
  __esm,
  __export,
  __toCommonJS,
  __toESM,
  __yieldStar
} from "./chunk-KZQQXEH6.js";

// node_modules/tinyqueue/index.js
var tinyqueue_exports = {};
__export(tinyqueue_exports, {
  default: () => TinyQueue
});
function defaultCompare(a2, b) {
  return a2 < b ? -1 : a2 > b ? 1 : 0;
}
var TinyQueue;
var init_tinyqueue = __esm({
  "node_modules/tinyqueue/index.js"() {
    TinyQueue = class {
      constructor(data = [], compare = defaultCompare) {
        this.data = data;
        this.length = this.data.length;
        this.compare = compare;
        if (this.length > 0) {
          for (let i = (this.length >> 1) - 1; i >= 0; i--) this._down(i);
        }
      }
      push(item) {
        this.data.push(item);
        this.length++;
        this._up(this.length - 1);
      }
      pop() {
        if (this.length === 0) return void 0;
        const top = this.data[0];
        const bottom = this.data.pop();
        this.length--;
        if (this.length > 0) {
          this.data[0] = bottom;
          this._down(0);
        }
        return top;
      }
      peek() {
        return this.data[0];
      }
      _up(pos) {
        const { data, compare } = this;
        const item = data[pos];
        while (pos > 0) {
          const parent = pos - 1 >> 1;
          const current = data[parent];
          if (compare(item, current) >= 0) break;
          data[pos] = current;
          pos = parent;
        }
        data[pos] = item;
      }
      _down(pos) {
        const { data, compare } = this;
        const halfLength = this.length >> 1;
        const item = data[pos];
        while (pos < halfLength) {
          let left = (pos << 1) + 1;
          let best = data[left];
          const right = left + 1;
          if (right < this.length && compare(data[right], best) < 0) {
            left = right;
            best = data[right];
          }
          if (compare(best, item) >= 0) break;
          data[pos] = best;
          pos = left;
        }
        data[pos] = item;
      }
    };
  }
});

// node_modules/polylabel/polylabel.js
var require_polylabel = __commonJS({
  "node_modules/polylabel/polylabel.js"(exports, module) {
    "use strict";
    var Queue = (init_tinyqueue(), __toCommonJS(tinyqueue_exports));
    if (Queue.default) Queue = Queue.default;
    module.exports = polylabel;
    module.exports.default = polylabel;
    function polylabel(polygon, precision, debug) {
      precision = precision || 1;
      var minX, minY, maxX, maxY;
      for (var i = 0; i < polygon[0].length; i++) {
        var p = polygon[0][i];
        if (!i || p[0] < minX) minX = p[0];
        if (!i || p[1] < minY) minY = p[1];
        if (!i || p[0] > maxX) maxX = p[0];
        if (!i || p[1] > maxY) maxY = p[1];
      }
      var width = maxX - minX;
      var height = maxY - minY;
      var cellSize = Math.min(width, height);
      var h = cellSize / 2;
      if (cellSize === 0) {
        var degeneratePoleOfInaccessibility = [minX, minY];
        degeneratePoleOfInaccessibility.distance = 0;
        return degeneratePoleOfInaccessibility;
      }
      var cellQueue = new Queue(void 0, compareMax);
      for (var x = minX; x < maxX; x += cellSize) {
        for (var y = minY; y < maxY; y += cellSize) {
          cellQueue.push(new Cell(x + h, y + h, h, polygon));
        }
      }
      var bestCell = getCentroidCell(polygon);
      var bboxCell = new Cell(minX + width / 2, minY + height / 2, 0, polygon);
      if (bboxCell.d > bestCell.d) bestCell = bboxCell;
      var numProbes = cellQueue.length;
      while (cellQueue.length) {
        var cell = cellQueue.pop();
        if (cell.d > bestCell.d) {
          bestCell = cell;
          if (debug) console.log("found best %d after %d probes", Math.round(1e4 * cell.d) / 1e4, numProbes);
        }
        if (cell.max - bestCell.d <= precision) continue;
        h = cell.h / 2;
        cellQueue.push(new Cell(cell.x - h, cell.y - h, h, polygon));
        cellQueue.push(new Cell(cell.x + h, cell.y - h, h, polygon));
        cellQueue.push(new Cell(cell.x - h, cell.y + h, h, polygon));
        cellQueue.push(new Cell(cell.x + h, cell.y + h, h, polygon));
        numProbes += 4;
      }
      if (debug) {
        console.log("num probes: " + numProbes);
        console.log("best distance: " + bestCell.d);
      }
      var poleOfInaccessibility = [bestCell.x, bestCell.y];
      poleOfInaccessibility.distance = bestCell.d;
      return poleOfInaccessibility;
    }
    function compareMax(a2, b) {
      return b.max - a2.max;
    }
    function Cell(x, y, h, polygon) {
      this.x = x;
      this.y = y;
      this.h = h;
      this.d = pointToPolygonDist(x, y, polygon);
      this.max = this.d + this.h * Math.SQRT2;
    }
    function pointToPolygonDist(x, y, polygon) {
      var inside = false;
      var minDistSq = Infinity;
      for (var k = 0; k < polygon.length; k++) {
        var ring = polygon[k];
        for (var i = 0, len = ring.length, j = len - 1; i < len; j = i++) {
          var a2 = ring[i];
          var b = ring[j];
          if (a2[1] > y !== b[1] > y && x < (b[0] - a2[0]) * (y - a2[1]) / (b[1] - a2[1]) + a2[0]) inside = !inside;
          minDistSq = Math.min(minDistSq, getSegDistSq(x, y, a2, b));
        }
      }
      return minDistSq === 0 ? 0 : (inside ? 1 : -1) * Math.sqrt(minDistSq);
    }
    function getCentroidCell(polygon) {
      var area = 0;
      var x = 0;
      var y = 0;
      var points = polygon[0];
      for (var i = 0, len = points.length, j = len - 1; i < len; j = i++) {
        var a2 = points[i];
        var b = points[j];
        var f = a2[0] * b[1] - b[0] * a2[1];
        x += (a2[0] + b[0]) * f;
        y += (a2[1] + b[1]) * f;
        area += f * 3;
      }
      if (area === 0) return new Cell(points[0][0], points[0][1], 0, polygon);
      return new Cell(x / area, y / area, 0, polygon);
    }
    function getSegDistSq(px, py, a2, b) {
      var x = a2[0];
      var y = a2[1];
      var dx = b[0] - x;
      var dy = b[1] - y;
      if (dx !== 0 || dy !== 0) {
        var t = ((px - x) * dx + (py - y) * dy) / (dx * dx + dy * dy);
        if (t > 1) {
          x = b[0];
          y = b[1];
        } else if (t > 0) {
          x += dx * t;
          y += dy * t;
        }
      }
      dx = px - x;
      dy = py - y;
      return dx * dx + dy * dy;
    }
  }
});

// node_modules/@amcharts/amcharts5/.internal/charts/map/MapSeries.js
var MapSeries = class extends Series {
  constructor() {
    super(...arguments);
    Object.defineProperty(this, "_types", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: []
    });
    Object.defineProperty(this, "_geometries", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: []
    });
    Object.defineProperty(this, "_geoJSONparsed", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: false
    });
    Object.defineProperty(this, "_excluded", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: []
    });
    Object.defineProperty(this, "_notIncluded", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: []
    });
  }
  _afterNew() {
    this.fields.push("geometry", "geometryType");
    this._setRawDefault("geometryField", "geometry");
    this._setRawDefault("geometryTypeField", "geometryType");
    this._setRawDefault("idField", "id");
    this.on("geoJSON", (geoJSON) => {
      let previous = this._prevSettings.geoJSON;
      if (previous && previous != geoJSON) {
        this.data.clear();
      }
    });
    super._afterNew();
  }
  _handleDirties() {
    const geoJSON = this.get("geoJSON");
    let previous = this._prevSettings.geoJSON;
    if (previous && previous != geoJSON) {
      this._prevSettings.geoJSON = void 0;
      this._geoJSONparsed = false;
    }
    if (!this._geoJSONparsed) {
      this._parseGeoJSON();
      this._geoJSONparsed = true;
    }
  }
  _prepareChildren() {
    super._prepareChildren();
    if (this._valuesDirty) {
      this._handleDirties();
    }
    if (this.get("geoJSON") && (this.isDirty("geoJSON") || this.isDirty("include") || this.isDirty("exclude"))) {
      this._handleDirties();
      const chart = this.chart;
      const exclude = this.get("exclude");
      if (exclude) {
        if (chart) {
          chart._centerLocation = null;
        }
        each(exclude, (id) => {
          const dataItem = this.getDataItemById(id);
          if (dataItem) {
            this._excludeDataItem(dataItem);
          }
        });
        each(this._excluded, (dataItem) => {
          const id = dataItem.get("id");
          if (id) {
            if (exclude.indexOf(id) == -1) {
              this._unexcludeDataItem(dataItem);
            }
          }
        });
      }
      if (!exclude || exclude.length == 0) {
        each(this._excluded, (dataItem) => {
          this._unexcludeDataItem(dataItem);
        });
        this._excluded = [];
      }
      const include = this.get("include");
      if (include) {
        if (chart) {
          chart._centerLocation = null;
        }
        each(this.dataItems, (dataItem) => {
          const id = dataItem.get("id");
          if (id && include.indexOf(id) == -1) {
            this._notIncludeDataItem(dataItem);
          } else {
            this._unNotIncludeDataItem(dataItem);
          }
        });
      }
      if (!include) {
        each(this._notIncluded, (dataItem) => {
          this._unNotIncludeDataItem(dataItem);
        });
        this._notIncluded = [];
      }
    }
  }
  _excludeDataItem(dataItem) {
    this._removeGeometry(dataItem.get("geometry"));
    move(this._excluded, dataItem);
  }
  _unexcludeDataItem(dataItem) {
    this._addGeometry(dataItem.get("geometry"), this);
  }
  _notIncludeDataItem(dataItem) {
    this._removeGeometry(dataItem.get("geometry"));
    move(this._notIncluded, dataItem);
  }
  _unNotIncludeDataItem(dataItem) {
    this._addGeometry(dataItem.get("geometry"), this);
  }
  checkInclude(id, includes, excludes) {
    if (includes) {
      if (includes.length == 0) {
        return false;
      } else {
        if (includes.indexOf(id) == -1) {
          return false;
        }
      }
    }
    if (excludes && excludes.length > 0) {
      if (excludes.indexOf(id) != -1) {
        return false;
      }
    }
    return true;
  }
  _parseGeoJSON() {
    const geoJSON = this.get("geoJSON");
    if (geoJSON) {
      let features;
      if (geoJSON.type == "FeatureCollection") {
        features = geoJSON.features;
      } else if (geoJSON.type == "Feature") {
        features = [geoJSON];
      } else if (["Point", "LineString", "Polygon", "MultiPoint", "MultiLineString", "MultiPolygon"].indexOf(geoJSON.type) != -1) {
        features = [{ geometry: geoJSON }];
      } else {
        console.log("nothing found in geoJSON");
      }
      const geodataNames = this.get("geodataNames");
      if (features) {
        const idField = this.get("idField", "id");
        for (let i = 0, len = features.length; i < len; i++) {
          let feature = features[i];
          let geometry = feature.geometry;
          if (geometry) {
            let type2 = geometry.type;
            let id = feature[idField];
            if (geodataNames && geodataNames[id]) {
              feature.properties.name = geodataNames[id];
            }
            if (this._types.indexOf(type2) != -1) {
              let dataItem;
              if (id != null) {
                dataItem = find(this.dataItems, (value) => {
                  return value.get("id") == id;
                });
              }
              let dataObject;
              if (dataItem) {
                dataObject = dataItem.dataContext;
              }
              if (!dataItem) {
                dataObject = { geometry, geometryType: type2, madeFromGeoData: true };
                dataObject[idField] = id;
                this.data.push(dataObject);
              } else {
                if (!dataObject.geometry) {
                  dataObject.geometry = geometry;
                  dataObject.geometryType = type2;
                  dataItem.set("geometry", geometry);
                  dataItem.set("geometryType", type2);
                  this.processDataItem(dataItem);
                }
              }
              softCopyProperties(feature.properties, dataObject);
            }
          }
        }
      }
      const type = "geodataprocessed";
      if (this.events.isEnabled(type)) {
        this.events.dispatch(type, { type, target: this });
      }
    }
  }
  _placeBulletsContainer(_chart) {
    this.children.moveValue(this.bulletsContainer);
  }
  _removeBulletsContainer() {
  }
  /**
   * @ignore
   */
  projection() {
    const chart = this.chart;
    if (chart) {
      return chart.get("projection");
    }
  }
  /**
   * @ignore
   */
  geoPath() {
    const chart = this.chart;
    if (chart) {
      return chart.getPrivate("geoPath");
    }
  }
  _addGeometry(geometry, series) {
    if (geometry && series.get("affectsBounds", true)) {
      this._geometries.push(geometry);
      const chart = this.chart;
      if (chart) {
        chart.markDirtyGeometries();
      }
    }
  }
  _removeGeometry(geometry) {
    if (geometry) {
      remove(this._geometries, geometry);
      const chart = this.chart;
      if (chart) {
        chart.markDirtyGeometries();
      }
    }
  }
  _dispose() {
    super._dispose();
    const chart = this.chart;
    if (chart) {
      chart.series.removeValue(this);
    }
  }
  _onDataClear() {
    super._onDataClear();
    this._geoJSONparsed = false;
    this._markDirtyKey("exclude");
  }
};
Object.defineProperty(MapSeries, "className", {
  enumerable: true,
  configurable: true,
  writable: true,
  value: "MapSeries"
});
Object.defineProperty(MapSeries, "classNames", {
  enumerable: true,
  configurable: true,
  writable: true,
  value: Series.classNames.concat([MapSeries.className])
});

// node_modules/d3-array/src/ascending.js
function ascending(a2, b) {
  return a2 == null || b == null ? NaN : a2 < b ? -1 : a2 > b ? 1 : a2 >= b ? 0 : NaN;
}

// node_modules/d3-array/src/descending.js
function descending(a2, b) {
  return a2 == null || b == null ? NaN : b < a2 ? -1 : b > a2 ? 1 : b >= a2 ? 0 : NaN;
}

// node_modules/d3-array/src/bisector.js
function bisector(f) {
  let compare1, compare2, delta;
  if (f.length !== 2) {
    compare1 = ascending;
    compare2 = (d, x) => ascending(f(d), x);
    delta = (d, x) => f(d) - x;
  } else {
    compare1 = f === ascending || f === descending ? f : zero;
    compare2 = f;
    delta = f;
  }
  function left(a2, x, lo = 0, hi = a2.length) {
    if (lo < hi) {
      if (compare1(x, x) !== 0) return hi;
      do {
        const mid = lo + hi >>> 1;
        if (compare2(a2[mid], x) < 0) lo = mid + 1;
        else hi = mid;
      } while (lo < hi);
    }
    return lo;
  }
  function right(a2, x, lo = 0, hi = a2.length) {
    if (lo < hi) {
      if (compare1(x, x) !== 0) return hi;
      do {
        const mid = lo + hi >>> 1;
        if (compare2(a2[mid], x) <= 0) lo = mid + 1;
        else hi = mid;
      } while (lo < hi);
    }
    return lo;
  }
  function center(a2, x, lo = 0, hi = a2.length) {
    const i = left(a2, x, lo, hi - 1);
    return i > lo && delta(a2[i - 1], x) > -delta(a2[i], x) ? i - 1 : i;
  }
  return { left, center, right };
}
function zero() {
  return 0;
}

// node_modules/d3-array/src/number.js
function number(x) {
  return x === null ? NaN : +x;
}

// node_modules/d3-array/src/bisect.js
var ascendingBisect = bisector(ascending);
var bisectRight = ascendingBisect.right;
var bisectLeft = ascendingBisect.left;
var bisectCenter = bisector(number).center;

// node_modules/d3-array/src/blur.js
var blur2 = Blur2(blurf);
var blurImage = Blur2(blurfImage);
function Blur2(blur3) {
  return function(data, rx, ry = rx) {
    if (!((rx = +rx) >= 0)) throw new RangeError("invalid rx");
    if (!((ry = +ry) >= 0)) throw new RangeError("invalid ry");
    let { data: values, width, height } = data;
    if (!((width = Math.floor(width)) >= 0)) throw new RangeError("invalid width");
    if (!((height = Math.floor(height !== void 0 ? height : values.length / width)) >= 0)) throw new RangeError("invalid height");
    if (!width || !height || !rx && !ry) return data;
    const blurx = rx && blur3(rx);
    const blury = ry && blur3(ry);
    const temp = values.slice();
    if (blurx && blury) {
      blurh(blurx, temp, values, width, height);
      blurh(blurx, values, temp, width, height);
      blurh(blurx, temp, values, width, height);
      blurv(blury, values, temp, width, height);
      blurv(blury, temp, values, width, height);
      blurv(blury, values, temp, width, height);
    } else if (blurx) {
      blurh(blurx, values, temp, width, height);
      blurh(blurx, temp, values, width, height);
      blurh(blurx, values, temp, width, height);
    } else if (blury) {
      blurv(blury, values, temp, width, height);
      blurv(blury, temp, values, width, height);
      blurv(blury, values, temp, width, height);
    }
    return data;
  };
}
function blurh(blur3, T, S, w, h) {
  for (let y = 0, n = w * h; y < n; ) {
    blur3(T, S, y, y += w, 1);
  }
}
function blurv(blur3, T, S, w, h) {
  for (let x = 0, n = w * h; x < w; ++x) {
    blur3(T, S, x, x + n, w);
  }
}
function blurfImage(radius) {
  const blur3 = blurf(radius);
  return (T, S, start, stop, step) => {
    start <<= 2, stop <<= 2, step <<= 2;
    blur3(T, S, start + 0, stop + 0, step);
    blur3(T, S, start + 1, stop + 1, step);
    blur3(T, S, start + 2, stop + 2, step);
    blur3(T, S, start + 3, stop + 3, step);
  };
}
function blurf(radius) {
  const radius0 = Math.floor(radius);
  if (radius0 === radius) return bluri(radius);
  const t = radius - radius0;
  const w = 2 * radius + 1;
  return (T, S, start, stop, step) => {
    if (!((stop -= step) >= start)) return;
    let sum2 = radius0 * S[start];
    const s0 = step * radius0;
    const s1 = s0 + step;
    for (let i = start, j = start + s0; i < j; i += step) {
      sum2 += S[Math.min(stop, i)];
    }
    for (let i = start, j = stop; i <= j; i += step) {
      sum2 += S[Math.min(stop, i + s0)];
      T[i] = (sum2 + t * (S[Math.max(start, i - s1)] + S[Math.min(stop, i + s1)])) / w;
      sum2 -= S[Math.max(start, i - s0)];
    }
  };
}
function bluri(radius) {
  const w = 2 * radius + 1;
  return (T, S, start, stop, step) => {
    if (!((stop -= step) >= start)) return;
    let sum2 = radius * S[start];
    const s = step * radius;
    for (let i = start, j = start + s; i < j; i += step) {
      sum2 += S[Math.min(stop, i)];
    }
    for (let i = start, j = stop; i <= j; i += step) {
      sum2 += S[Math.min(stop, i + s)];
      T[i] = sum2 / w;
      sum2 -= S[Math.max(start, i - s)];
    }
  };
}

// node_modules/d3-array/src/fsum.js
var Adder = class {
  constructor() {
    this._partials = new Float64Array(32);
    this._n = 0;
  }
  add(x) {
    const p = this._partials;
    let i = 0;
    for (let j = 0; j < this._n && j < 32; j++) {
      const y = p[j], hi = x + y, lo = Math.abs(x) < Math.abs(y) ? x - (hi - y) : y - (hi - x);
      if (lo) p[i++] = lo;
      x = hi;
    }
    p[i] = x;
    this._n = i + 1;
    return this;
  }
  valueOf() {
    const p = this._partials;
    let n = this._n, x, y, lo, hi = 0;
    if (n > 0) {
      hi = p[--n];
      while (n > 0) {
        x = hi;
        y = p[--n];
        hi = x + y;
        lo = y - (hi - x);
        if (lo) break;
      }
      if (n > 0 && (lo < 0 && p[n - 1] < 0 || lo > 0 && p[n - 1] > 0)) {
        y = lo * 2;
        x = hi + y;
        if (y == x - hi) hi = x;
      }
    }
    return hi;
  }
};

// node_modules/d3-array/src/array.js
var array = Array.prototype;
var slice = array.slice;
var map = array.map;

// node_modules/d3-array/src/ticks.js
var e10 = Math.sqrt(50);
var e5 = Math.sqrt(10);
var e2 = Math.sqrt(2);

// node_modules/d3-array/src/merge.js
function* flatten(arrays) {
  for (const array2 of arrays) {
    yield* __yieldStar(array2);
  }
}
function merge(arrays) {
  return Array.from(flatten(arrays));
}

// node_modules/d3-array/src/range.js
function range(start, stop, step) {
  start = +start, stop = +stop, step = (n = arguments.length) < 2 ? (stop = start, start = 0, 1) : n < 3 ? 1 : +step;
  var i = -1, n = Math.max(0, Math.ceil((stop - start) / step)) | 0, range3 = new Array(n);
  while (++i < n) {
    range3[i] = start + i * step;
  }
  return range3;
}

// node_modules/d3-array/src/shuffle.js
var shuffle_default = shuffler(Math.random);
function shuffler(random) {
  return function shuffle2(array2, i0 = 0, i1 = array2.length) {
    let m2 = i1 - (i0 = +i0);
    while (m2) {
      const i = random() * m2-- | 0, t = array2[m2 + i0];
      array2[m2 + i0] = array2[i + i0];
      array2[i + i0] = t;
    }
    return array2;
  };
}

// node_modules/d3-geo/src/math.js
var epsilon = 1e-6;
var epsilon2 = 1e-12;
var pi = Math.PI;
var halfPi = pi / 2;
var quarterPi = pi / 4;
var tau = pi * 2;
var degrees = 180 / pi;
var radians = pi / 180;
var abs = Math.abs;
var atan = Math.atan;
var atan2 = Math.atan2;
var cos = Math.cos;
var ceil = Math.ceil;
var exp = Math.exp;
var hypot = Math.hypot;
var log = Math.log;
var sin = Math.sin;
var sign = Math.sign || function(x) {
  return x > 0 ? 1 : x < 0 ? -1 : 0;
};
var sqrt = Math.sqrt;
var tan = Math.tan;
function acos(x) {
  return x > 1 ? 0 : x < -1 ? pi : Math.acos(x);
}
function asin(x) {
  return x > 1 ? halfPi : x < -1 ? -halfPi : Math.asin(x);
}
function haversin(x) {
  return (x = sin(x / 2)) * x;
}

// node_modules/d3-geo/src/noop.js
function noop() {
}

// node_modules/d3-geo/src/stream.js
function streamGeometry(geometry, stream) {
  if (geometry && streamGeometryType.hasOwnProperty(geometry.type)) {
    streamGeometryType[geometry.type](geometry, stream);
  }
}
var streamObjectType = {
  Feature: function(object2, stream) {
    streamGeometry(object2.geometry, stream);
  },
  FeatureCollection: function(object2, stream) {
    var features = object2.features, i = -1, n = features.length;
    while (++i < n) streamGeometry(features[i].geometry, stream);
  }
};
var streamGeometryType = {
  Sphere: function(object2, stream) {
    stream.sphere();
  },
  Point: function(object2, stream) {
    object2 = object2.coordinates;
    stream.point(object2[0], object2[1], object2[2]);
  },
  MultiPoint: function(object2, stream) {
    var coordinates2 = object2.coordinates, i = -1, n = coordinates2.length;
    while (++i < n) object2 = coordinates2[i], stream.point(object2[0], object2[1], object2[2]);
  },
  LineString: function(object2, stream) {
    streamLine(object2.coordinates, stream, 0);
  },
  MultiLineString: function(object2, stream) {
    var coordinates2 = object2.coordinates, i = -1, n = coordinates2.length;
    while (++i < n) streamLine(coordinates2[i], stream, 0);
  },
  Polygon: function(object2, stream) {
    streamPolygon(object2.coordinates, stream);
  },
  MultiPolygon: function(object2, stream) {
    var coordinates2 = object2.coordinates, i = -1, n = coordinates2.length;
    while (++i < n) streamPolygon(coordinates2[i], stream);
  },
  GeometryCollection: function(object2, stream) {
    var geometries = object2.geometries, i = -1, n = geometries.length;
    while (++i < n) streamGeometry(geometries[i], stream);
  }
};
function streamLine(coordinates2, stream, closed) {
  var i = -1, n = coordinates2.length - closed, coordinate;
  stream.lineStart();
  while (++i < n) coordinate = coordinates2[i], stream.point(coordinate[0], coordinate[1], coordinate[2]);
  stream.lineEnd();
}
function streamPolygon(coordinates2, stream) {
  var i = -1, n = coordinates2.length;
  stream.polygonStart();
  while (++i < n) streamLine(coordinates2[i], stream, 1);
  stream.polygonEnd();
}
function stream_default(object2, stream) {
  if (object2 && streamObjectType.hasOwnProperty(object2.type)) {
    streamObjectType[object2.type](object2, stream);
  } else {
    streamGeometry(object2, stream);
  }
}

// node_modules/d3-geo/src/area.js
var areaRingSum = new Adder();
var areaSum = new Adder();
var lambda00;
var phi00;
var lambda0;
var cosPhi0;
var sinPhi0;
var areaStream = {
  point: noop,
  lineStart: noop,
  lineEnd: noop,
  polygonStart: function() {
    areaRingSum = new Adder();
    areaStream.lineStart = areaRingStart;
    areaStream.lineEnd = areaRingEnd;
  },
  polygonEnd: function() {
    var areaRing = +areaRingSum;
    areaSum.add(areaRing < 0 ? tau + areaRing : areaRing);
    this.lineStart = this.lineEnd = this.point = noop;
  },
  sphere: function() {
    areaSum.add(tau);
  }
};
function areaRingStart() {
  areaStream.point = areaPointFirst;
}
function areaRingEnd() {
  areaPoint(lambda00, phi00);
}
function areaPointFirst(lambda, phi2) {
  areaStream.point = areaPoint;
  lambda00 = lambda, phi00 = phi2;
  lambda *= radians, phi2 *= radians;
  lambda0 = lambda, cosPhi0 = cos(phi2 = phi2 / 2 + quarterPi), sinPhi0 = sin(phi2);
}
function areaPoint(lambda, phi2) {
  lambda *= radians, phi2 *= radians;
  phi2 = phi2 / 2 + quarterPi;
  var dLambda = lambda - lambda0, sdLambda = dLambda >= 0 ? 1 : -1, adLambda = sdLambda * dLambda, cosPhi = cos(phi2), sinPhi = sin(phi2), k = sinPhi0 * sinPhi, u = cosPhi0 * cosPhi + k * cos(adLambda), v = k * sdLambda * sin(adLambda);
  areaRingSum.add(atan2(v, u));
  lambda0 = lambda, cosPhi0 = cosPhi, sinPhi0 = sinPhi;
}
function area_default(object2) {
  areaSum = new Adder();
  stream_default(object2, areaStream);
  return areaSum * 2;
}

// node_modules/d3-geo/src/cartesian.js
function spherical(cartesian2) {
  return [atan2(cartesian2[1], cartesian2[0]), asin(cartesian2[2])];
}
function cartesian(spherical2) {
  var lambda = spherical2[0], phi2 = spherical2[1], cosPhi = cos(phi2);
  return [cosPhi * cos(lambda), cosPhi * sin(lambda), sin(phi2)];
}
function cartesianDot(a2, b) {
  return a2[0] * b[0] + a2[1] * b[1] + a2[2] * b[2];
}
function cartesianCross(a2, b) {
  return [a2[1] * b[2] - a2[2] * b[1], a2[2] * b[0] - a2[0] * b[2], a2[0] * b[1] - a2[1] * b[0]];
}
function cartesianAddInPlace(a2, b) {
  a2[0] += b[0], a2[1] += b[1], a2[2] += b[2];
}
function cartesianScale(vector, k) {
  return [vector[0] * k, vector[1] * k, vector[2] * k];
}
function cartesianNormalizeInPlace(d) {
  var l = sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
  d[0] /= l, d[1] /= l, d[2] /= l;
}

// node_modules/d3-geo/src/bounds.js
var lambda02;
var phi0;
var lambda1;
var phi1;
var lambda2;
var lambda002;
var phi002;
var p0;
var deltaSum;
var ranges;
var range2;
var boundsStream = {
  point: boundsPoint,
  lineStart: boundsLineStart,
  lineEnd: boundsLineEnd,
  polygonStart: function() {
    boundsStream.point = boundsRingPoint;
    boundsStream.lineStart = boundsRingStart;
    boundsStream.lineEnd = boundsRingEnd;
    deltaSum = new Adder();
    areaStream.polygonStart();
  },
  polygonEnd: function() {
    areaStream.polygonEnd();
    boundsStream.point = boundsPoint;
    boundsStream.lineStart = boundsLineStart;
    boundsStream.lineEnd = boundsLineEnd;
    if (areaRingSum < 0) lambda02 = -(lambda1 = 180), phi0 = -(phi1 = 90);
    else if (deltaSum > epsilon) phi1 = 90;
    else if (deltaSum < -epsilon) phi0 = -90;
    range2[0] = lambda02, range2[1] = lambda1;
  },
  sphere: function() {
    lambda02 = -(lambda1 = 180), phi0 = -(phi1 = 90);
  }
};
function boundsPoint(lambda, phi2) {
  ranges.push(range2 = [lambda02 = lambda, lambda1 = lambda]);
  if (phi2 < phi0) phi0 = phi2;
  if (phi2 > phi1) phi1 = phi2;
}
function linePoint(lambda, phi2) {
  var p = cartesian([lambda * radians, phi2 * radians]);
  if (p0) {
    var normal = cartesianCross(p0, p), equatorial = [normal[1], -normal[0], 0], inflection = cartesianCross(equatorial, normal);
    cartesianNormalizeInPlace(inflection);
    inflection = spherical(inflection);
    var delta = lambda - lambda2, sign2 = delta > 0 ? 1 : -1, lambdai = inflection[0] * degrees * sign2, phii, antimeridian = abs(delta) > 180;
    if (antimeridian ^ (sign2 * lambda2 < lambdai && lambdai < sign2 * lambda)) {
      phii = inflection[1] * degrees;
      if (phii > phi1) phi1 = phii;
    } else if (lambdai = (lambdai + 360) % 360 - 180, antimeridian ^ (sign2 * lambda2 < lambdai && lambdai < sign2 * lambda)) {
      phii = -inflection[1] * degrees;
      if (phii < phi0) phi0 = phii;
    } else {
      if (phi2 < phi0) phi0 = phi2;
      if (phi2 > phi1) phi1 = phi2;
    }
    if (antimeridian) {
      if (lambda < lambda2) {
        if (angle(lambda02, lambda) > angle(lambda02, lambda1)) lambda1 = lambda;
      } else {
        if (angle(lambda, lambda1) > angle(lambda02, lambda1)) lambda02 = lambda;
      }
    } else {
      if (lambda1 >= lambda02) {
        if (lambda < lambda02) lambda02 = lambda;
        if (lambda > lambda1) lambda1 = lambda;
      } else {
        if (lambda > lambda2) {
          if (angle(lambda02, lambda) > angle(lambda02, lambda1)) lambda1 = lambda;
        } else {
          if (angle(lambda, lambda1) > angle(lambda02, lambda1)) lambda02 = lambda;
        }
      }
    }
  } else {
    ranges.push(range2 = [lambda02 = lambda, lambda1 = lambda]);
  }
  if (phi2 < phi0) phi0 = phi2;
  if (phi2 > phi1) phi1 = phi2;
  p0 = p, lambda2 = lambda;
}
function boundsLineStart() {
  boundsStream.point = linePoint;
}
function boundsLineEnd() {
  range2[0] = lambda02, range2[1] = lambda1;
  boundsStream.point = boundsPoint;
  p0 = null;
}
function boundsRingPoint(lambda, phi2) {
  if (p0) {
    var delta = lambda - lambda2;
    deltaSum.add(abs(delta) > 180 ? delta + (delta > 0 ? 360 : -360) : delta);
  } else {
    lambda002 = lambda, phi002 = phi2;
  }
  areaStream.point(lambda, phi2);
  linePoint(lambda, phi2);
}
function boundsRingStart() {
  areaStream.lineStart();
}
function boundsRingEnd() {
  boundsRingPoint(lambda002, phi002);
  areaStream.lineEnd();
  if (abs(deltaSum) > epsilon) lambda02 = -(lambda1 = 180);
  range2[0] = lambda02, range2[1] = lambda1;
  p0 = null;
}
function angle(lambda04, lambda12) {
  return (lambda12 -= lambda04) < 0 ? lambda12 + 360 : lambda12;
}
function rangeCompare(a2, b) {
  return a2[0] - b[0];
}
function rangeContains(range3, x) {
  return range3[0] <= range3[1] ? range3[0] <= x && x <= range3[1] : x < range3[0] || range3[1] < x;
}
function bounds_default(feature) {
  var i, n, a2, b, merged, deltaMax, delta;
  phi1 = lambda1 = -(lambda02 = phi0 = Infinity);
  ranges = [];
  stream_default(feature, boundsStream);
  if (n = ranges.length) {
    ranges.sort(rangeCompare);
    for (i = 1, a2 = ranges[0], merged = [a2]; i < n; ++i) {
      b = ranges[i];
      if (rangeContains(a2, b[0]) || rangeContains(a2, b[1])) {
        if (angle(a2[0], b[1]) > angle(a2[0], a2[1])) a2[1] = b[1];
        if (angle(b[0], a2[1]) > angle(a2[0], a2[1])) a2[0] = b[0];
      } else {
        merged.push(a2 = b);
      }
    }
    for (deltaMax = -Infinity, n = merged.length - 1, i = 0, a2 = merged[n]; i <= n; a2 = b, ++i) {
      b = merged[i];
      if ((delta = angle(a2[1], b[0])) > deltaMax) deltaMax = delta, lambda02 = b[0], lambda1 = a2[1];
    }
  }
  ranges = range2 = null;
  return lambda02 === Infinity || phi0 === Infinity ? [[NaN, NaN], [NaN, NaN]] : [[lambda02, phi0], [lambda1, phi1]];
}

// node_modules/d3-geo/src/centroid.js
var W0;
var W1;
var X0;
var Y0;
var Z0;
var X1;
var Y1;
var Z1;
var X2;
var Y2;
var Z2;
var lambda003;
var phi003;
var x0;
var y0;
var z0;
var centroidStream = {
  sphere: noop,
  point: centroidPoint,
  lineStart: centroidLineStart,
  lineEnd: centroidLineEnd,
  polygonStart: function() {
    centroidStream.lineStart = centroidRingStart;
    centroidStream.lineEnd = centroidRingEnd;
  },
  polygonEnd: function() {
    centroidStream.lineStart = centroidLineStart;
    centroidStream.lineEnd = centroidLineEnd;
  }
};
function centroidPoint(lambda, phi2) {
  lambda *= radians, phi2 *= radians;
  var cosPhi = cos(phi2);
  centroidPointCartesian(cosPhi * cos(lambda), cosPhi * sin(lambda), sin(phi2));
}
function centroidPointCartesian(x, y, z) {
  ++W0;
  X0 += (x - X0) / W0;
  Y0 += (y - Y0) / W0;
  Z0 += (z - Z0) / W0;
}
function centroidLineStart() {
  centroidStream.point = centroidLinePointFirst;
}
function centroidLinePointFirst(lambda, phi2) {
  lambda *= radians, phi2 *= radians;
  var cosPhi = cos(phi2);
  x0 = cosPhi * cos(lambda);
  y0 = cosPhi * sin(lambda);
  z0 = sin(phi2);
  centroidStream.point = centroidLinePoint;
  centroidPointCartesian(x0, y0, z0);
}
function centroidLinePoint(lambda, phi2) {
  lambda *= radians, phi2 *= radians;
  var cosPhi = cos(phi2), x = cosPhi * cos(lambda), y = cosPhi * sin(lambda), z = sin(phi2), w = atan2(sqrt((w = y0 * z - z0 * y) * w + (w = z0 * x - x0 * z) * w + (w = x0 * y - y0 * x) * w), x0 * x + y0 * y + z0 * z);
  W1 += w;
  X1 += w * (x0 + (x0 = x));
  Y1 += w * (y0 + (y0 = y));
  Z1 += w * (z0 + (z0 = z));
  centroidPointCartesian(x0, y0, z0);
}
function centroidLineEnd() {
  centroidStream.point = centroidPoint;
}
function centroidRingStart() {
  centroidStream.point = centroidRingPointFirst;
}
function centroidRingEnd() {
  centroidRingPoint(lambda003, phi003);
  centroidStream.point = centroidPoint;
}
function centroidRingPointFirst(lambda, phi2) {
  lambda003 = lambda, phi003 = phi2;
  lambda *= radians, phi2 *= radians;
  centroidStream.point = centroidRingPoint;
  var cosPhi = cos(phi2);
  x0 = cosPhi * cos(lambda);
  y0 = cosPhi * sin(lambda);
  z0 = sin(phi2);
  centroidPointCartesian(x0, y0, z0);
}
function centroidRingPoint(lambda, phi2) {
  lambda *= radians, phi2 *= radians;
  var cosPhi = cos(phi2), x = cosPhi * cos(lambda), y = cosPhi * sin(lambda), z = sin(phi2), cx = y0 * z - z0 * y, cy = z0 * x - x0 * z, cz = x0 * y - y0 * x, m2 = hypot(cx, cy, cz), w = asin(m2), v = m2 && -w / m2;
  X2.add(v * cx);
  Y2.add(v * cy);
  Z2.add(v * cz);
  W1 += w;
  X1 += w * (x0 + (x0 = x));
  Y1 += w * (y0 + (y0 = y));
  Z1 += w * (z0 + (z0 = z));
  centroidPointCartesian(x0, y0, z0);
}
function centroid_default(object2) {
  W0 = W1 = X0 = Y0 = Z0 = X1 = Y1 = Z1 = 0;
  X2 = new Adder();
  Y2 = new Adder();
  Z2 = new Adder();
  stream_default(object2, centroidStream);
  var x = +X2, y = +Y2, z = +Z2, m2 = hypot(x, y, z);
  if (m2 < epsilon2) {
    x = X1, y = Y1, z = Z1;
    if (W1 < epsilon) x = X0, y = Y0, z = Z0;
    m2 = hypot(x, y, z);
    if (m2 < epsilon2) return [NaN, NaN];
  }
  return [atan2(y, x) * degrees, asin(z / m2) * degrees];
}

// node_modules/d3-geo/src/constant.js
function constant_default(x) {
  return function() {
    return x;
  };
}

// node_modules/d3-geo/src/compose.js
function compose_default(a2, b) {
  function compose(x, y) {
    return x = a2(x, y), b(x[0], x[1]);
  }
  if (a2.invert && b.invert) compose.invert = function(x, y) {
    return x = b.invert(x, y), x && a2.invert(x[0], x[1]);
  };
  return compose;
}

// node_modules/d3-geo/src/rotation.js
function rotationIdentity(lambda, phi2) {
  if (abs(lambda) > pi) lambda -= Math.round(lambda / tau) * tau;
  return [lambda, phi2];
}
rotationIdentity.invert = rotationIdentity;
function rotateRadians(deltaLambda, deltaPhi, deltaGamma) {
  return (deltaLambda %= tau) ? deltaPhi || deltaGamma ? compose_default(rotationLambda(deltaLambda), rotationPhiGamma(deltaPhi, deltaGamma)) : rotationLambda(deltaLambda) : deltaPhi || deltaGamma ? rotationPhiGamma(deltaPhi, deltaGamma) : rotationIdentity;
}
function forwardRotationLambda(deltaLambda) {
  return function(lambda, phi2) {
    lambda += deltaLambda;
    if (abs(lambda) > pi) lambda -= Math.round(lambda / tau) * tau;
    return [lambda, phi2];
  };
}
function rotationLambda(deltaLambda) {
  var rotation = forwardRotationLambda(deltaLambda);
  rotation.invert = forwardRotationLambda(-deltaLambda);
  return rotation;
}
function rotationPhiGamma(deltaPhi, deltaGamma) {
  var cosDeltaPhi = cos(deltaPhi), sinDeltaPhi = sin(deltaPhi), cosDeltaGamma = cos(deltaGamma), sinDeltaGamma = sin(deltaGamma);
  function rotation(lambda, phi2) {
    var cosPhi = cos(phi2), x = cos(lambda) * cosPhi, y = sin(lambda) * cosPhi, z = sin(phi2), k = z * cosDeltaPhi + x * sinDeltaPhi;
    return [
      atan2(y * cosDeltaGamma - k * sinDeltaGamma, x * cosDeltaPhi - z * sinDeltaPhi),
      asin(k * cosDeltaGamma + y * sinDeltaGamma)
    ];
  }
  rotation.invert = function(lambda, phi2) {
    var cosPhi = cos(phi2), x = cos(lambda) * cosPhi, y = sin(lambda) * cosPhi, z = sin(phi2), k = z * cosDeltaGamma - y * sinDeltaGamma;
    return [
      atan2(y * cosDeltaGamma + z * sinDeltaGamma, x * cosDeltaPhi + k * sinDeltaPhi),
      asin(k * cosDeltaPhi - x * sinDeltaPhi)
    ];
  };
  return rotation;
}
function rotation_default(rotate) {
  rotate = rotateRadians(rotate[0] * radians, rotate[1] * radians, rotate.length > 2 ? rotate[2] * radians : 0);
  function forward(coordinates2) {
    coordinates2 = rotate(coordinates2[0] * radians, coordinates2[1] * radians);
    return coordinates2[0] *= degrees, coordinates2[1] *= degrees, coordinates2;
  }
  forward.invert = function(coordinates2) {
    coordinates2 = rotate.invert(coordinates2[0] * radians, coordinates2[1] * radians);
    return coordinates2[0] *= degrees, coordinates2[1] *= degrees, coordinates2;
  };
  return forward;
}

// node_modules/d3-geo/src/circle.js
function circleStream(stream, radius, delta, direction, t0, t1) {
  if (!delta) return;
  var cosRadius = cos(radius), sinRadius = sin(radius), step = direction * delta;
  if (t0 == null) {
    t0 = radius + direction * tau;
    t1 = radius - step / 2;
  } else {
    t0 = circleRadius(cosRadius, t0);
    t1 = circleRadius(cosRadius, t1);
    if (direction > 0 ? t0 < t1 : t0 > t1) t0 += direction * tau;
  }
  for (var point, t = t0; direction > 0 ? t > t1 : t < t1; t -= step) {
    point = spherical([cosRadius, -sinRadius * cos(t), -sinRadius * sin(t)]);
    stream.point(point[0], point[1]);
  }
}
function circleRadius(cosRadius, point) {
  point = cartesian(point), point[0] -= cosRadius;
  cartesianNormalizeInPlace(point);
  var radius = acos(-point[1]);
  return ((-point[2] < 0 ? -radius : radius) + tau - epsilon) % tau;
}
function circle_default() {
  var center = constant_default([0, 0]), radius = constant_default(90), precision = constant_default(2), ring, rotate, stream = { point };
  function point(x, y) {
    ring.push(x = rotate(x, y));
    x[0] *= degrees, x[1] *= degrees;
  }
  function circle() {
    var c2 = center.apply(this, arguments), r = radius.apply(this, arguments) * radians, p = precision.apply(this, arguments) * radians;
    ring = [];
    rotate = rotateRadians(-c2[0] * radians, -c2[1] * radians, 0).invert;
    circleStream(stream, r, p, 1);
    c2 = { type: "Polygon", coordinates: [ring] };
    ring = rotate = null;
    return c2;
  }
  circle.center = function(_) {
    return arguments.length ? (center = typeof _ === "function" ? _ : constant_default([+_[0], +_[1]]), circle) : center;
  };
  circle.radius = function(_) {
    return arguments.length ? (radius = typeof _ === "function" ? _ : constant_default(+_), circle) : radius;
  };
  circle.precision = function(_) {
    return arguments.length ? (precision = typeof _ === "function" ? _ : constant_default(+_), circle) : precision;
  };
  return circle;
}

// node_modules/d3-geo/src/clip/buffer.js
function buffer_default() {
  var lines = [], line;
  return {
    point: function(x, y, m2) {
      line.push([x, y, m2]);
    },
    lineStart: function() {
      lines.push(line = []);
    },
    lineEnd: noop,
    rejoin: function() {
      if (lines.length > 1) lines.push(lines.pop().concat(lines.shift()));
    },
    result: function() {
      var result = lines;
      lines = [];
      line = null;
      return result;
    }
  };
}

// node_modules/d3-geo/src/pointEqual.js
function pointEqual_default(a2, b) {
  return abs(a2[0] - b[0]) < epsilon && abs(a2[1] - b[1]) < epsilon;
}

// node_modules/d3-geo/src/clip/rejoin.js
function Intersection(point, points, other, entry) {
  this.x = point;
  this.z = points;
  this.o = other;
  this.e = entry;
  this.v = false;
  this.n = this.p = null;
}
function rejoin_default(segments, compareIntersection2, startInside, interpolate, stream) {
  var subject = [], clip = [], i, n;
  segments.forEach(function(segment) {
    if ((n2 = segment.length - 1) <= 0) return;
    var n2, p02 = segment[0], p1 = segment[n2], x;
    if (pointEqual_default(p02, p1)) {
      if (!p02[2] && !p1[2]) {
        stream.lineStart();
        for (i = 0; i < n2; ++i) stream.point((p02 = segment[i])[0], p02[1]);
        stream.lineEnd();
        return;
      }
      p1[0] += 2 * epsilon;
    }
    subject.push(x = new Intersection(p02, segment, null, true));
    clip.push(x.o = new Intersection(p02, null, x, false));
    subject.push(x = new Intersection(p1, segment, null, false));
    clip.push(x.o = new Intersection(p1, null, x, true));
  });
  if (!subject.length) return;
  clip.sort(compareIntersection2);
  link(subject);
  link(clip);
  for (i = 0, n = clip.length; i < n; ++i) {
    clip[i].e = startInside = !startInside;
  }
  var start = subject[0], points, point;
  while (1) {
    var current = start, isSubject = true;
    while (current.v) if ((current = current.n) === start) return;
    points = current.z;
    stream.lineStart();
    do {
      current.v = current.o.v = true;
      if (current.e) {
        if (isSubject) {
          for (i = 0, n = points.length; i < n; ++i) stream.point((point = points[i])[0], point[1]);
        } else {
          interpolate(current.x, current.n.x, 1, stream);
        }
        current = current.n;
      } else {
        if (isSubject) {
          points = current.p.z;
          for (i = points.length - 1; i >= 0; --i) stream.point((point = points[i])[0], point[1]);
        } else {
          interpolate(current.x, current.p.x, -1, stream);
        }
        current = current.p;
      }
      current = current.o;
      points = current.z;
      isSubject = !isSubject;
    } while (!current.v);
    stream.lineEnd();
  }
}
function link(array2) {
  if (!(n = array2.length)) return;
  var n, i = 0, a2 = array2[0], b;
  while (++i < n) {
    a2.n = b = array2[i];
    b.p = a2;
    a2 = b;
  }
  a2.n = b = array2[0];
  b.p = a2;
}

// node_modules/d3-geo/src/polygonContains.js
function longitude(point) {
  return abs(point[0]) <= pi ? point[0] : sign(point[0]) * ((abs(point[0]) + pi) % tau - pi);
}
function polygonContains_default(polygon, point) {
  var lambda = longitude(point), phi2 = point[1], sinPhi = sin(phi2), normal = [sin(lambda), -cos(lambda), 0], angle2 = 0, winding = 0;
  var sum2 = new Adder();
  if (sinPhi === 1) phi2 = halfPi + epsilon;
  else if (sinPhi === -1) phi2 = -halfPi - epsilon;
  for (var i = 0, n = polygon.length; i < n; ++i) {
    if (!(m2 = (ring = polygon[i]).length)) continue;
    var ring, m2, point0 = ring[m2 - 1], lambda04 = longitude(point0), phi02 = point0[1] / 2 + quarterPi, sinPhi03 = sin(phi02), cosPhi03 = cos(phi02);
    for (var j = 0; j < m2; ++j, lambda04 = lambda12, sinPhi03 = sinPhi1, cosPhi03 = cosPhi1, point0 = point1) {
      var point1 = ring[j], lambda12 = longitude(point1), phi12 = point1[1] / 2 + quarterPi, sinPhi1 = sin(phi12), cosPhi1 = cos(phi12), delta = lambda12 - lambda04, sign2 = delta >= 0 ? 1 : -1, absDelta = sign2 * delta, antimeridian = absDelta > pi, k = sinPhi03 * sinPhi1;
      sum2.add(atan2(k * sign2 * sin(absDelta), cosPhi03 * cosPhi1 + k * cos(absDelta)));
      angle2 += antimeridian ? delta + sign2 * tau : delta;
      if (antimeridian ^ lambda04 >= lambda ^ lambda12 >= lambda) {
        var arc = cartesianCross(cartesian(point0), cartesian(point1));
        cartesianNormalizeInPlace(arc);
        var intersection2 = cartesianCross(normal, arc);
        cartesianNormalizeInPlace(intersection2);
        var phiArc = (antimeridian ^ delta >= 0 ? -1 : 1) * asin(intersection2[2]);
        if (phi2 > phiArc || phi2 === phiArc && (arc[0] || arc[1])) {
          winding += antimeridian ^ delta >= 0 ? 1 : -1;
        }
      }
    }
  }
  return (angle2 < -epsilon || angle2 < epsilon && sum2 < -epsilon2) ^ winding & 1;
}

// node_modules/d3-geo/src/clip/index.js
function clip_default(pointVisible, clipLine, interpolate, start) {
  return function(sink) {
    var line = clipLine(sink), ringBuffer = buffer_default(), ringSink = clipLine(ringBuffer), polygonStarted = false, polygon, segments, ring;
    var clip = {
      point,
      lineStart,
      lineEnd,
      polygonStart: function() {
        clip.point = pointRing;
        clip.lineStart = ringStart;
        clip.lineEnd = ringEnd;
        segments = [];
        polygon = [];
      },
      polygonEnd: function() {
        clip.point = point;
        clip.lineStart = lineStart;
        clip.lineEnd = lineEnd;
        segments = merge(segments);
        var startInside = polygonContains_default(polygon, start);
        if (segments.length) {
          if (!polygonStarted) sink.polygonStart(), polygonStarted = true;
          rejoin_default(segments, compareIntersection, startInside, interpolate, sink);
        } else if (startInside) {
          if (!polygonStarted) sink.polygonStart(), polygonStarted = true;
          sink.lineStart();
          interpolate(null, null, 1, sink);
          sink.lineEnd();
        }
        if (polygonStarted) sink.polygonEnd(), polygonStarted = false;
        segments = polygon = null;
      },
      sphere: function() {
        sink.polygonStart();
        sink.lineStart();
        interpolate(null, null, 1, sink);
        sink.lineEnd();
        sink.polygonEnd();
      }
    };
    function point(lambda, phi2) {
      if (pointVisible(lambda, phi2)) sink.point(lambda, phi2);
    }
    function pointLine(lambda, phi2) {
      line.point(lambda, phi2);
    }
    function lineStart() {
      clip.point = pointLine;
      line.lineStart();
    }
    function lineEnd() {
      clip.point = point;
      line.lineEnd();
    }
    function pointRing(lambda, phi2) {
      ring.push([lambda, phi2]);
      ringSink.point(lambda, phi2);
    }
    function ringStart() {
      ringSink.lineStart();
      ring = [];
    }
    function ringEnd() {
      pointRing(ring[0][0], ring[0][1]);
      ringSink.lineEnd();
      var clean = ringSink.clean(), ringSegments = ringBuffer.result(), i, n = ringSegments.length, m2, segment, point2;
      ring.pop();
      polygon.push(ring);
      ring = null;
      if (!n) return;
      if (clean & 1) {
        segment = ringSegments[0];
        if ((m2 = segment.length - 1) > 0) {
          if (!polygonStarted) sink.polygonStart(), polygonStarted = true;
          sink.lineStart();
          for (i = 0; i < m2; ++i) sink.point((point2 = segment[i])[0], point2[1]);
          sink.lineEnd();
        }
        return;
      }
      if (n > 1 && clean & 2) ringSegments.push(ringSegments.pop().concat(ringSegments.shift()));
      segments.push(ringSegments.filter(validSegment));
    }
    return clip;
  };
}
function validSegment(segment) {
  return segment.length > 1;
}
function compareIntersection(a2, b) {
  return ((a2 = a2.x)[0] < 0 ? a2[1] - halfPi - epsilon : halfPi - a2[1]) - ((b = b.x)[0] < 0 ? b[1] - halfPi - epsilon : halfPi - b[1]);
}

// node_modules/d3-geo/src/clip/antimeridian.js
var antimeridian_default = clip_default(
  function() {
    return true;
  },
  clipAntimeridianLine,
  clipAntimeridianInterpolate,
  [-pi, -halfPi]
);
function clipAntimeridianLine(stream) {
  var lambda04 = NaN, phi02 = NaN, sign0 = NaN, clean;
  return {
    lineStart: function() {
      stream.lineStart();
      clean = 1;
    },
    point: function(lambda12, phi12) {
      var sign1 = lambda12 > 0 ? pi : -pi, delta = abs(lambda12 - lambda04);
      if (abs(delta - pi) < epsilon) {
        stream.point(lambda04, phi02 = (phi02 + phi12) / 2 > 0 ? halfPi : -halfPi);
        stream.point(sign0, phi02);
        stream.lineEnd();
        stream.lineStart();
        stream.point(sign1, phi02);
        stream.point(lambda12, phi02);
        clean = 0;
      } else if (sign0 !== sign1 && delta >= pi) {
        if (abs(lambda04 - sign0) < epsilon) lambda04 -= sign0 * epsilon;
        if (abs(lambda12 - sign1) < epsilon) lambda12 -= sign1 * epsilon;
        phi02 = clipAntimeridianIntersect(lambda04, phi02, lambda12, phi12);
        stream.point(sign0, phi02);
        stream.lineEnd();
        stream.lineStart();
        stream.point(sign1, phi02);
        clean = 0;
      }
      stream.point(lambda04 = lambda12, phi02 = phi12);
      sign0 = sign1;
    },
    lineEnd: function() {
      stream.lineEnd();
      lambda04 = phi02 = NaN;
    },
    clean: function() {
      return 2 - clean;
    }
  };
}
function clipAntimeridianIntersect(lambda04, phi02, lambda12, phi12) {
  var cosPhi03, cosPhi1, sinLambda0Lambda1 = sin(lambda04 - lambda12);
  return abs(sinLambda0Lambda1) > epsilon ? atan((sin(phi02) * (cosPhi1 = cos(phi12)) * sin(lambda12) - sin(phi12) * (cosPhi03 = cos(phi02)) * sin(lambda04)) / (cosPhi03 * cosPhi1 * sinLambda0Lambda1)) : (phi02 + phi12) / 2;
}
function clipAntimeridianInterpolate(from, to, direction, stream) {
  var phi2;
  if (from == null) {
    phi2 = direction * halfPi;
    stream.point(-pi, phi2);
    stream.point(0, phi2);
    stream.point(pi, phi2);
    stream.point(pi, 0);
    stream.point(pi, -phi2);
    stream.point(0, -phi2);
    stream.point(-pi, -phi2);
    stream.point(-pi, 0);
    stream.point(-pi, phi2);
  } else if (abs(from[0] - to[0]) > epsilon) {
    var lambda = from[0] < to[0] ? pi : -pi;
    phi2 = direction * lambda / 2;
    stream.point(-lambda, phi2);
    stream.point(0, phi2);
    stream.point(lambda, phi2);
  } else {
    stream.point(to[0], to[1]);
  }
}

// node_modules/d3-geo/src/clip/circle.js
function circle_default2(radius) {
  var cr = cos(radius), delta = 2 * radians, smallRadius = cr > 0, notHemisphere = abs(cr) > epsilon;
  function interpolate(from, to, direction, stream) {
    circleStream(stream, radius, delta, direction, from, to);
  }
  function visible(lambda, phi2) {
    return cos(lambda) * cos(phi2) > cr;
  }
  function clipLine(stream) {
    var point0, c0, v0, v00, clean;
    return {
      lineStart: function() {
        v00 = v0 = false;
        clean = 1;
      },
      point: function(lambda, phi2) {
        var point1 = [lambda, phi2], point2, v = visible(lambda, phi2), c2 = smallRadius ? v ? 0 : code(lambda, phi2) : v ? code(lambda + (lambda < 0 ? pi : -pi), phi2) : 0;
        if (!point0 && (v00 = v0 = v)) stream.lineStart();
        if (v !== v0) {
          point2 = intersect(point0, point1);
          if (!point2 || pointEqual_default(point0, point2) || pointEqual_default(point1, point2))
            point1[2] = 1;
        }
        if (v !== v0) {
          clean = 0;
          if (v) {
            stream.lineStart();
            point2 = intersect(point1, point0);
            stream.point(point2[0], point2[1]);
          } else {
            point2 = intersect(point0, point1);
            stream.point(point2[0], point2[1], 2);
            stream.lineEnd();
          }
          point0 = point2;
        } else if (notHemisphere && point0 && smallRadius ^ v) {
          var t;
          if (!(c2 & c0) && (t = intersect(point1, point0, true))) {
            clean = 0;
            if (smallRadius) {
              stream.lineStart();
              stream.point(t[0][0], t[0][1]);
              stream.point(t[1][0], t[1][1]);
              stream.lineEnd();
            } else {
              stream.point(t[1][0], t[1][1]);
              stream.lineEnd();
              stream.lineStart();
              stream.point(t[0][0], t[0][1], 3);
            }
          }
        }
        if (v && (!point0 || !pointEqual_default(point0, point1))) {
          stream.point(point1[0], point1[1]);
        }
        point0 = point1, v0 = v, c0 = c2;
      },
      lineEnd: function() {
        if (v0) stream.lineEnd();
        point0 = null;
      },
      // Rejoin first and last segments if there were intersections and the first
      // and last points were visible.
      clean: function() {
        return clean | (v00 && v0) << 1;
      }
    };
  }
  function intersect(a2, b, two) {
    var pa = cartesian(a2), pb = cartesian(b);
    var n1 = [1, 0, 0], n2 = cartesianCross(pa, pb), n2n2 = cartesianDot(n2, n2), n1n2 = n2[0], determinant = n2n2 - n1n2 * n1n2;
    if (!determinant) return !two && a2;
    var c1 = cr * n2n2 / determinant, c2 = -cr * n1n2 / determinant, n1xn2 = cartesianCross(n1, n2), A = cartesianScale(n1, c1), B = cartesianScale(n2, c2);
    cartesianAddInPlace(A, B);
    var u = n1xn2, w = cartesianDot(A, u), uu = cartesianDot(u, u), t2 = w * w - uu * (cartesianDot(A, A) - 1);
    if (t2 < 0) return;
    var t = sqrt(t2), q = cartesianScale(u, (-w - t) / uu);
    cartesianAddInPlace(q, A);
    q = spherical(q);
    if (!two) return q;
    var lambda04 = a2[0], lambda12 = b[0], phi02 = a2[1], phi12 = b[1], z;
    if (lambda12 < lambda04) z = lambda04, lambda04 = lambda12, lambda12 = z;
    var delta2 = lambda12 - lambda04, polar = abs(delta2 - pi) < epsilon, meridian = polar || delta2 < epsilon;
    if (!polar && phi12 < phi02) z = phi02, phi02 = phi12, phi12 = z;
    if (meridian ? polar ? phi02 + phi12 > 0 ^ q[1] < (abs(q[0] - lambda04) < epsilon ? phi02 : phi12) : phi02 <= q[1] && q[1] <= phi12 : delta2 > pi ^ (lambda04 <= q[0] && q[0] <= lambda12)) {
      var q1 = cartesianScale(u, (-w + t) / uu);
      cartesianAddInPlace(q1, A);
      return [q, spherical(q1)];
    }
  }
  function code(lambda, phi2) {
    var r = smallRadius ? radius : pi - radius, code2 = 0;
    if (lambda < -r) code2 |= 1;
    else if (lambda > r) code2 |= 2;
    if (phi2 < -r) code2 |= 4;
    else if (phi2 > r) code2 |= 8;
    return code2;
  }
  return clip_default(visible, clipLine, interpolate, smallRadius ? [0, -radius] : [-pi, radius - pi]);
}

// node_modules/d3-geo/src/clip/line.js
function line_default(a2, b, x06, y06, x12, y12) {
  var ax = a2[0], ay = a2[1], bx = b[0], by = b[1], t0 = 0, t1 = 1, dx = bx - ax, dy = by - ay, r;
  r = x06 - ax;
  if (!dx && r > 0) return;
  r /= dx;
  if (dx < 0) {
    if (r < t0) return;
    if (r < t1) t1 = r;
  } else if (dx > 0) {
    if (r > t1) return;
    if (r > t0) t0 = r;
  }
  r = x12 - ax;
  if (!dx && r < 0) return;
  r /= dx;
  if (dx < 0) {
    if (r > t1) return;
    if (r > t0) t0 = r;
  } else if (dx > 0) {
    if (r < t0) return;
    if (r < t1) t1 = r;
  }
  r = y06 - ay;
  if (!dy && r > 0) return;
  r /= dy;
  if (dy < 0) {
    if (r < t0) return;
    if (r < t1) t1 = r;
  } else if (dy > 0) {
    if (r > t1) return;
    if (r > t0) t0 = r;
  }
  r = y12 - ay;
  if (!dy && r < 0) return;
  r /= dy;
  if (dy < 0) {
    if (r > t1) return;
    if (r > t0) t0 = r;
  } else if (dy > 0) {
    if (r < t0) return;
    if (r < t1) t1 = r;
  }
  if (t0 > 0) a2[0] = ax + t0 * dx, a2[1] = ay + t0 * dy;
  if (t1 < 1) b[0] = ax + t1 * dx, b[1] = ay + t1 * dy;
  return true;
}

// node_modules/d3-geo/src/clip/rectangle.js
var clipMax = 1e9;
var clipMin = -clipMax;
function clipRectangle(x06, y06, x12, y12) {
  function visible(x, y) {
    return x06 <= x && x <= x12 && y06 <= y && y <= y12;
  }
  function interpolate(from, to, direction, stream) {
    var a2 = 0, a1 = 0;
    if (from == null || (a2 = corner(from, direction)) !== (a1 = corner(to, direction)) || comparePoint(from, to) < 0 ^ direction > 0) {
      do
        stream.point(a2 === 0 || a2 === 3 ? x06 : x12, a2 > 1 ? y12 : y06);
      while ((a2 = (a2 + direction + 4) % 4) !== a1);
    } else {
      stream.point(to[0], to[1]);
    }
  }
  function corner(p, direction) {
    return abs(p[0] - x06) < epsilon ? direction > 0 ? 0 : 3 : abs(p[0] - x12) < epsilon ? direction > 0 ? 2 : 1 : abs(p[1] - y06) < epsilon ? direction > 0 ? 1 : 0 : direction > 0 ? 3 : 2;
  }
  function compareIntersection2(a2, b) {
    return comparePoint(a2.x, b.x);
  }
  function comparePoint(a2, b) {
    var ca = corner(a2, 1), cb = corner(b, 1);
    return ca !== cb ? ca - cb : ca === 0 ? b[1] - a2[1] : ca === 1 ? a2[0] - b[0] : ca === 2 ? a2[1] - b[1] : b[0] - a2[0];
  }
  return function(stream) {
    var activeStream = stream, bufferStream = buffer_default(), segments, polygon, ring, x__, y__, v__, x_, y_, v_, first, clean;
    var clipStream = {
      point,
      lineStart,
      lineEnd,
      polygonStart,
      polygonEnd
    };
    function point(x, y) {
      if (visible(x, y)) activeStream.point(x, y);
    }
    function polygonInside() {
      var winding = 0;
      for (var i = 0, n = polygon.length; i < n; ++i) {
        for (var ring2 = polygon[i], j = 1, m2 = ring2.length, point2 = ring2[0], a0, a1, b0 = point2[0], b1 = point2[1]; j < m2; ++j) {
          a0 = b0, a1 = b1, point2 = ring2[j], b0 = point2[0], b1 = point2[1];
          if (a1 <= y12) {
            if (b1 > y12 && (b0 - a0) * (y12 - a1) > (b1 - a1) * (x06 - a0)) ++winding;
          } else {
            if (b1 <= y12 && (b0 - a0) * (y12 - a1) < (b1 - a1) * (x06 - a0)) --winding;
          }
        }
      }
      return winding;
    }
    function polygonStart() {
      activeStream = bufferStream, segments = [], polygon = [], clean = true;
    }
    function polygonEnd() {
      var startInside = polygonInside(), cleanInside = clean && startInside, visible2 = (segments = merge(segments)).length;
      if (cleanInside || visible2) {
        stream.polygonStart();
        if (cleanInside) {
          stream.lineStart();
          interpolate(null, null, 1, stream);
          stream.lineEnd();
        }
        if (visible2) {
          rejoin_default(segments, compareIntersection2, startInside, interpolate, stream);
        }
        stream.polygonEnd();
      }
      activeStream = stream, segments = polygon = ring = null;
    }
    function lineStart() {
      clipStream.point = linePoint2;
      if (polygon) polygon.push(ring = []);
      first = true;
      v_ = false;
      x_ = y_ = NaN;
    }
    function lineEnd() {
      if (segments) {
        linePoint2(x__, y__);
        if (v__ && v_) bufferStream.rejoin();
        segments.push(bufferStream.result());
      }
      clipStream.point = point;
      if (v_) activeStream.lineEnd();
    }
    function linePoint2(x, y) {
      var v = visible(x, y);
      if (polygon) ring.push([x, y]);
      if (first) {
        x__ = x, y__ = y, v__ = v;
        first = false;
        if (v) {
          activeStream.lineStart();
          activeStream.point(x, y);
        }
      } else {
        if (v && v_) activeStream.point(x, y);
        else {
          var a2 = [x_ = Math.max(clipMin, Math.min(clipMax, x_)), y_ = Math.max(clipMin, Math.min(clipMax, y_))], b = [x = Math.max(clipMin, Math.min(clipMax, x)), y = Math.max(clipMin, Math.min(clipMax, y))];
          if (line_default(a2, b, x06, y06, x12, y12)) {
            if (!v_) {
              activeStream.lineStart();
              activeStream.point(a2[0], a2[1]);
            }
            activeStream.point(b[0], b[1]);
            if (!v) activeStream.lineEnd();
            clean = false;
          } else if (v) {
            activeStream.lineStart();
            activeStream.point(x, y);
            clean = false;
          }
        }
      }
      x_ = x, y_ = y, v_ = v;
    }
    return clipStream;
  };
}

// node_modules/d3-geo/src/length.js
var lengthSum;
var lambda03;
var sinPhi02;
var cosPhi02;
var lengthStream = {
  sphere: noop,
  point: noop,
  lineStart: lengthLineStart,
  lineEnd: noop,
  polygonStart: noop,
  polygonEnd: noop
};
function lengthLineStart() {
  lengthStream.point = lengthPointFirst;
  lengthStream.lineEnd = lengthLineEnd;
}
function lengthLineEnd() {
  lengthStream.point = lengthStream.lineEnd = noop;
}
function lengthPointFirst(lambda, phi2) {
  lambda *= radians, phi2 *= radians;
  lambda03 = lambda, sinPhi02 = sin(phi2), cosPhi02 = cos(phi2);
  lengthStream.point = lengthPoint;
}
function lengthPoint(lambda, phi2) {
  lambda *= radians, phi2 *= radians;
  var sinPhi = sin(phi2), cosPhi = cos(phi2), delta = abs(lambda - lambda03), cosDelta = cos(delta), sinDelta = sin(delta), x = cosPhi * sinDelta, y = cosPhi02 * sinPhi - sinPhi02 * cosPhi * cosDelta, z = sinPhi02 * sinPhi + cosPhi02 * cosPhi * cosDelta;
  lengthSum.add(atan2(sqrt(x * x + y * y), z));
  lambda03 = lambda, sinPhi02 = sinPhi, cosPhi02 = cosPhi;
}
function length_default(object2) {
  lengthSum = new Adder();
  stream_default(object2, lengthStream);
  return +lengthSum;
}

// node_modules/d3-geo/src/distance.js
var coordinates = [null, null];
var object = { type: "LineString", coordinates };
function distance_default(a2, b) {
  coordinates[0] = a2;
  coordinates[1] = b;
  return length_default(object);
}

// node_modules/d3-geo/src/graticule.js
function graticuleX(y06, y12, dy) {
  var y = range(y06, y12 - epsilon, dy).concat(y12);
  return function(x) {
    return y.map(function(y2) {
      return [x, y2];
    });
  };
}
function graticuleY(x06, x12, dx) {
  var x = range(x06, x12 - epsilon, dx).concat(x12);
  return function(y) {
    return x.map(function(x2) {
      return [x2, y];
    });
  };
}
function graticule() {
  var x12, x06, X13, X03, y12, y06, Y13, Y03, dx = 10, dy = dx, DX = 90, DY = 360, x, y, X, Y, precision = 2.5;
  function graticule2() {
    return { type: "MultiLineString", coordinates: lines() };
  }
  function lines() {
    return range(ceil(X03 / DX) * DX, X13, DX).map(X).concat(range(ceil(Y03 / DY) * DY, Y13, DY).map(Y)).concat(range(ceil(x06 / dx) * dx, x12, dx).filter(function(x2) {
      return abs(x2 % DX) > epsilon;
    }).map(x)).concat(range(ceil(y06 / dy) * dy, y12, dy).filter(function(y2) {
      return abs(y2 % DY) > epsilon;
    }).map(y));
  }
  graticule2.lines = function() {
    return lines().map(function(coordinates2) {
      return { type: "LineString", coordinates: coordinates2 };
    });
  };
  graticule2.outline = function() {
    return {
      type: "Polygon",
      coordinates: [
        X(X03).concat(
          Y(Y13).slice(1),
          X(X13).reverse().slice(1),
          Y(Y03).reverse().slice(1)
        )
      ]
    };
  };
  graticule2.extent = function(_) {
    if (!arguments.length) return graticule2.extentMinor();
    return graticule2.extentMajor(_).extentMinor(_);
  };
  graticule2.extentMajor = function(_) {
    if (!arguments.length) return [[X03, Y03], [X13, Y13]];
    X03 = +_[0][0], X13 = +_[1][0];
    Y03 = +_[0][1], Y13 = +_[1][1];
    if (X03 > X13) _ = X03, X03 = X13, X13 = _;
    if (Y03 > Y13) _ = Y03, Y03 = Y13, Y13 = _;
    return graticule2.precision(precision);
  };
  graticule2.extentMinor = function(_) {
    if (!arguments.length) return [[x06, y06], [x12, y12]];
    x06 = +_[0][0], x12 = +_[1][0];
    y06 = +_[0][1], y12 = +_[1][1];
    if (x06 > x12) _ = x06, x06 = x12, x12 = _;
    if (y06 > y12) _ = y06, y06 = y12, y12 = _;
    return graticule2.precision(precision);
  };
  graticule2.step = function(_) {
    if (!arguments.length) return graticule2.stepMinor();
    return graticule2.stepMajor(_).stepMinor(_);
  };
  graticule2.stepMajor = function(_) {
    if (!arguments.length) return [DX, DY];
    DX = +_[0], DY = +_[1];
    return graticule2;
  };
  graticule2.stepMinor = function(_) {
    if (!arguments.length) return [dx, dy];
    dx = +_[0], dy = +_[1];
    return graticule2;
  };
  graticule2.precision = function(_) {
    if (!arguments.length) return precision;
    precision = +_;
    x = graticuleX(y06, y12, 90);
    y = graticuleY(x06, x12, precision);
    X = graticuleX(Y03, Y13, 90);
    Y = graticuleY(X03, X13, precision);
    return graticule2;
  };
  return graticule2.extentMajor([[-180, -90 + epsilon], [180, 90 - epsilon]]).extentMinor([[-180, -80 - epsilon], [180, 80 + epsilon]]);
}

// node_modules/d3-geo/src/interpolate.js
function interpolate_default(a2, b) {
  var x06 = a2[0] * radians, y06 = a2[1] * radians, x12 = b[0] * radians, y12 = b[1] * radians, cy0 = cos(y06), sy0 = sin(y06), cy1 = cos(y12), sy1 = sin(y12), kx0 = cy0 * cos(x06), ky0 = cy0 * sin(x06), kx1 = cy1 * cos(x12), ky1 = cy1 * sin(x12), d = 2 * asin(sqrt(haversin(y12 - y06) + cy0 * cy1 * haversin(x12 - x06))), k = sin(d);
  var interpolate = d ? function(t) {
    var B = sin(t *= d) / k, A = sin(d - t) / k, x = A * kx0 + B * kx1, y = A * ky0 + B * ky1, z = A * sy0 + B * sy1;
    return [
      atan2(y, x) * degrees,
      atan2(z, sqrt(x * x + y * y)) * degrees
    ];
  } : function() {
    return [x06 * degrees, y06 * degrees];
  };
  interpolate.distance = d;
  return interpolate;
}

// node_modules/d3-geo/src/identity.js
var identity_default = (x) => x;

// node_modules/d3-geo/src/path/area.js
var areaSum2 = new Adder();
var areaRingSum2 = new Adder();
var x00;
var y00;
var x02;
var y02;
var areaStream2 = {
  point: noop,
  lineStart: noop,
  lineEnd: noop,
  polygonStart: function() {
    areaStream2.lineStart = areaRingStart2;
    areaStream2.lineEnd = areaRingEnd2;
  },
  polygonEnd: function() {
    areaStream2.lineStart = areaStream2.lineEnd = areaStream2.point = noop;
    areaSum2.add(abs(areaRingSum2));
    areaRingSum2 = new Adder();
  },
  result: function() {
    var area = areaSum2 / 2;
    areaSum2 = new Adder();
    return area;
  }
};
function areaRingStart2() {
  areaStream2.point = areaPointFirst2;
}
function areaPointFirst2(x, y) {
  areaStream2.point = areaPoint2;
  x00 = x02 = x, y00 = y02 = y;
}
function areaPoint2(x, y) {
  areaRingSum2.add(y02 * x - x02 * y);
  x02 = x, y02 = y;
}
function areaRingEnd2() {
  areaPoint2(x00, y00);
}
var area_default2 = areaStream2;

// node_modules/d3-geo/src/path/bounds.js
var x03 = Infinity;
var y03 = x03;
var x1 = -x03;
var y1 = x1;
var boundsStream2 = {
  point: boundsPoint2,
  lineStart: noop,
  lineEnd: noop,
  polygonStart: noop,
  polygonEnd: noop,
  result: function() {
    var bounds = [[x03, y03], [x1, y1]];
    x1 = y1 = -(y03 = x03 = Infinity);
    return bounds;
  }
};
function boundsPoint2(x, y) {
  if (x < x03) x03 = x;
  if (x > x1) x1 = x;
  if (y < y03) y03 = y;
  if (y > y1) y1 = y;
}
var bounds_default2 = boundsStream2;

// node_modules/d3-geo/src/path/centroid.js
var X02 = 0;
var Y02 = 0;
var Z02 = 0;
var X12 = 0;
var Y12 = 0;
var Z12 = 0;
var X22 = 0;
var Y22 = 0;
var Z22 = 0;
var x002;
var y002;
var x04;
var y04;
var centroidStream2 = {
  point: centroidPoint2,
  lineStart: centroidLineStart2,
  lineEnd: centroidLineEnd2,
  polygonStart: function() {
    centroidStream2.lineStart = centroidRingStart2;
    centroidStream2.lineEnd = centroidRingEnd2;
  },
  polygonEnd: function() {
    centroidStream2.point = centroidPoint2;
    centroidStream2.lineStart = centroidLineStart2;
    centroidStream2.lineEnd = centroidLineEnd2;
  },
  result: function() {
    var centroid = Z22 ? [X22 / Z22, Y22 / Z22] : Z12 ? [X12 / Z12, Y12 / Z12] : Z02 ? [X02 / Z02, Y02 / Z02] : [NaN, NaN];
    X02 = Y02 = Z02 = X12 = Y12 = Z12 = X22 = Y22 = Z22 = 0;
    return centroid;
  }
};
function centroidPoint2(x, y) {
  X02 += x;
  Y02 += y;
  ++Z02;
}
function centroidLineStart2() {
  centroidStream2.point = centroidPointFirstLine;
}
function centroidPointFirstLine(x, y) {
  centroidStream2.point = centroidPointLine;
  centroidPoint2(x04 = x, y04 = y);
}
function centroidPointLine(x, y) {
  var dx = x - x04, dy = y - y04, z = sqrt(dx * dx + dy * dy);
  X12 += z * (x04 + x) / 2;
  Y12 += z * (y04 + y) / 2;
  Z12 += z;
  centroidPoint2(x04 = x, y04 = y);
}
function centroidLineEnd2() {
  centroidStream2.point = centroidPoint2;
}
function centroidRingStart2() {
  centroidStream2.point = centroidPointFirstRing;
}
function centroidRingEnd2() {
  centroidPointRing(x002, y002);
}
function centroidPointFirstRing(x, y) {
  centroidStream2.point = centroidPointRing;
  centroidPoint2(x002 = x04 = x, y002 = y04 = y);
}
function centroidPointRing(x, y) {
  var dx = x - x04, dy = y - y04, z = sqrt(dx * dx + dy * dy);
  X12 += z * (x04 + x) / 2;
  Y12 += z * (y04 + y) / 2;
  Z12 += z;
  z = y04 * x - x04 * y;
  X22 += z * (x04 + x);
  Y22 += z * (y04 + y);
  Z22 += z * 3;
  centroidPoint2(x04 = x, y04 = y);
}
var centroid_default2 = centroidStream2;

// node_modules/d3-geo/src/path/context.js
function PathContext(context) {
  this._context = context;
}
PathContext.prototype = {
  _radius: 4.5,
  pointRadius: function(_) {
    return this._radius = _, this;
  },
  polygonStart: function() {
    this._line = 0;
  },
  polygonEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._point = 0;
  },
  lineEnd: function() {
    if (this._line === 0) this._context.closePath();
    this._point = NaN;
  },
  point: function(x, y) {
    switch (this._point) {
      case 0: {
        this._context.moveTo(x, y);
        this._point = 1;
        break;
      }
      case 1: {
        this._context.lineTo(x, y);
        break;
      }
      default: {
        this._context.moveTo(x + this._radius, y);
        this._context.arc(x, y, this._radius, 0, tau);
        break;
      }
    }
  },
  result: noop
};

// node_modules/d3-geo/src/path/measure.js
var lengthSum2 = new Adder();
var lengthRing;
var x003;
var y003;
var x05;
var y05;
var lengthStream2 = {
  point: noop,
  lineStart: function() {
    lengthStream2.point = lengthPointFirst2;
  },
  lineEnd: function() {
    if (lengthRing) lengthPoint2(x003, y003);
    lengthStream2.point = noop;
  },
  polygonStart: function() {
    lengthRing = true;
  },
  polygonEnd: function() {
    lengthRing = null;
  },
  result: function() {
    var length = +lengthSum2;
    lengthSum2 = new Adder();
    return length;
  }
};
function lengthPointFirst2(x, y) {
  lengthStream2.point = lengthPoint2;
  x003 = x05 = x, y003 = y05 = y;
}
function lengthPoint2(x, y) {
  x05 -= x, y05 -= y;
  lengthSum2.add(sqrt(x05 * x05 + y05 * y05));
  x05 = x, y05 = y;
}
var measure_default = lengthStream2;

// node_modules/d3-geo/src/path/string.js
var cacheDigits;
var cacheAppend;
var cacheRadius;
var cacheCircle;
var PathString = class {
  constructor(digits) {
    this._append = digits == null ? append : appendRound(digits);
    this._radius = 4.5;
    this._ = "";
  }
  pointRadius(_) {
    this._radius = +_;
    return this;
  }
  polygonStart() {
    this._line = 0;
  }
  polygonEnd() {
    this._line = NaN;
  }
  lineStart() {
    this._point = 0;
  }
  lineEnd() {
    if (this._line === 0) this._ += "Z";
    this._point = NaN;
  }
  point(x, y) {
    switch (this._point) {
      case 0: {
        this._append`M${x},${y}`;
        this._point = 1;
        break;
      }
      case 1: {
        this._append`L${x},${y}`;
        break;
      }
      default: {
        this._append`M${x},${y}`;
        if (this._radius !== cacheRadius || this._append !== cacheAppend) {
          const r = this._radius;
          const s = this._;
          this._ = "";
          this._append`m0,${r}a${r},${r} 0 1,1 0,${-2 * r}a${r},${r} 0 1,1 0,${2 * r}z`;
          cacheRadius = r;
          cacheAppend = this._append;
          cacheCircle = this._;
          this._ = s;
        }
        this._ += cacheCircle;
        break;
      }
    }
  }
  result() {
    const result = this._;
    this._ = "";
    return result.length ? result : null;
  }
};
function append(strings) {
  let i = 1;
  this._ += strings[0];
  for (const j = strings.length; i < j; ++i) {
    this._ += arguments[i] + strings[i];
  }
}
function appendRound(digits) {
  const d = Math.floor(digits);
  if (!(d >= 0)) throw new RangeError(`invalid digits: ${digits}`);
  if (d > 15) return append;
  if (d !== cacheDigits) {
    const k = 10 ** d;
    cacheDigits = d;
    cacheAppend = function append2(strings) {
      let i = 1;
      this._ += strings[0];
      for (const j = strings.length; i < j; ++i) {
        this._ += Math.round(arguments[i] * k) / k + strings[i];
      }
    };
  }
  return cacheAppend;
}

// node_modules/d3-geo/src/path/index.js
function path_default(projection2, context) {
  let digits = 3, pointRadius = 4.5, projectionStream, contextStream;
  function path(object2) {
    if (object2) {
      if (typeof pointRadius === "function") contextStream.pointRadius(+pointRadius.apply(this, arguments));
      stream_default(object2, projectionStream(contextStream));
    }
    return contextStream.result();
  }
  path.area = function(object2) {
    stream_default(object2, projectionStream(area_default2));
    return area_default2.result();
  };
  path.measure = function(object2) {
    stream_default(object2, projectionStream(measure_default));
    return measure_default.result();
  };
  path.bounds = function(object2) {
    stream_default(object2, projectionStream(bounds_default2));
    return bounds_default2.result();
  };
  path.centroid = function(object2) {
    stream_default(object2, projectionStream(centroid_default2));
    return centroid_default2.result();
  };
  path.projection = function(_) {
    if (!arguments.length) return projection2;
    projectionStream = _ == null ? (projection2 = null, identity_default) : (projection2 = _).stream;
    return path;
  };
  path.context = function(_) {
    if (!arguments.length) return context;
    contextStream = _ == null ? (context = null, new PathString(digits)) : new PathContext(context = _);
    if (typeof pointRadius !== "function") contextStream.pointRadius(pointRadius);
    return path;
  };
  path.pointRadius = function(_) {
    if (!arguments.length) return pointRadius;
    pointRadius = typeof _ === "function" ? _ : (contextStream.pointRadius(+_), +_);
    return path;
  };
  path.digits = function(_) {
    if (!arguments.length) return digits;
    if (_ == null) digits = null;
    else {
      const d = Math.floor(_);
      if (!(d >= 0)) throw new RangeError(`invalid digits: ${_}`);
      digits = d;
    }
    if (context === null) contextStream = new PathString(digits);
    return path;
  };
  return path.projection(projection2).digits(digits).context(context);
}

// node_modules/d3-geo/src/transform.js
function transformer(methods) {
  return function(stream) {
    var s = new TransformStream();
    for (var key in methods) s[key] = methods[key];
    s.stream = stream;
    return s;
  };
}
function TransformStream() {
}
TransformStream.prototype = {
  constructor: TransformStream,
  point: function(x, y) {
    this.stream.point(x, y);
  },
  sphere: function() {
    this.stream.sphere();
  },
  lineStart: function() {
    this.stream.lineStart();
  },
  lineEnd: function() {
    this.stream.lineEnd();
  },
  polygonStart: function() {
    this.stream.polygonStart();
  },
  polygonEnd: function() {
    this.stream.polygonEnd();
  }
};

// node_modules/d3-geo/src/projection/fit.js
function fit(projection2, fitBounds, object2) {
  var clip = projection2.clipExtent && projection2.clipExtent();
  projection2.scale(150).translate([0, 0]);
  if (clip != null) projection2.clipExtent(null);
  stream_default(object2, projection2.stream(bounds_default2));
  fitBounds(bounds_default2.result());
  if (clip != null) projection2.clipExtent(clip);
  return projection2;
}
function fitExtent(projection2, extent2, object2) {
  return fit(projection2, function(b) {
    var w = extent2[1][0] - extent2[0][0], h = extent2[1][1] - extent2[0][1], k = Math.min(w / (b[1][0] - b[0][0]), h / (b[1][1] - b[0][1])), x = +extent2[0][0] + (w - k * (b[1][0] + b[0][0])) / 2, y = +extent2[0][1] + (h - k * (b[1][1] + b[0][1])) / 2;
    projection2.scale(150 * k).translate([x, y]);
  }, object2);
}
function fitSize(projection2, size, object2) {
  return fitExtent(projection2, [[0, 0], size], object2);
}
function fitWidth(projection2, width, object2) {
  return fit(projection2, function(b) {
    var w = +width, k = w / (b[1][0] - b[0][0]), x = (w - k * (b[1][0] + b[0][0])) / 2, y = -k * b[0][1];
    projection2.scale(150 * k).translate([x, y]);
  }, object2);
}
function fitHeight(projection2, height, object2) {
  return fit(projection2, function(b) {
    var h = +height, k = h / (b[1][1] - b[0][1]), x = -k * b[0][0], y = (h - k * (b[1][1] + b[0][1])) / 2;
    projection2.scale(150 * k).translate([x, y]);
  }, object2);
}

// node_modules/d3-geo/src/projection/resample.js
var maxDepth = 16;
var cosMinDistance = cos(30 * radians);
function resample_default(project, delta2) {
  return +delta2 ? resample(project, delta2) : resampleNone(project);
}
function resampleNone(project) {
  return transformer({
    point: function(x, y) {
      x = project(x, y);
      this.stream.point(x[0], x[1]);
    }
  });
}
function resample(project, delta2) {
  function resampleLineTo(x06, y06, lambda04, a0, b0, c0, x12, y12, lambda12, a1, b1, c1, depth, stream) {
    var dx = x12 - x06, dy = y12 - y06, d2 = dx * dx + dy * dy;
    if (d2 > 4 * delta2 && depth--) {
      var a2 = a0 + a1, b = b0 + b1, c2 = c0 + c1, m2 = sqrt(a2 * a2 + b * b + c2 * c2), phi2 = asin(c2 /= m2), lambda22 = abs(abs(c2) - 1) < epsilon || abs(lambda04 - lambda12) < epsilon ? (lambda04 + lambda12) / 2 : atan2(b, a2), p = project(lambda22, phi2), x2 = p[0], y2 = p[1], dx2 = x2 - x06, dy2 = y2 - y06, dz = dy * dx2 - dx * dy2;
      if (dz * dz / d2 > delta2 || abs((dx * dx2 + dy * dy2) / d2 - 0.5) > 0.3 || a0 * a1 + b0 * b1 + c0 * c1 < cosMinDistance) {
        resampleLineTo(x06, y06, lambda04, a0, b0, c0, x2, y2, lambda22, a2 /= m2, b /= m2, c2, depth, stream);
        stream.point(x2, y2);
        resampleLineTo(x2, y2, lambda22, a2, b, c2, x12, y12, lambda12, a1, b1, c1, depth, stream);
      }
    }
  }
  return function(stream) {
    var lambda004, x004, y004, a00, b00, c00, lambda04, x06, y06, a0, b0, c0;
    var resampleStream = {
      point,
      lineStart,
      lineEnd,
      polygonStart: function() {
        stream.polygonStart();
        resampleStream.lineStart = ringStart;
      },
      polygonEnd: function() {
        stream.polygonEnd();
        resampleStream.lineStart = lineStart;
      }
    };
    function point(x, y) {
      x = project(x, y);
      stream.point(x[0], x[1]);
    }
    function lineStart() {
      x06 = NaN;
      resampleStream.point = linePoint2;
      stream.lineStart();
    }
    function linePoint2(lambda, phi2) {
      var c2 = cartesian([lambda, phi2]), p = project(lambda, phi2);
      resampleLineTo(x06, y06, lambda04, a0, b0, c0, x06 = p[0], y06 = p[1], lambda04 = lambda, a0 = c2[0], b0 = c2[1], c0 = c2[2], maxDepth, stream);
      stream.point(x06, y06);
    }
    function lineEnd() {
      resampleStream.point = point;
      stream.lineEnd();
    }
    function ringStart() {
      lineStart();
      resampleStream.point = ringPoint;
      resampleStream.lineEnd = ringEnd;
    }
    function ringPoint(lambda, phi2) {
      linePoint2(lambda004 = lambda, phi2), x004 = x06, y004 = y06, a00 = a0, b00 = b0, c00 = c0;
      resampleStream.point = linePoint2;
    }
    function ringEnd() {
      resampleLineTo(x06, y06, lambda04, a0, b0, c0, x004, y004, lambda004, a00, b00, c00, maxDepth, stream);
      resampleStream.lineEnd = lineEnd;
      lineEnd();
    }
    return resampleStream;
  };
}

// node_modules/d3-geo/src/projection/index.js
var transformRadians = transformer({
  point: function(x, y) {
    this.stream.point(x * radians, y * radians);
  }
});
function transformRotate(rotate) {
  return transformer({
    point: function(x, y) {
      var r = rotate(x, y);
      return this.stream.point(r[0], r[1]);
    }
  });
}
function scaleTranslate(k, dx, dy, sx, sy) {
  function transform(x, y) {
    x *= sx;
    y *= sy;
    return [dx + k * x, dy - k * y];
  }
  transform.invert = function(x, y) {
    return [(x - dx) / k * sx, (dy - y) / k * sy];
  };
  return transform;
}
function scaleTranslateRotate(k, dx, dy, sx, sy, alpha) {
  if (!alpha) return scaleTranslate(k, dx, dy, sx, sy);
  var cosAlpha = cos(alpha), sinAlpha = sin(alpha), a2 = cosAlpha * k, b = sinAlpha * k, ai = cosAlpha / k, bi = sinAlpha / k, ci = (sinAlpha * dy - cosAlpha * dx) / k, fi = (sinAlpha * dx + cosAlpha * dy) / k;
  function transform(x, y) {
    x *= sx;
    y *= sy;
    return [a2 * x - b * y + dx, dy - b * x - a2 * y];
  }
  transform.invert = function(x, y) {
    return [sx * (ai * x - bi * y + ci), sy * (fi - bi * x - ai * y)];
  };
  return transform;
}
function projection(project) {
  return projectionMutator(function() {
    return project;
  })();
}
function projectionMutator(projectAt) {
  var project, k = 150, x = 480, y = 250, lambda = 0, phi2 = 0, deltaLambda = 0, deltaPhi = 0, deltaGamma = 0, rotate, alpha = 0, sx = 1, sy = 1, theta = null, preclip = antimeridian_default, x06 = null, y06, x12, y12, postclip = identity_default, delta2 = 0.5, projectResample, projectTransform, projectRotateTransform, cache, cacheStream;
  function projection2(point) {
    return projectRotateTransform(point[0] * radians, point[1] * radians);
  }
  function invert(point) {
    point = projectRotateTransform.invert(point[0], point[1]);
    return point && [point[0] * degrees, point[1] * degrees];
  }
  projection2.stream = function(stream) {
    return cache && cacheStream === stream ? cache : cache = transformRadians(transformRotate(rotate)(preclip(projectResample(postclip(cacheStream = stream)))));
  };
  projection2.preclip = function(_) {
    return arguments.length ? (preclip = _, theta = void 0, reset()) : preclip;
  };
  projection2.postclip = function(_) {
    return arguments.length ? (postclip = _, x06 = y06 = x12 = y12 = null, reset()) : postclip;
  };
  projection2.clipAngle = function(_) {
    return arguments.length ? (preclip = +_ ? circle_default2(theta = _ * radians) : (theta = null, antimeridian_default), reset()) : theta * degrees;
  };
  projection2.clipExtent = function(_) {
    return arguments.length ? (postclip = _ == null ? (x06 = y06 = x12 = y12 = null, identity_default) : clipRectangle(x06 = +_[0][0], y06 = +_[0][1], x12 = +_[1][0], y12 = +_[1][1]), reset()) : x06 == null ? null : [[x06, y06], [x12, y12]];
  };
  projection2.scale = function(_) {
    return arguments.length ? (k = +_, recenter()) : k;
  };
  projection2.translate = function(_) {
    return arguments.length ? (x = +_[0], y = +_[1], recenter()) : [x, y];
  };
  projection2.center = function(_) {
    return arguments.length ? (lambda = _[0] % 360 * radians, phi2 = _[1] % 360 * radians, recenter()) : [lambda * degrees, phi2 * degrees];
  };
  projection2.rotate = function(_) {
    return arguments.length ? (deltaLambda = _[0] % 360 * radians, deltaPhi = _[1] % 360 * radians, deltaGamma = _.length > 2 ? _[2] % 360 * radians : 0, recenter()) : [deltaLambda * degrees, deltaPhi * degrees, deltaGamma * degrees];
  };
  projection2.angle = function(_) {
    return arguments.length ? (alpha = _ % 360 * radians, recenter()) : alpha * degrees;
  };
  projection2.reflectX = function(_) {
    return arguments.length ? (sx = _ ? -1 : 1, recenter()) : sx < 0;
  };
  projection2.reflectY = function(_) {
    return arguments.length ? (sy = _ ? -1 : 1, recenter()) : sy < 0;
  };
  projection2.precision = function(_) {
    return arguments.length ? (projectResample = resample_default(projectTransform, delta2 = _ * _), reset()) : sqrt(delta2);
  };
  projection2.fitExtent = function(extent2, object2) {
    return fitExtent(projection2, extent2, object2);
  };
  projection2.fitSize = function(size, object2) {
    return fitSize(projection2, size, object2);
  };
  projection2.fitWidth = function(width, object2) {
    return fitWidth(projection2, width, object2);
  };
  projection2.fitHeight = function(height, object2) {
    return fitHeight(projection2, height, object2);
  };
  function recenter() {
    var center = scaleTranslateRotate(k, 0, 0, sx, sy, alpha).apply(null, project(lambda, phi2)), transform = scaleTranslateRotate(k, x - center[0], y - center[1], sx, sy, alpha);
    rotate = rotateRadians(deltaLambda, deltaPhi, deltaGamma);
    projectTransform = compose_default(project, transform);
    projectRotateTransform = compose_default(rotate, projectTransform);
    projectResample = resample_default(projectTransform, delta2);
    return reset();
  }
  function reset() {
    cache = cacheStream = null;
    return projection2;
  }
  return function() {
    project = projectAt.apply(this, arguments);
    projection2.invert = project.invert && invert;
    return recenter();
  };
}

// node_modules/d3-geo/src/projection/conic.js
function conicProjection(projectAt) {
  var phi02 = 0, phi12 = pi / 3, m2 = projectionMutator(projectAt), p = m2(phi02, phi12);
  p.parallels = function(_) {
    return arguments.length ? m2(phi02 = _[0] * radians, phi12 = _[1] * radians) : [phi02 * degrees, phi12 * degrees];
  };
  return p;
}

// node_modules/d3-geo/src/projection/cylindricalEqualArea.js
function cylindricalEqualAreaRaw(phi02) {
  var cosPhi03 = cos(phi02);
  function forward(lambda, phi2) {
    return [lambda * cosPhi03, sin(phi2) / cosPhi03];
  }
  forward.invert = function(x, y) {
    return [x / cosPhi03, asin(y * cosPhi03)];
  };
  return forward;
}

// node_modules/d3-geo/src/projection/conicEqualArea.js
function conicEqualAreaRaw(y06, y12) {
  var sy0 = sin(y06), n = (sy0 + sin(y12)) / 2;
  if (abs(n) < epsilon) return cylindricalEqualAreaRaw(y06);
  var c2 = 1 + sy0 * (2 * n - sy0), r0 = sqrt(c2) / n;
  function project(x, y) {
    var r = sqrt(c2 - 2 * n * sin(y)) / n;
    return [r * sin(x *= n), r0 - r * cos(x)];
  }
  project.invert = function(x, y) {
    var r0y = r0 - y, l = atan2(x, abs(r0y)) * sign(r0y);
    if (r0y * n < 0)
      l -= pi * sign(x) * sign(r0y);
    return [l / n, asin((c2 - (x * x + r0y * r0y) * n * n) / (2 * n))];
  };
  return project;
}
function conicEqualArea_default() {
  return conicProjection(conicEqualAreaRaw).scale(155.424).center([0, 33.6442]);
}

// node_modules/d3-geo/src/projection/albers.js
function albers_default() {
  return conicEqualArea_default().parallels([29.5, 45.5]).scale(1070).translate([480, 250]).rotate([96, 0]).center([-0.6, 38.7]);
}

// node_modules/d3-geo/src/projection/albersUsa.js
function multiplex(streams) {
  var n = streams.length;
  return {
    point: function(x, y) {
      var i = -1;
      while (++i < n) streams[i].point(x, y);
    },
    sphere: function() {
      var i = -1;
      while (++i < n) streams[i].sphere();
    },
    lineStart: function() {
      var i = -1;
      while (++i < n) streams[i].lineStart();
    },
    lineEnd: function() {
      var i = -1;
      while (++i < n) streams[i].lineEnd();
    },
    polygonStart: function() {
      var i = -1;
      while (++i < n) streams[i].polygonStart();
    },
    polygonEnd: function() {
      var i = -1;
      while (++i < n) streams[i].polygonEnd();
    }
  };
}
function albersUsa_default() {
  var cache, cacheStream, lower48 = albers_default(), lower48Point, alaska = conicEqualArea_default().rotate([154, 0]).center([-2, 58.5]).parallels([55, 65]), alaskaPoint, hawaii = conicEqualArea_default().rotate([157, 0]).center([-3, 19.9]).parallels([8, 18]), hawaiiPoint, point, pointStream = { point: function(x, y) {
    point = [x, y];
  } };
  function albersUsa(coordinates2) {
    var x = coordinates2[0], y = coordinates2[1];
    return point = null, (lower48Point.point(x, y), point) || (alaskaPoint.point(x, y), point) || (hawaiiPoint.point(x, y), point);
  }
  albersUsa.invert = function(coordinates2) {
    var k = lower48.scale(), t = lower48.translate(), x = (coordinates2[0] - t[0]) / k, y = (coordinates2[1] - t[1]) / k;
    return (y >= 0.12 && y < 0.234 && x >= -0.425 && x < -0.214 ? alaska : y >= 0.166 && y < 0.234 && x >= -0.214 && x < -0.115 ? hawaii : lower48).invert(coordinates2);
  };
  albersUsa.stream = function(stream) {
    return cache && cacheStream === stream ? cache : cache = multiplex([lower48.stream(cacheStream = stream), alaska.stream(stream), hawaii.stream(stream)]);
  };
  albersUsa.precision = function(_) {
    if (!arguments.length) return lower48.precision();
    lower48.precision(_), alaska.precision(_), hawaii.precision(_);
    return reset();
  };
  albersUsa.scale = function(_) {
    if (!arguments.length) return lower48.scale();
    lower48.scale(_), alaska.scale(_ * 0.35), hawaii.scale(_);
    return albersUsa.translate(lower48.translate());
  };
  albersUsa.translate = function(_) {
    if (!arguments.length) return lower48.translate();
    var k = lower48.scale(), x = +_[0], y = +_[1];
    lower48Point = lower48.translate(_).clipExtent([[x - 0.455 * k, y - 0.238 * k], [x + 0.455 * k, y + 0.238 * k]]).stream(pointStream);
    alaskaPoint = alaska.translate([x - 0.307 * k, y + 0.201 * k]).clipExtent([[x - 0.425 * k + epsilon, y + 0.12 * k + epsilon], [x - 0.214 * k - epsilon, y + 0.234 * k - epsilon]]).stream(pointStream);
    hawaiiPoint = hawaii.translate([x - 0.205 * k, y + 0.212 * k]).clipExtent([[x - 0.214 * k + epsilon, y + 0.166 * k + epsilon], [x - 0.115 * k - epsilon, y + 0.234 * k - epsilon]]).stream(pointStream);
    return reset();
  };
  albersUsa.fitExtent = function(extent2, object2) {
    return fitExtent(albersUsa, extent2, object2);
  };
  albersUsa.fitSize = function(size, object2) {
    return fitSize(albersUsa, size, object2);
  };
  albersUsa.fitWidth = function(width, object2) {
    return fitWidth(albersUsa, width, object2);
  };
  albersUsa.fitHeight = function(height, object2) {
    return fitHeight(albersUsa, height, object2);
  };
  function reset() {
    cache = cacheStream = null;
    return albersUsa;
  }
  return albersUsa.scale(1070);
}

// node_modules/d3-geo/src/projection/azimuthal.js
function azimuthalRaw(scale) {
  return function(x, y) {
    var cx = cos(x), cy = cos(y), k = scale(cx * cy);
    if (k === Infinity) return [2, 0];
    return [
      k * cy * sin(x),
      k * sin(y)
    ];
  };
}
function azimuthalInvert(angle2) {
  return function(x, y) {
    var z = sqrt(x * x + y * y), c2 = angle2(z), sc = sin(c2), cc = cos(c2);
    return [
      atan2(x * sc, z * cc),
      asin(z && y * sc / z)
    ];
  };
}

// node_modules/d3-geo/src/projection/azimuthalEqualArea.js
var azimuthalEqualAreaRaw = azimuthalRaw(function(cxcy) {
  return sqrt(2 / (1 + cxcy));
});
azimuthalEqualAreaRaw.invert = azimuthalInvert(function(z) {
  return 2 * asin(z / 2);
});

// node_modules/d3-geo/src/projection/azimuthalEquidistant.js
var azimuthalEquidistantRaw = azimuthalRaw(function(c2) {
  return (c2 = acos(c2)) && c2 / sin(c2);
});
azimuthalEquidistantRaw.invert = azimuthalInvert(function(z) {
  return z;
});

// node_modules/d3-geo/src/projection/mercator.js
function mercatorRaw(lambda, phi2) {
  return [lambda, log(tan((halfPi + phi2) / 2))];
}
mercatorRaw.invert = function(x, y) {
  return [x, 2 * atan(exp(y)) - halfPi];
};
function mercator_default() {
  return mercatorProjection(mercatorRaw).scale(961 / tau);
}
function mercatorProjection(project) {
  var m2 = projection(project), center = m2.center, scale = m2.scale, translate = m2.translate, clipExtent = m2.clipExtent, x06 = null, y06, x12, y12;
  m2.scale = function(_) {
    return arguments.length ? (scale(_), reclip()) : scale();
  };
  m2.translate = function(_) {
    return arguments.length ? (translate(_), reclip()) : translate();
  };
  m2.center = function(_) {
    return arguments.length ? (center(_), reclip()) : center();
  };
  m2.clipExtent = function(_) {
    return arguments.length ? (_ == null ? x06 = y06 = x12 = y12 = null : (x06 = +_[0][0], y06 = +_[0][1], x12 = +_[1][0], y12 = +_[1][1]), reclip()) : x06 == null ? null : [[x06, y06], [x12, y12]];
  };
  function reclip() {
    var k = pi * scale(), t = m2(rotation_default(m2.rotate()).invert([0, 0]));
    return clipExtent(x06 == null ? [[t[0] - k, t[1] - k], [t[0] + k, t[1] + k]] : project === mercatorRaw ? [[Math.max(t[0] - k, x06), y06], [Math.min(t[0] + k, x12), y12]] : [[x06, Math.max(t[1] - k, y06)], [x12, Math.min(t[1] + k, y12)]]);
  }
  return reclip();
}

// node_modules/d3-geo/src/projection/equirectangular.js
function equirectangularRaw(lambda, phi2) {
  return [lambda, phi2];
}
equirectangularRaw.invert = equirectangularRaw;
function equirectangular_default() {
  return projection(equirectangularRaw).scale(152.63);
}

// node_modules/d3-geo/src/projection/equalEarth.js
var A1 = 1.340264;
var A2 = -0.081106;
var A3 = 893e-6;
var A4 = 3796e-6;
var M = sqrt(3) / 2;
var iterations = 12;
function equalEarthRaw(lambda, phi2) {
  var l = asin(M * sin(phi2)), l2 = l * l, l6 = l2 * l2 * l2;
  return [
    lambda * cos(l) / (M * (A1 + 3 * A2 * l2 + l6 * (7 * A3 + 9 * A4 * l2))),
    l * (A1 + A2 * l2 + l6 * (A3 + A4 * l2))
  ];
}
equalEarthRaw.invert = function(x, y) {
  var l = y, l2 = l * l, l6 = l2 * l2 * l2;
  for (var i = 0, delta, fy, fpy; i < iterations; ++i) {
    fy = l * (A1 + A2 * l2 + l6 * (A3 + A4 * l2)) - y;
    fpy = A1 + 3 * A2 * l2 + l6 * (7 * A3 + 9 * A4 * l2);
    l -= delta = fy / fpy, l2 = l * l, l6 = l2 * l2 * l2;
    if (abs(delta) < epsilon2) break;
  }
  return [
    M * x * (A1 + 3 * A2 * l2 + l6 * (7 * A3 + 9 * A4 * l2)) / cos(l),
    asin(sin(l) / M)
  ];
};
function equalEarth_default() {
  return projection(equalEarthRaw).scale(177.158);
}

// node_modules/d3-geo/src/projection/gnomonic.js
function gnomonicRaw(x, y) {
  var cy = cos(y), k = cos(x) * cy;
  return [cy * sin(x) / k, sin(y) / k];
}
gnomonicRaw.invert = azimuthalInvert(atan);

// node_modules/d3-geo/src/projection/naturalEarth1.js
function naturalEarth1Raw(lambda, phi2) {
  var phi22 = phi2 * phi2, phi4 = phi22 * phi22;
  return [
    lambda * (0.8707 - 0.131979 * phi22 + phi4 * (-0.013791 + phi4 * (3971e-6 * phi22 - 1529e-6 * phi4))),
    phi2 * (1.007226 + phi22 * (0.015085 + phi4 * (-0.044475 + 0.028874 * phi22 - 5916e-6 * phi4)))
  ];
}
naturalEarth1Raw.invert = function(x, y) {
  var phi2 = y, i = 25, delta;
  do {
    var phi22 = phi2 * phi2, phi4 = phi22 * phi22;
    phi2 -= delta = (phi2 * (1.007226 + phi22 * (0.015085 + phi4 * (-0.044475 + 0.028874 * phi22 - 5916e-6 * phi4))) - y) / (1.007226 + phi22 * (0.015085 * 3 + phi4 * (-0.044475 * 7 + 0.028874 * 9 * phi22 - 5916e-6 * 11 * phi4)));
  } while (abs(delta) > epsilon && --i > 0);
  return [
    x / (0.8707 + (phi22 = phi2 * phi2) * (-0.131979 + phi22 * (-0.013791 + phi22 * phi22 * phi22 * (3971e-6 - 1529e-6 * phi22)))),
    phi2
  ];
};
function naturalEarth1_default() {
  return projection(naturalEarth1Raw).scale(175.295);
}

// node_modules/d3-geo/src/projection/orthographic.js
function orthographicRaw(x, y) {
  return [cos(y) * sin(x), sin(y)];
}
orthographicRaw.invert = azimuthalInvert(asin);
function orthographic_default() {
  return projection(orthographicRaw).scale(249.5).clipAngle(90 + epsilon);
}

// node_modules/d3-geo/src/projection/stereographic.js
function stereographicRaw(x, y) {
  var cy = cos(y), k = 1 + cos(x) * cy;
  return [cy * sin(x) / k, sin(y) / k];
}
stereographicRaw.invert = azimuthalInvert(function(z) {
  return 2 * atan(z);
});

// node_modules/d3-geo/src/projection/transverseMercator.js
function transverseMercatorRaw(lambda, phi2) {
  return [log(tan((halfPi + phi2) / 2)), -lambda];
}
transverseMercatorRaw.invert = function(x, y) {
  return [-y, 2 * atan(exp(x)) - halfPi];
};

// node_modules/@amcharts/amcharts5/.internal/charts/map/MapLine.js
var MapLine = class extends Graphics {
  constructor() {
    super(...arguments);
    Object.defineProperty(this, "_projectionDirty", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: false
    });
  }
  _beforeChanged() {
    super._beforeChanged();
    if (this._projectionDirty || this.isDirty("geometry") || this.isDirty("precision")) {
      const geometry = this.get("geometry");
      if (geometry) {
        const series = this.getPrivate("series");
        if (series) {
          const chart = series.chart;
          if (chart) {
            const projection2 = chart.get("projection");
            let clipAngle = null;
            if (projection2 && projection2.clipAngle) {
              clipAngle = projection2.clipAngle();
              projection2.precision(this.get("precision", 0.5));
            }
            const dataItem = this.dataItem;
            const geoPath = chart.getPrivate("geoPath");
            if (geoPath && dataItem) {
              this._clear = true;
              if (dataItem.get("lineType", series.get("lineType")) == "straight") {
                const geometry2 = this.get("geometry");
                if (geometry2) {
                  let coordinates2 = geometry2.coordinates;
                  if (coordinates2) {
                    let segments;
                    if (geometry2.type == "LineString") {
                      segments = [coordinates2];
                    } else if (geometry2.type == "MultiLineString") {
                      segments = coordinates2;
                    }
                    this.set("draw", (display) => {
                      for (let s = 0; s < segments.length; s++) {
                        let segment = segments[s];
                        if (segment.length > 0) {
                          const gp0 = segment[0];
                          const p02 = chart.convert({ longitude: gp0[0], latitude: gp0[1] });
                          display.lineTo(p02.x, p02.y);
                          for (let p = 0; p < segment.length; p++) {
                            const gp = segment[p];
                            const pn = chart.convert({ longitude: gp[0], latitude: gp[1] });
                            display.lineTo(pn.x, pn.y);
                          }
                        }
                      }
                    });
                  }
                }
              } else {
                this.set("draw", (_display) => {
                  if (projection2 && series.get("clipBack") === false) {
                    projection2.clipAngle(180);
                  }
                  geoPath.context(this._display);
                  geoPath(geometry);
                  geoPath.context(null);
                  if (projection2 && projection2.clipAngle) {
                    projection2.clipAngle(clipAngle);
                  }
                });
              }
            }
          }
        }
      }
      const type = "linechanged";
      if (this.events.isEnabled(type)) {
        this.events.dispatch(type, { type, target: this });
      }
    }
  }
  /**
   * @ignore
   */
  markDirtyProjection() {
    this.markDirty();
    this._projectionDirty = true;
  }
  _clearDirty() {
    super._clearDirty();
    this._projectionDirty = false;
  }
  _getTooltipPoint() {
    let tooltipX = this.get("tooltipX");
    let tooltipY = this.get("tooltipY");
    let x = 0;
    let y = 0;
    if (isNumber(tooltipX)) {
      x = tooltipX;
    }
    if (isNumber(tooltipY)) {
      y = tooltipY;
    }
    if (tooltipX instanceof Percent) {
      const geoPoint = this.positionToGeoPoint(tooltipX.value);
      const series = this.getPrivate("series");
      if (series) {
        const chart = series.chart;
        if (chart) {
          const point = chart.convert(geoPoint);
          x = point.x;
          y = point.y;
        }
      }
    }
    return { x, y };
  }
  /**
   * Converts relative position along the line (0-1) into pixel coordinates.
   *
   * @param position  Position (0-1)
   * @return Coordinates
   */
  positionToGeoPoint(position) {
    const geometry = this.get("geometry");
    const series = this.getPrivate("series");
    const chart = series.chart;
    const dataItem = this.dataItem;
    if (geometry && series && chart && dataItem) {
      const lineType = dataItem.get("lineType", series.get("lineType"));
      let totalDistance = length_default(geometry);
      let currentDistance = 0;
      let distanceAB;
      let positionA = 0;
      let positionB = 0;
      let pointA;
      let pointB;
      let coordinates2 = geometry.coordinates;
      if (coordinates2) {
        let segments;
        if (geometry.type == "LineString") {
          segments = [coordinates2];
        } else if (geometry.type == "MultiLineString") {
          segments = coordinates2;
        }
        for (let s = 0; s < segments.length; s++) {
          let segment = segments[s];
          if (segment.length > 1) {
            for (let p = 1; p < segment.length; p++) {
              pointA = segment[p - 1];
              pointB = segment[p];
              positionA = currentDistance / totalDistance;
              distanceAB = distance_default(pointA, pointB);
              currentDistance += distanceAB;
              positionB = currentDistance / totalDistance;
              if (positionA <= position && positionB > position) {
                s = segments.length;
                break;
              }
            }
          } else if (segment.length == 1) {
            pointA = segment[0];
            pointB = segment[0];
            positionA = 0;
            positionB = 1;
          }
        }
        if (pointA && pointB) {
          let positionAB = (position - positionA) / (positionB - positionA);
          let location2;
          if (lineType == "straight") {
            let p02 = chart.convert({ longitude: pointA[0], latitude: pointA[1] });
            let p1 = chart.convert({ longitude: pointB[0], latitude: pointB[1] });
            let x = p02.x + (p1.x - p02.x) * positionAB;
            let y = p02.y + (p1.y - p02.y) * positionAB;
            return chart.invert({ x, y });
          } else {
            location2 = interpolate_default(pointA, pointB)(positionAB);
            return { longitude: location2[0], latitude: location2[1] };
          }
        }
      }
    }
    return { longitude: 0, latitude: 0 };
  }
};
Object.defineProperty(MapLine, "className", {
  enumerable: true,
  configurable: true,
  writable: true,
  value: "MapLine"
});
Object.defineProperty(MapLine, "classNames", {
  enumerable: true,
  configurable: true,
  writable: true,
  value: Graphics.classNames.concat([MapLine.className])
});

// node_modules/@amcharts/amcharts5/.internal/charts/map/MapLineSeries.js
var MapLineSeries = class extends MapSeries {
  constructor() {
    super(...arguments);
    Object.defineProperty(this, "mapLines", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: this.addDisposer(new ListTemplate(Template.new({}), () => MapLine._new(this._root, {}, [this.mapLines.template])))
    });
    Object.defineProperty(this, "_types", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: ["LineString", "MultiLineString"]
    });
  }
  _afterNew() {
    this.fields.push("lineType");
    this._setRawDefault("lineTypeField", "lineType");
    super._afterNew();
  }
  /**
   * @ignore
   */
  makeMapLine(dataItem) {
    const mapLine = this.children.push(this.mapLines.make());
    mapLine._setDataItem(dataItem);
    this.mapLines.push(mapLine);
    return mapLine;
  }
  /**
   * @ignore
   */
  markDirtyProjection() {
    each(this.dataItems, (dataItem) => {
      let mapLine = dataItem.get("mapLine");
      if (mapLine) {
        mapLine.markDirtyProjection();
      }
    });
  }
  _prepareChildren() {
    super._prepareChildren();
    if (this.isDirty("stroke")) {
      this.mapLines.template.set("stroke", this.get("stroke"));
    }
  }
  processDataItem(dataItem) {
    super.processDataItem(dataItem);
    let mapLine = dataItem.get("mapLine");
    if (!mapLine) {
      mapLine = this.makeMapLine(dataItem);
    }
    this._handlePointsToConnect(dataItem);
    dataItem.on("pointsToConnect", () => {
      this._handlePointsToConnect(dataItem);
    });
    dataItem.set("mapLine", mapLine);
    this._addGeometry(dataItem.get("geometry"), this);
    mapLine.setPrivate("series", this);
  }
  _handlePointsToConnect(dataItem) {
    const pointsToConnect = dataItem.get("pointsToConnect");
    if (pointsToConnect) {
      each(pointsToConnect, (point) => {
        point.on("geometry", () => {
          this.markDirtyValues(dataItem);
        });
        point.on("longitude", () => {
          this.markDirtyValues(dataItem);
        });
        point.on("latitude", () => {
          this.markDirtyValues(dataItem);
        });
      });
      this.markDirtyValues(dataItem);
    }
  }
  /**
   * Forces a repaint of the element which relies on data.
   *
   * @since 5.0.21
   */
  markDirtyValues(dataItem) {
    super.markDirtyValues();
    if (dataItem) {
      const mapLine = dataItem.get("mapLine");
      if (mapLine) {
        const pointsToConnect = dataItem.get("pointsToConnect");
        if (pointsToConnect) {
          let coordinates2 = [];
          each(pointsToConnect, (point) => {
            const longitude2 = point.get("longitude");
            const latitude = point.get("latitude");
            if (longitude2 != null && latitude != null) {
              coordinates2.push([longitude2, latitude]);
            } else {
              const geometry2 = point.get("geometry");
              if (geometry2) {
                const coords = geometry2.coordinates;
                if (coords) {
                  coordinates2.push([coords[0], coords[1]]);
                }
              }
            }
          });
          let geometry = { type: "LineString", coordinates: coordinates2 };
          dataItem.setRaw("geometry", geometry);
          mapLine.set("geometry", geometry);
        } else {
          mapLine.set("geometry", dataItem.get("geometry"));
        }
      }
    }
  }
  /**
   * @ignore
   */
  disposeDataItem(dataItem) {
    super.disposeDataItem(dataItem);
    const mapLine = dataItem.get("mapLine");
    if (mapLine) {
      this.mapLines.removeValue(mapLine);
      mapLine.dispose();
    }
  }
  /**
   * @ignore
   */
  _excludeDataItem(dataItem) {
    super._excludeDataItem(dataItem);
    const mapLine = dataItem.get("mapLine");
    if (mapLine) {
      mapLine.setPrivate("visible", false);
    }
  }
  /**
   * @ignore
   */
  _unexcludeDataItem(dataItem) {
    super._unexcludeDataItem(dataItem);
    const mapLine = dataItem.get("mapLine");
    if (mapLine) {
      mapLine.setPrivate("visible", true);
    }
  }
  /**
   * @ignore
   */
  _notIncludeDataItem(dataItem) {
    super._notIncludeDataItem(dataItem);
    const mapLine = dataItem.get("mapLine");
    if (mapLine) {
      mapLine.setPrivate("visible", false);
    }
  }
  /**
   * @ignore
   */
  _unNotIncludeDataItem(dataItem) {
    super._unNotIncludeDataItem(dataItem);
    const mapLine = dataItem.get("mapLine");
    if (mapLine) {
      mapLine.setPrivate("visible", true);
    }
  }
};
Object.defineProperty(MapLineSeries, "className", {
  enumerable: true,
  configurable: true,
  writable: true,
  value: "MapLineSeries"
});
Object.defineProperty(MapLineSeries, "classNames", {
  enumerable: true,
  configurable: true,
  writable: true,
  value: MapSeries.classNames.concat([MapLineSeries.className])
});

// node_modules/@amcharts/amcharts5/.internal/charts/map/GraticuleSeries.js
var GraticuleSeries = class extends MapLineSeries {
  constructor() {
    super(...arguments);
    Object.defineProperty(this, "_dataItem", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: this.makeDataItem({})
    });
  }
  _afterNew() {
    super._afterNew();
    this.dataItems.push(this._dataItem);
    this._generate();
  }
  _updateChildren() {
    super._updateChildren();
    if (this.isDirty("step")) {
      this._generate();
    }
    if (this.isDirty("clipExtent")) {
      if (this.get("clipExtent")) {
        const chart = this.chart;
        if (chart) {
          chart.events.on("geoboundschanged", () => {
            this._generate();
          });
        }
        this._generate();
      }
    }
  }
  _generate() {
    let graticule2 = graticule();
    if (graticule2) {
      if (this.get("clipExtent")) {
        const chart = this.chart;
        if (chart) {
          const geoBounds = chart.geoBounds();
          if (geoBounds) {
            graticule2.extent([[geoBounds.left, geoBounds.bottom], [geoBounds.right, geoBounds.top]]);
          }
        }
      }
      const step = this.get("step", 10);
      graticule2.stepMinor([360, 360]);
      graticule2.stepMajor([step, step]);
      this._dataItem.set("geometry", graticule2());
    }
  }
};
Object.defineProperty(GraticuleSeries, "className", {
  enumerable: true,
  configurable: true,
  writable: true,
  value: "GraticuleSeries"
});
Object.defineProperty(GraticuleSeries, "classNames", {
  enumerable: true,
  configurable: true,
  writable: true,
  value: MapLineSeries.classNames.concat([GraticuleSeries.className])
});

// node_modules/@amcharts/amcharts5/.internal/charts/map/MapChartDefaultTheme.js
var MapChartDefaultTheme = class extends Theme {
  setupDefaultRules() {
    super.setupDefaultRules();
    const ic = this._root.interfaceColors;
    const r = this.rule.bind(this);
    r("MapChart").setAll({
      projection: mercator_default(),
      panX: "translateX",
      panY: "translateY",
      pinchZoom: true,
      zoomStep: 2,
      zoomLevel: 1,
      rotationX: 0,
      rotationY: 0,
      rotationZ: 0,
      maxZoomLevel: 32,
      minZoomLevel: 1,
      wheelY: "zoom",
      wheelX: "none",
      animationEasing: out(cubic),
      wheelEasing: out(cubic),
      wheelDuration: 0,
      wheelSensitivity: 1,
      maxPanOut: 0.4,
      centerMapOnZoomOut: true
    });
    {
      const rule = r("MapLine");
      rule.setAll({
        precision: 0.5,
        role: "figure"
      });
      setColor(rule, "stroke", ic, "grid");
    }
    r("MapPolygonSeries").setAll({
      affectsBounds: true
    });
    r("MapPointSeries").setAll({
      affectsBounds: false,
      clipFront: false,
      clipBack: true,
      autoScale: false
    });
    r("ClusteredPointSeries").setAll({
      minDistance: 20,
      scatterDistance: 3,
      scatterRadius: 8,
      stopClusterZoom: 0.95
    });
    r("MapLineSeries").setAll({
      affectsBounds: false
    });
    {
      const rule = r("MapPolygon");
      rule.setAll({
        precision: 0.5,
        isMeasured: false,
        role: "figure",
        fillOpacity: 1,
        position: "absolute",
        strokeWidth: 0.2,
        strokeOpacity: 1
      });
      setColor(rule, "fill", ic, "primaryButton");
      setColor(rule, "stroke", ic, "background");
    }
    r("Button", ["zoomtools", "home"]).setAll({
      visible: false
    });
    r("GraticuleSeries").setAll({
      step: 10
    });
  }
};

// node_modules/@amcharts/amcharts5/.internal/charts/map/MapUtils.js
function getGeoCircle(geoPoint, radius) {
  return circle_default().center([geoPoint.longitude, geoPoint.latitude]).radius(radius)();
}
function getGeoCentroid(geometry) {
  const centroid = centroid_default(geometry);
  return { longitude: centroid[0], latitude: centroid[1] };
}
function getGeoArea(geometry) {
  return area_default(geometry);
}
function getGeoBounds(geometry) {
  const bounds = bounds_default(geometry);
  if (bounds) {
    const geoBounds = { left: bounds[0][0], right: bounds[1][0], top: bounds[1][1], bottom: bounds[0][1] };
    if (geoBounds.right < geoBounds.left) {
      geoBounds.right = 180;
      geoBounds.left = -180;
    }
    return geoBounds;
  }
  return { left: 0, right: 0, top: 0, bottom: 0 };
}
function getGeoRectangle(north, east, south, west) {
  let multiPolygon = [];
  if (west <= -180) {
    west = -179.9999;
  }
  if (south <= -90) {
    south = -89.9999;
  }
  if (north >= 90) {
    north = 89.9999;
  }
  if (east >= 180) {
    east = 179.9999;
  }
  let stepLong = Math.min(90, (east - west) / Math.ceil((east - west) / 90));
  let stepLat = (north - south) / Math.ceil((north - south) / 90);
  for (let ln = west; ln < east; ln = ln + stepLong) {
    let surface = [];
    multiPolygon.push([surface]);
    if (ln + stepLong > east) {
      stepLong = east - ln;
    }
    for (let ll = ln; ll <= ln + stepLong; ll = ll + 5) {
      surface.push([ll, north]);
    }
    for (let lt = north; lt >= south; lt = lt - stepLat) {
      surface.push([ln + stepLong, lt]);
    }
    for (let ll = ln + stepLong; ll >= ln; ll = ll - 5) {
      surface.push([ll, south]);
    }
    for (let lt = south; lt <= north; lt = lt + stepLat) {
      surface.push([ln, lt]);
    }
  }
  return { type: "MultiPolygon", coordinates: multiPolygon };
}
function normalizeGeoPoint(geoPoint) {
  let longitude2 = wrapAngleTo180(geoPoint.longitude);
  let latitude = Math.asin(Math.sin(geoPoint.latitude * RADIANS)) * DEGREES;
  let latitude180 = wrapAngleTo180(geoPoint.latitude);
  if (Math.abs(latitude180) > 90) {
    longitude2 = wrapAngleTo180(longitude2 + 180);
  }
  geoPoint.longitude = longitude2;
  geoPoint.latitude = latitude;
  return geoPoint;
}
function wrapAngleTo180(angle2) {
  angle2 = angle2 % 360;
  if (angle2 > 180) {
    angle2 -= 360;
  }
  if (angle2 < -180) {
    angle2 += 360;
  }
  return angle2;
}

// node_modules/@amcharts/amcharts5/.internal/charts/map/MapChart.js
var MapChart = class extends SerialChart {
  constructor() {
    super(...arguments);
    Object.defineProperty(this, "_downTranslateX", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_downTranslateY", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_downRotationX", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_downRotationY", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_downRotationZ", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_pLat", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 0
    });
    Object.defineProperty(this, "_pLon", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 0
    });
    Object.defineProperty(this, "_movePoints", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: {}
    });
    Object.defineProperty(this, "_downZoomLevel", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 1
    });
    Object.defineProperty(this, "_doubleDownDistance", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 0
    });
    Object.defineProperty(this, "_dirtyGeometries", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: false
    });
    Object.defineProperty(this, "_geometryColection", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: { type: "GeometryCollection", geometries: [] }
    });
    Object.defineProperty(this, "_centerLocation", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: null
    });
    Object.defineProperty(this, "_za", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_rxa", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_rya", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_txa", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_tya", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_mapBounds", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: [[0, 0], [0, 0]]
    });
    Object.defineProperty(this, "_geoCentroid", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: { longitude: 0, latitude: 0 }
    });
    Object.defineProperty(this, "_geoBounds", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: { left: 0, right: 0, top: 0, bottom: 0 }
    });
    Object.defineProperty(this, "_prevGeoBounds", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: { left: 0, right: 0, top: 0, bottom: 0 }
    });
    Object.defineProperty(this, "_dispatchBounds", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: false
    });
    Object.defineProperty(this, "_wheelDp", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_pw", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_ph", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_mapFitted", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: false
    });
    Object.defineProperty(this, "_centerX", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 0
    });
    Object.defineProperty(this, "_centerY", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 0
    });
  }
  _makeGeoPath() {
    const projection2 = this.get("projection");
    const path = path_default();
    path.projection(projection2);
    this.setPrivateRaw("geoPath", path);
  }
  /**
   * Returns a geoPoint of the current zoom position.
   *
   * You can later use it to restore zoom position, e.g.: `chart.zoomToGeoPoint(geoPoint, zoomLevel, true)`.
   *
   * @since 5.2.19
   */
  geoPoint() {
    return this.invert(this.seriesContainer.toGlobal({ x: this.width() / 2, y: this.height() / 2 }));
  }
  /**
   * Returns coordinates to geographical center of the map.
   */
  geoCentroid() {
    return this._geoCentroid;
  }
  /**
   * Returns geographical bounds of the map.
   */
  geoBounds() {
    return this._geoBounds;
  }
  _handleSetWheel() {
    const wheelX = this.get("wheelX");
    const wheelY = this.get("wheelY");
    const chartContainer = this.chartContainer;
    if (wheelX != "none" || wheelY != "none") {
      if (this._wheelDp) {
        this._wheelDp.dispose();
      }
      this._wheelDp = chartContainer.events.on("wheel", (event) => {
        const wheelEasing = this.get("wheelEasing");
        const wheelSensitivity = this.get("wheelSensitivity", 1);
        const wheelDuration = this.get("wheelDuration", 0);
        const wheelEvent = event.originalEvent;
        let prevent = false;
        if (isLocalEvent(wheelEvent, this)) {
          prevent = true;
        } else {
          return;
        }
        const point = chartContainer._display.toLocal(event.point);
        if (wheelY == "zoom") {
          if (this.get("zoomLevel") == this.get("minZoomLevel", 1) && wheelEvent.deltaY > 0) {
            return;
          }
          this._handleWheelZoom(wheelEvent.deltaY, point);
        } else if (wheelY == "rotateY") {
          this._handleWheelRotateY(wheelEvent.deltaY / 5 * wheelSensitivity, wheelDuration, wheelEasing);
        } else if (wheelY == "rotateX") {
          this._handleWheelRotateX(wheelEvent.deltaY / 5 * wheelSensitivity, wheelDuration, wheelEasing);
        }
        if (wheelX == "zoom") {
          this._handleWheelZoom(wheelEvent.deltaX, point);
        } else if (wheelX == "rotateY") {
          this._handleWheelRotateY(wheelEvent.deltaX / 5 * wheelSensitivity, wheelDuration, wheelEasing);
        } else if (wheelX == "rotateX") {
          this._handleWheelRotateX(wheelEvent.deltaX / 5 * wheelSensitivity, wheelDuration, wheelEasing);
        }
        if (prevent) {
          wheelEvent.preventDefault();
        }
      });
      this._disposers.push(this._wheelDp);
    } else {
      if (this._wheelDp) {
        this._wheelDp.dispose();
      }
    }
  }
  _prepareChildren() {
    super._prepareChildren();
    const projection2 = this.get("projection");
    const w = this.innerWidth();
    const h = this.innerHeight();
    const previousGeometries = this._geometryColection.geometries;
    if (this.isDirty("projection")) {
      this._makeGeoPath();
      this.markDirtyProjection();
      this._fitMap();
      projection2.scale(this.getPrivate("mapScale") * this.get("zoomLevel", 1));
      if (projection2.rotate) {
        projection2.rotate([this.get("rotationX", 0), this.get("rotationY", 0), this.get("rotationZ", 0)]);
      }
      let prev = this._prevSettings.projection;
      if (prev && prev != projection2) {
        let hw = w / 2;
        let hh = h / 2;
        if (prev.invert) {
          let centerLocation = prev.invert([hw, hh]);
          if (centerLocation) {
            let xy = projection2(centerLocation);
            if (xy) {
              let translate = projection2.translate();
              let xx = hw - (xy[0] - translate[0]);
              let yy = hh - (xy[1] - translate[1]);
              projection2.translate([xx, yy]);
              this.setRaw("translateX", xx);
              this.setRaw("translateY", yy);
            }
          }
        }
      }
    }
    if (this.isDirty("wheelX") || this.isDirty("wheelY")) {
      this._handleSetWheel();
    }
    if (this._dirtyGeometries) {
      this._geometryColection.geometries = [];
      this.series.each((series) => {
        pushAll(this._geometryColection.geometries, series._geometries);
      });
      this._fitMap();
    }
    if (previousGeometries.length != 0 && (w != this._pw || h != this._ph || this._dirtyGeometries)) {
      if (w > 0 && h > 0) {
        let hw = w / 2;
        let hh = h / 2;
        projection2.fitSize([w, h], this._geometryColection);
        const newScale = projection2.scale();
        this.setPrivateRaw("mapScale", newScale);
        projection2.scale(newScale * this.get("zoomLevel", 1));
        if (this._centerLocation) {
          let xy = projection2(this._centerLocation);
          if (xy) {
            let translate = projection2.translate();
            let xx = hw - (xy[0] - translate[0]);
            let yy = hh - (xy[1] - translate[1]);
            projection2.translate([xx, yy]);
            this.setRaw("translateX", xx);
            this.setRaw("translateY", yy);
            this._centerX = translate[0];
            this._centerY = translate[1];
          }
        }
        this.markDirtyProjection();
        const geoPath = this.getPrivate("geoPath");
        this._mapBounds = geoPath.bounds(this._geometryColection);
      }
    }
    this._pw = w;
    this._ph = h;
    if (this.isDirty("zoomControl")) {
      const previous = this._prevSettings.zoomControl;
      const zoomControl = this.get("zoomControl");
      if (zoomControl !== previous) {
        this._disposeProperty("zoomControl");
        if (previous) {
          previous.dispose();
        }
        if (zoomControl) {
          zoomControl.setPrivate("chart", this);
          this.children.push(zoomControl);
        }
        this.setRaw("zoomControl", zoomControl);
      }
    }
    if (this.isDirty("zoomLevel")) {
      projection2.scale(this.getPrivate("mapScale") * this.get("zoomLevel", 1));
      this.markDirtyProjection();
      this.series.each((series) => {
        if (series.isType("MapPointSeries")) {
          if (series.get("autoScale")) {
            each(series.dataItems, (dataItem) => {
              const bullets = dataItem.bullets;
              if (bullets) {
                each(bullets, (bullet) => {
                  const sprite = bullet.get("sprite");
                  if (sprite) {
                    sprite.set("scale", this.get("zoomLevel"));
                  }
                });
              }
            });
          }
        }
      });
      const zoomControl = this.get("zoomControl");
      if (zoomControl) {
        const zoomLevel = this.get("zoomLevel", 1);
        if (zoomLevel == this.get("minZoomLevel", 1)) {
          this.root.events.once("frameended", () => {
            zoomControl.minusButton.set("disabled", true);
          });
        } else {
          zoomControl.minusButton.set("disabled", false);
        }
        if (zoomLevel == this.get("maxZoomLevel", 32)) {
          zoomControl.plusButton.set("disabled", true);
        } else {
          zoomControl.plusButton.set("disabled", false);
        }
      }
    }
    if (this.isDirty("translateX") || this.isDirty("translateY")) {
      projection2.translate([this.get("translateX", this.width() / 2), this.get("translateY", this.height() / 2)]);
      this.markDirtyProjection();
    }
    if (projection2.rotate) {
      if (this.isDirty("rotationX") || this.isDirty("rotationY") || this.isDirty("rotationZ")) {
        projection2.rotate([this.get("rotationX", 0), this.get("rotationY", 0), this.get("rotationZ", 0)]);
        this.markDirtyProjection();
      }
    }
    if (this.isDirty("pinchZoom") || this.get("panX") || this.get("panY")) {
      this._setUpTouch();
    }
  }
  _fitMap() {
    const projection2 = this.get("projection");
    let w = this.innerWidth();
    let h = this.innerHeight();
    if (w > 0 && h > 0) {
      projection2.fitSize([w, h], this._geometryColection);
      this.setPrivateRaw("mapScale", projection2.scale());
      const translate = projection2.translate();
      this.setRaw("translateX", translate[0]);
      this.setRaw("translateY", translate[1]);
      this._centerX = translate[0];
      this._centerY = translate[1];
      const geoPath = this.getPrivate("geoPath");
      this._mapBounds = geoPath.bounds(this._geometryColection);
      this._geoCentroid = getGeoCentroid(this._geometryColection);
      const bounds = getGeoBounds(this._geometryColection);
      this._geoBounds = bounds;
      if (this._geometryColection.geometries.length > 0) {
        bounds.left = round(this._geoBounds.left, 3);
        bounds.right = round(this._geoBounds.right, 3);
        bounds.top = round(this._geoBounds.top, 3);
        bounds.bottom = round(this._geoBounds.bottom, 3);
        const prevGeoBounds = this._prevGeoBounds;
        if (prevGeoBounds && !sameBounds(bounds, prevGeoBounds)) {
          this._dispatchBounds = true;
          this._prevGeoBounds = bounds;
        }
      }
      this._mapFitted = true;
    }
  }
  /**
   * Returns geographical coordinates for calculated or manual center of the
   * map.
   */
  homeGeoPoint() {
    let homeGeoPoint = this.get("homeGeoPoint");
    if (!homeGeoPoint) {
      const geoPath = this.getPrivate("geoPath");
      const bounds = geoPath.bounds(this._geometryColection);
      const left = bounds[0][0];
      const top = bounds[0][1];
      const right = bounds[1][0];
      const bottom = bounds[1][1];
      homeGeoPoint = this.invert({ x: left + (right - left) / 2, y: top + (bottom - top) / 2 });
    }
    return homeGeoPoint;
  }
  /**
   * Repositions the map to the "home" zoom level and center coordinates.
   *
   * @see {@link https://www.amcharts.com/docs/v5/charts/map-chart/map-pan-zoom/#Resetting_position_level} for more info
   * @param  duration  Animation duration in milliseconds
   */
  goHome(duration) {
    this.zoomToGeoPoint(this.homeGeoPoint(), this.get("homeZoomLevel", 1), true, duration, this.get("homeRotationX"), this.get("homeRotationY"));
  }
  _updateChildren() {
    const projection2 = this.get("projection");
    if (projection2.invert) {
      let w = this.innerWidth();
      let h = this.innerHeight();
      if (w > 0 && h > 0) {
        this._centerLocation = projection2.invert([this.innerWidth() / 2, this.innerHeight() / 2]);
      }
    }
    super._updateChildren();
  }
  _afterChanged() {
    super._afterChanged();
    if (this._dispatchBounds) {
      this._dispatchBounds = false;
      const type = "geoboundschanged";
      if (this.events.isEnabled(type)) {
        this.events.dispatch(type, { type, target: this });
      }
    }
  }
  _setUpTouch() {
    if (!this.chartContainer._display.cancelTouch) {
      this.chartContainer._display.cancelTouch = this.get("pinchZoom") || this.get("panX") || this.get("panY") ? true : false;
    }
  }
  /**
   * @ignore
   */
  markDirtyGeometries() {
    this._dirtyGeometries = true;
    this.markDirty();
  }
  /**
   * @ignore
   */
  markDirtyProjection() {
    this.series.each((series) => {
      series.markDirtyProjection();
    });
  }
  _afterNew() {
    this._defaultThemes.push(MapChartDefaultTheme.new(this._root));
    this._settings.themeTags = mergeTags(this._settings.themeTags, ["map"]);
    this.children.push(this.bulletsContainer);
    super._afterNew();
    this._makeGeoPath();
    this.chartContainer.children.push(this.seriesContainer);
    if (this.get("translateX") == null) {
      this.set("translateX", this.width() / 2);
    }
    if (this.get("translateY") == null) {
      this.set("translateY", this.height() / 2);
    }
    this.chartContainer.set("interactive", true);
    this.chartContainer.set("interactiveChildren", false);
    this.chartContainer.set("background", Rectangle.new(this._root, {
      themeTags: ["map", "background"],
      fill: Color.fromHex(0),
      fillOpacity: 0
    }));
    this._disposers.push(this.chartContainer.events.on("pointerdown", (event) => {
      this._handleChartDown(event);
    }));
    this._disposers.push(this.chartContainer.events.on("globalpointerup", (event) => {
      this._handleChartUp(event);
    }));
    this._disposers.push(this.chartContainer.events.on("globalpointermove", (event) => {
      this._handleChartMove(event);
    }));
    let license = false;
    for (let i = 0; i < registry.licenses.length; i++) {
      if (registry.licenses[i].match(/^AM5M.{5,}/i)) {
        license = true;
      }
    }
    if (!license) {
      this._root._showBranding();
    } else {
      this._root._licenseApplied();
    }
    this._setUpTouch();
  }
  _handleChartDown(event) {
    this._downZoomLevel = this.get("zoomLevel", 1);
    const downPoints = this.chartContainer._downPoints;
    let count3 = keys(downPoints).length;
    if (count3 == 1) {
      let downPoint = downPoints[1];
      if (!downPoint) {
        downPoint = downPoints[0];
      }
      if (downPoint && (downPoint.x == event.point.x && downPoint.y == event.point.y)) {
        count3 = 0;
      }
    }
    if (count3 > 0) {
      this._downTranslateX = this.get("translateX");
      this._downTranslateY = this.get("translateY");
      this._downRotationX = this.get("rotationX");
      this._downRotationY = this.get("rotationY");
      this._downRotationZ = this.get("rotationZ");
      const downId = this.chartContainer._getDownPointId();
      if (downId) {
        let movePoint = this._movePoints[downId];
        if (movePoint) {
          this.chartContainer._downPoints[downId] = movePoint;
        }
      }
    } else if (count3 == 0) {
      let bg = this.chartContainer.get("background");
      if (bg) {
        bg.events.enableType("click");
      }
      if (this.get("panX") || this.get("panY")) {
        if (this._za) {
          this._za.stop();
        }
        if (this._txa) {
          this._txa.stop();
        }
        if (this._tya) {
          this._tya.stop();
        }
        if (this._rxa) {
          this._rxa.stop();
        }
        if (this._rya) {
          this._rya.stop();
        }
        const downPoint = this.chartContainer._display.toLocal(event.point);
        this._downTranslateX = this.get("translateX");
        this._downTranslateY = this.get("translateY");
        this._downRotationX = this.get("rotationX");
        this._downRotationY = this.get("rotationY");
        this._downRotationZ = this.get("rotationZ");
        let projection2 = this.get("projection");
        if (projection2.invert) {
          let l0 = projection2.invert([downPoint.x, downPoint.y]);
          let l1 = projection2.invert([downPoint.x + 1, downPoint.y + 1]);
          if (l0 && l1) {
            this._pLon = Math.abs(l1[0] - l0[0]);
            this._pLat = Math.abs(l1[1] - l0[1]);
          }
        }
      }
    }
  }
  /**
   * Converts screen coordinates (X and Y) within chart to latitude and
   * longitude.
   *
   * @param  point  Screen coordinates
   * @return        Geographical coordinates
   */
  invert(point) {
    let projection2 = this.get("projection");
    if (projection2.invert) {
      const ll = projection2.invert([point.x, point.y]);
      if (ll) {
        return { longitude: ll[0], latitude: ll[1] };
      }
    }
    return { longitude: 0, latitude: 0 };
  }
  /**
   * Converts latitude/longitude to screen coordinates (X and Y).
   *
   * @param  point  Geographical coordinates
   * @param  rotationX  X rotation of a map if different from current
   * @param  rotationY  Y rotation of a map if different from current
   *
   * @return Screen coordinates
   */
  convert(point, rotationX, rotationY) {
    let projection2 = this.get("projection");
    let xy;
    if (!projection2.rotate) {
      rotationX = void 0;
      rotationY = void 0;
    }
    if (rotationX != null || rotationY != null) {
      if (rotationX == null) {
        rotationX = 0;
      }
      if (rotationY == null) {
        rotationY = 0;
      }
      let rotation = projection2.rotate();
      projection2.rotate([rotationX, rotationY, 0]);
      xy = projection2([point.longitude, point.latitude]);
      projection2.rotate(rotation);
    } else {
      xy = projection2([point.longitude, point.latitude]);
    }
    if (xy) {
      return { x: xy[0], y: xy[1] };
    }
    return { x: 0, y: 0 };
  }
  _handleChartUp(_event) {
    this.chartContainer._downPoints = {};
  }
  _handlePinch() {
    const chartContainer = this.chartContainer;
    let i = 0;
    let downPoints = [];
    let movePoints = [];
    each2(chartContainer._downPoints, (k, point) => {
      downPoints[i] = point;
      let movePoint = this._movePoints[k];
      if (movePoint) {
        movePoints[i] = movePoint;
      }
      i++;
    });
    if (downPoints.length > 1 && movePoints.length > 1) {
      const display = chartContainer._display;
      let downPoint0 = downPoints[0];
      let downPoint1 = downPoints[1];
      let movePoint0 = movePoints[0];
      let movePoint1 = movePoints[1];
      if (downPoint0 && downPoint1 && movePoint0 && movePoint1) {
        downPoint0 = display.toLocal(downPoint0);
        downPoint1 = display.toLocal(downPoint1);
        movePoint0 = display.toLocal(movePoint0);
        movePoint1 = display.toLocal(movePoint1);
        let initialDistance = Math.hypot(downPoint1.x - downPoint0.x, downPoint1.y - downPoint0.y);
        let currentDistance = Math.hypot(movePoint1.x - movePoint0.x, movePoint1.y - movePoint0.y);
        let level = currentDistance / initialDistance * this._downZoomLevel;
        level = fitToRange(level, this.get("minZoomLevel", 1), this.get("maxZoomLevel", 32));
        let moveCenter = { x: movePoint0.x + (movePoint1.x - movePoint0.x) / 2, y: movePoint0.y + (movePoint1.y - movePoint0.y) / 2 };
        let downCenter = { x: downPoint0.x + (downPoint1.x - downPoint0.x) / 2, y: downPoint0.y + (downPoint1.y - downPoint0.y) / 2 };
        let tx = this._downTranslateX || 0;
        let ty = this._downTranslateY || 0;
        let zoomLevel = this._downZoomLevel;
        let xx = moveCenter.x - (-tx + downCenter.x) / zoomLevel * level;
        let yy = moveCenter.y - (-ty + downCenter.y) / zoomLevel * level;
        this.set("zoomLevel", level);
        this.set("translateX", xx);
        this.set("translateY", yy);
      }
    }
  }
  _handleChartMove(event) {
    const chartContainer = this.chartContainer;
    let downPoint = chartContainer._getDownPoint();
    const downPointId = chartContainer._getDownPointId();
    const originalEvent = event.originalEvent;
    const pointerId = originalEvent.pointerId;
    if (this.get("pinchZoom")) {
      if (pointerId) {
        this._movePoints[pointerId] = event.point;
        if (keys(chartContainer._downPoints).length > 1) {
          this._handlePinch();
          return;
        }
      }
    }
    if (downPointId && pointerId && pointerId != downPointId) {
      return;
    } else {
      if (downPoint) {
        const panX = this.get("panX");
        const panY = this.get("panY");
        if (panX != "none" || panY != "none") {
          const display = chartContainer._display;
          let local = display.toLocal(event.point);
          downPoint = display.toLocal(downPoint);
          let x = this._downTranslateX;
          let y = this._downTranslateY;
          if (Math.hypot(downPoint.x - local.x, downPoint.y - local.y) > 5) {
            let bg = chartContainer.get("background");
            if (bg) {
              bg.events.disableType("click");
            }
            if (isNumber(x) && isNumber(y)) {
              let projection2 = this.get("projection");
              const zoomLevel = this.get("zoomLevel", 1);
              const maxPanOut = this.get("maxPanOut", 0.4);
              const bounds = this._mapBounds;
              const w = this.width();
              const h = this.height();
              const ww = bounds[1][0] - bounds[0][0];
              const hh = bounds[1][1] - bounds[0][1];
              if (panX == "translateX") {
                x += local.x - downPoint.x;
                const cx = w / 2 - (w / 2 - this._centerX) * zoomLevel;
                x = Math.min(x, cx + ww * maxPanOut * zoomLevel);
                x = Math.max(x, cx - ww * maxPanOut * zoomLevel);
              }
              if (panY == "translateY") {
                y += local.y - downPoint.y;
                const cy = h / 2 - (h / 2 - this._centerY) * zoomLevel;
                y = Math.min(y, cy + hh * maxPanOut * zoomLevel);
                y = Math.max(y, cy - hh * maxPanOut * zoomLevel);
              }
              this.set("translateX", x);
              this.set("translateY", y);
              if (projection2.invert) {
                let downLocation = projection2.invert([downPoint.x, downPoint.y]);
                if (location && downLocation) {
                  if (panX == "rotateX") {
                    this.set("rotationX", this._downRotationX - (downPoint.x - local.x) * this._pLon);
                  }
                  if (panY == "rotateY") {
                    this.set("rotationY", this._downRotationY + (downPoint.y - local.y) * this._pLat);
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  _handleWheelRotateY(delta, duration, easing) {
    this._rya = this.animate({ key: "rotationY", to: this.get("rotationY", 0) - delta, duration, easing });
  }
  _handleWheelRotateX(delta, duration, easing) {
    this._rxa = this.animate({ key: "rotationX", to: this.get("rotationX", 0) - delta, duration, easing });
  }
  _handleWheelZoom(delta, point) {
    let step = this.get("zoomStep", 2);
    let zoomLevel = this.get("zoomLevel", 1);
    let newZoomLevel = zoomLevel;
    if (delta > 0) {
      newZoomLevel = zoomLevel / step;
    } else if (delta < 0) {
      newZoomLevel = zoomLevel * step;
    }
    if (newZoomLevel != zoomLevel) {
      this.zoomToPoint(point, newZoomLevel);
    }
  }
  /**
   * Zoom the map to geographical bounds.
   *
   * @param  geoBounds  Bounds
   * @param  duration   Animation duration in milliseconds
   * @param  rotationX  X rotation of a map at the end of zoom
   * @param  rotationY  Y rotation of a map at the end of zoom
   */
  zoomToGeoBounds(geoBounds, duration, rotationX, rotationY) {
    if (geoBounds.right < geoBounds.left) {
      geoBounds.right = 180;
      geoBounds.left = -180;
    }
    const geoPath = this.getPrivate("geoPath");
    const mapBounds = geoPath.bounds(this._geometryColection);
    let p02 = this.convert({ longitude: geoBounds.left, latitude: geoBounds.top }, rotationX, rotationY);
    let p1 = this.convert({ longitude: geoBounds.right, latitude: geoBounds.bottom }, rotationX, rotationY);
    if (p02.y < mapBounds[0][1]) {
      p02.y = mapBounds[0][1];
    }
    if (p1.y > mapBounds[1][1]) {
      p1.y = mapBounds[1][1];
    }
    let zl = this.get("zoomLevel", 1);
    let bounds = { left: p02.x, right: p1.x, top: p02.y, bottom: p1.y };
    let seriesContainer = this.seriesContainer;
    let zoomLevel = 0.9 * Math.min(seriesContainer.innerWidth() / (bounds.right - bounds.left) * zl, seriesContainer.innerHeight() / (bounds.bottom - bounds.top) * zl);
    let x = bounds.left + (bounds.right - bounds.left) / 2;
    let y = bounds.top + (bounds.bottom - bounds.top) / 2;
    let geoPoint = this.invert({ x, y });
    if (rotationX != null || rotationY != null) {
      this.rotate(rotationX, rotationY);
    }
    return this.zoomToGeoPoint(geoPoint, zoomLevel, true, duration);
  }
  /**
   * Zooms the map to specific screen point.
   *
   * @param  point    Point
   * @param  level    Zoom level
   * @param  center   Center the map
   * @param  duration Duration of the animation in milliseconds
   */
  zoomToPoint(point, level, center, duration) {
    if (level) {
      level = fitToRange(level, this.get("minZoomLevel", 1), this.get("maxZoomLevel", 32));
    }
    if (!isNumber(duration)) {
      duration = this.get("animationDuration", 0);
    }
    const easing = this.get("animationEasing");
    const zoomLevel = this.get("zoomLevel", 1);
    if (this.get("centerMapOnZoomOut") && level == this.get("homeZoomLevel", 1)) {
      point = this.convert(this.homeGeoPoint(), this.get("homeRotationX"), this.get("homeRotationY"));
      center = true;
    }
    let x = point.x;
    let y = point.y;
    let tx = this.get("translateX", 0);
    let ty = this.get("translateY", 0);
    let cx = x;
    let cy = y;
    if (center) {
      cx = this.width() / 2;
      cy = this.height() / 2;
    }
    let xx = cx - (x - tx) / zoomLevel * level;
    let yy = cy - (y - ty) / zoomLevel * level;
    this._txa = this.animate({ key: "translateX", to: xx, duration, easing });
    this._tya = this.animate({ key: "translateY", to: yy, duration, easing });
    this._za = this.animate({ key: "zoomLevel", to: level, duration, easing });
    if (zoomLevel != level) {
      this._root.readerAlert(this._t("Zoom level changed to %1", this._root.locale, numberToString(level)));
    }
    return this._za;
  }
  /**
   * Zooms the map to specific geographical point.
   *
   * @param  geoPoint  Point
   * @param  level     Zoom level
   * @param  center    Center the map
   * @param  duration  Duration of the animation in milliseconds
   * @param  rotationX  X rotation of a map at the end of zoom
   * @param  rotationY  Y rotation of a map at the end of zoom
   *
   */
  zoomToGeoPoint(geoPoint, level, center, duration, rotationX, rotationY) {
    let xy = this.convert(geoPoint, rotationX, rotationY);
    if (rotationX != null || rotationY != null) {
      this.rotate(rotationX, rotationY, duration);
    }
    if (xy) {
      return this.zoomToPoint(xy, level, center, duration);
    }
  }
  rotate(rotationX, rotationY, duration) {
    const projection2 = this.get("projection");
    if (!projection2.rotate) {
    } else {
      if (!isNumber(duration)) {
        duration = this.get("animationDuration", 0);
      }
      const easing = this.get("animationEasing");
      if (rotationX != null) {
        this.animate({ key: "rotationX", to: rotationX, duration, easing });
      }
      if (rotationY != null) {
        this.animate({ key: "rotationY", to: rotationY, duration, easing });
      }
    }
  }
  /**
   * Zooms the map in.
   */
  zoomIn() {
    return this.zoomToPoint({ x: this.width() / 2, y: this.height() / 2 }, this.get("zoomLevel", 1) * this.get("zoomStep", 2));
  }
  /**
   * Zooms the map out.
   */
  zoomOut() {
    return this.zoomToPoint({ x: this.width() / 2, y: this.height() / 2 }, this.get("zoomLevel", 1) / this.get("zoomStep", 2));
  }
  _clearDirty() {
    super._clearDirty();
    this._dirtyGeometries = false;
    this._mapFitted = false;
  }
  /**
   * Returns area of a mapPolygon in square pixels.
   */
  getArea(dataItem) {
    const geoPath = this.getPrivate("geoPath");
    const geometry = dataItem.get("geometry");
    if (geometry) {
      return geoPath.area(geometry);
    }
    return 0;
  }
};
Object.defineProperty(MapChart, "className", {
  enumerable: true,
  configurable: true,
  writable: true,
  value: "MapChart"
});
Object.defineProperty(MapChart, "classNames", {
  enumerable: true,
  configurable: true,
  writable: true,
  value: SerialChart.classNames.concat([MapChart.className])
});

// node_modules/@amcharts/amcharts5/.internal/charts/map/MapPointSeries.js
var MapPointSeries = class extends MapSeries {
  constructor() {
    super(...arguments);
    Object.defineProperty(this, "_types", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: ["Point", "MultiPoint"]
    });
    Object.defineProperty(this, "_lineChangedDp", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
  }
  _afterNew() {
    this.fields.push("polygonId", "lineId", "longitude", "latitude", "fixed");
    super._afterNew();
  }
  /**
   * @ignore
   */
  markDirtyProjection() {
    this.markDirty();
  }
  /**
   * Forces a repaint of the element which relies on data.
   *
   * @since 5.0.21
   */
  markDirtyValues(dataItem) {
    super.markDirtyValues();
    if (dataItem) {
      this._positionBullets(dataItem);
    }
  }
  processDataItem(dataItem) {
    super.processDataItem(dataItem);
    let geometry = dataItem.get("geometry");
    if (!geometry) {
      geometry = { type: "Point", coordinates: [dataItem.get("longitude", 0), dataItem.get("latitude", 0)] };
      dataItem.set("geometry", geometry);
    } else {
      if (geometry.type == "Point") {
        const coordinates2 = geometry.coordinates;
        if (coordinates2) {
          dataItem.set("longitude", coordinates2[0]);
          dataItem.set("latitude", coordinates2[1]);
        }
      } else if (geometry.type == "MultiPoint") {
        const coordinates2 = geometry.coordinates;
        if (coordinates2 && coordinates2[0]) {
          dataItem.set("longitude", coordinates2[0][0]);
          dataItem.set("latitude", coordinates2[0][1]);
        }
      }
    }
    this._addGeometry(geometry, this);
  }
  _makeBullets(dataItem) {
    dataItem.bullets = [];
    this.bullets.each((bulletFunction) => {
      const geometry = dataItem.get("geometry");
      if (geometry) {
        if (geometry.type == "Point") {
          this._setBulletParent(this._makeBullet(dataItem, bulletFunction));
        } else if (geometry.type = "MultiPoint") {
          let i = 0;
          each(geometry.coordinates, () => {
            this._setBulletParent(this._makeBullet(dataItem, bulletFunction, i));
            i++;
          });
        }
      }
    });
  }
  _setBulletParent(bullet) {
    if (bullet) {
      const sprite = bullet.get("sprite");
      const chart = this.chart;
      if (sprite && chart) {
        const dataItem = sprite.dataItem;
        if (dataItem) {
          if (dataItem.get("fixed")) {
            if (sprite.parent != chart.bulletsContainer) {
              chart.bulletsContainer.children.moveValue(sprite);
            }
          } else {
            if (sprite.parent != this.bulletsContainer) {
              this.bulletsContainer.children.moveValue(sprite);
            }
          }
        }
      }
    }
  }
  _positionBullet(bullet) {
    const sprite = bullet.get("sprite");
    if (sprite) {
      const dataItem = sprite.dataItem;
      if (dataItem && dataItem.get("fixed")) {
        return;
      }
      const latitude = dataItem.get("latitude");
      const longitude2 = dataItem.get("longitude");
      const lineDataItem = dataItem.get("lineDataItem");
      const fixed = dataItem.get("fixed");
      const chart = this.chart;
      let line;
      if (lineDataItem) {
        line = lineDataItem.get("mapLine");
      } else {
        const lineId = dataItem.get("lineId");
        if (lineId && chart) {
          chart.series.each((series) => {
            if (series.isType("MapLineSeries")) {
              let lineDI = series.getDataItemById(lineId);
              if (lineDI) {
                dataItem.set("lineDataItem", lineDI);
                line = lineDI.get("mapLine");
              }
            }
          });
        }
      }
      if (this._lineChangedDp) {
        this._lineChangedDp.dispose();
      }
      if (line) {
        this._lineChangedDp = line.events.on("linechanged", () => {
          this._positionBullets(dataItem);
        });
      }
      const polygonDataItem = dataItem.get("polygonDataItem");
      let polygon;
      if (polygonDataItem) {
        polygon = polygonDataItem.get("mapPolygon");
      } else {
        const polygonId = dataItem.get("polygonId");
        if (polygonId && chart) {
          chart.series.each((series) => {
            if (series.isType("MapPolygonSeries")) {
              let polygonDI = series.getDataItemById(polygonId);
              if (polygonDI) {
                dataItem.set("polygonDataItem", polygonDI);
                polygon = polygonDI.get("mapPolygon");
              }
            }
          });
        }
      }
      const positionOnLine = dataItem.get("positionOnLine");
      let coordinates2;
      let angle2;
      if (polygon) {
        let geoPoint = polygon.visualCentroid();
        coordinates2 = [geoPoint.longitude, geoPoint.latitude];
        dataItem.setRaw("longitude", geoPoint.longitude);
        dataItem.setRaw("latitude", geoPoint.latitude);
      } else if (line && isNumber(positionOnLine)) {
        let geoPoint = line.positionToGeoPoint(positionOnLine);
        coordinates2 = [geoPoint.longitude, geoPoint.latitude];
        if (dataItem.get("autoRotate", bullet.get("autoRotate")) && chart) {
          const geoPoint0 = line.positionToGeoPoint(positionOnLine - 2e-3);
          const geoPoint1 = line.positionToGeoPoint(positionOnLine + 2e-3);
          const point0 = chart.convert(geoPoint0);
          const point1 = chart.convert(geoPoint1);
          angle2 = getAngle(point0, point1);
        }
        dataItem.setRaw("longitude", geoPoint.longitude);
        dataItem.setRaw("latitude", geoPoint.latitude);
      } else if (isNumber(longitude2) && isNumber(latitude)) {
        coordinates2 = [longitude2, latitude];
      } else {
        const geometry = dataItem.get("geometry");
        if (geometry) {
          if (geometry.type == "Point") {
            this._positionBulletReal(bullet, geometry, geometry.coordinates, angle2);
          } else if (geometry.type == "MultiPoint") {
            let index2 = bullet._index || 0;
            coordinates2 = geometry.coordinates[index2];
          }
        }
      }
      if (!fixed && coordinates2) {
        this._positionBulletReal(bullet, { type: "Point", coordinates: coordinates2 }, coordinates2, angle2);
      }
    }
  }
  _positionBulletReal(bullet, geometry, coordinates2, angle2) {
    const sprite = bullet.get("sprite");
    const chart = this.chart;
    if (chart) {
      const projection2 = chart.get("projection");
      const geoPath = chart.getPrivate("geoPath");
      const dataItem = sprite.dataItem;
      const xy = projection2(coordinates2);
      if (xy) {
        const point = { x: xy[0], y: xy[1] };
        sprite.setAll(point);
        dataItem.setRaw("point", point);
      }
      let visible = true;
      if (geoPath(geometry)) {
        if (this.get("clipFront")) {
          visible = false;
        }
      } else {
        if (this.get("clipBack")) {
          visible = false;
        }
      }
      sprite.setPrivate("visible", visible);
      dataItem.set("clipped", !visible);
      if (dataItem && angle2 != null && dataItem.get("autoRotate", bullet.get("autoRotate"))) {
        sprite.set("rotation", angle2 + dataItem.get("autoRotateAngle", bullet.get("autoRotateAngle", 0)));
      }
    }
  }
  /**
   * Centers the map to specific series' data item and zooms to the level
   * specified in the parameters.
   *
   * @param  dataItem   Map point
   * @param  zoomLevel  Zoom level
   * @param  rotate If it's true, the map will rotate so that this point would be in the center. Mostly usefull with geoOrthographic projection.
   */
  zoomToDataItem(dataItem, zoomLevel, rotate) {
    const chart = this.chart;
    if (chart) {
      const longitude2 = dataItem.get("longitude", 0);
      const latitude = dataItem.get("latitude", 0);
      if (rotate) {
        return chart.zoomToGeoPoint({ longitude: longitude2, latitude }, zoomLevel, true, void 0, -longitude2, -latitude);
      }
      return chart.zoomToGeoPoint({ longitude: longitude2, latitude }, zoomLevel, true);
    }
  }
  /**
   * Zooms the map in so that all points in the array are visible.
   *
   * @param   dataItems  An array of data items of points to zoom to
   * @param   rotate     Rotate the map so it is centered on the selected items
   * @return             Animation
   * @since 5.5.6
   */
  zoomToDataItems(dataItems, rotate) {
    let left = null;
    let right = null;
    let top = null;
    let bottom = null;
    each(dataItems, (dataItem) => {
      const longitude2 = dataItem.get("longitude", 0);
      const latitude = dataItem.get("latitude", 0);
      if (left == null || left > longitude2) {
        left = longitude2;
      }
      if (right == null || right < longitude2) {
        right = longitude2;
      }
      if (top == null || top < latitude) {
        top = latitude;
      }
      if (bottom == null || bottom > latitude) {
        bottom = latitude;
      }
    });
    if (left != null && right != null && top != null && bottom != null) {
      const chart = this.chart;
      if (chart) {
        if (rotate) {
          return chart.zoomToGeoBounds({ left, right, top, bottom }, void 0, -(left + (right - left) / 2), -(top + (top - bottom) / 2));
        }
        return chart.zoomToGeoBounds({ left, right, top, bottom });
      }
    }
  }
  /**
   * @ignore
   */
  disposeDataItem(dataItem) {
    const chart = this.chart;
    if (chart) {
      chart.series.each((series) => {
        if (series.isType("MapLineSeries")) {
          each(series.dataItems, (di) => {
            const pointsToConnect = di.get("pointsToConnect");
            if (pointsToConnect) {
              each(pointsToConnect, (point) => {
                if (point == dataItem) {
                  remove(pointsToConnect, point);
                  series.markDirtyValues(di);
                }
              });
            }
          });
        }
      });
    }
    super.disposeDataItem(dataItem);
  }
  /**
   * @ignore
   */
  _excludeDataItem(dataItem) {
    super._excludeDataItem(dataItem);
    const bullets = dataItem.bullets;
    if (bullets) {
      each(bullets, (bullet) => {
        const sprite = bullet.get("sprite");
        if (sprite) {
          sprite.setPrivate("visible", false);
        }
      });
    }
  }
  /**
   * @ignore
   */
  _unexcludeDataItem(dataItem) {
    super._unexcludeDataItem(dataItem);
    const bullets = dataItem.bullets;
    if (bullets) {
      each(bullets, (bullet) => {
        const sprite = bullet.get("sprite");
        if (sprite) {
          sprite.setPrivate("visible", true);
        }
      });
    }
  }
  /**
   * @ignore
   */
  _notIncludeDataItem(dataItem) {
    super._notIncludeDataItem(dataItem);
    const bullets = dataItem.bullets;
    if (bullets) {
      each(bullets, (bullet) => {
        const sprite = bullet.get("sprite");
        if (sprite) {
          sprite.setPrivate("visible", false);
        }
      });
    }
  }
  /**
   * @ignore
   */
  _unNotIncludeDataItem(dataItem) {
    super._unNotIncludeDataItem(dataItem);
    const bullets = dataItem.bullets;
    if (bullets) {
      each(bullets, (bullet) => {
        const sprite = bullet.get("sprite");
        if (sprite) {
          sprite.setPrivate("visible", true);
        }
      });
    }
  }
};
Object.defineProperty(MapPointSeries, "className", {
  enumerable: true,
  configurable: true,
  writable: true,
  value: "MapPointSeries"
});
Object.defineProperty(MapPointSeries, "classNames", {
  enumerable: true,
  configurable: true,
  writable: true,
  value: MapSeries.classNames.concat([MapPointSeries.className])
});

// node_modules/@amcharts/amcharts5/.internal/charts/map/MapPolygon.js
var import_polylabel = __toESM(require_polylabel());
var MapPolygon = class extends Graphics {
  constructor() {
    super(...arguments);
    Object.defineProperty(this, "_projectionDirty", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: false
    });
    Object.defineProperty(this, "series", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
  }
  _afterNew() {
    super._afterNew();
    this.setPrivate("trustBounds", true);
  }
  _beforeChanged() {
    super._beforeChanged();
    if (this._projectionDirty || this.isDirty("geometry") || this.isDirty("precision")) {
      const geometry = this.get("geometry");
      if (geometry) {
        const series = this.series;
        if (series) {
          const projection2 = series.projection();
          if (projection2) {
            projection2.precision(this.get("precision", 0.5));
          }
          const geoPath = series.geoPath();
          if (geoPath) {
            this._clear = true;
            this.set("draw", (_display) => {
              geoPath.context(this._display);
              geoPath(geometry);
              geoPath.context(null);
            });
            if (this.isHover()) {
              this.showTooltip();
            }
          }
        }
      }
    }
  }
  /**
   * @ignore
   */
  markDirtyProjection() {
    this.markDirty();
    this._projectionDirty = true;
  }
  _clearDirty() {
    super._clearDirty();
    this._projectionDirty = false;
  }
  /**
   * Returns latitude/longitude of the geometrical center of the polygon.
   *
   * @return Center
   */
  geoCentroid() {
    const geometry = this.get("geometry");
    if (geometry) {
      return getGeoCentroid(geometry);
    } else {
      return { latitude: 0, longitude: 0 };
    }
  }
  /**
   * Returns latitude/longitude of the visual center of the polygon.
   *
   * @return Center
   */
  visualCentroid() {
    let biggestArea = 0;
    let coordinates2 = [];
    const geometry = this.get("geometry");
    if (geometry) {
      if (geometry.type == "Polygon") {
        coordinates2 = geometry.coordinates;
      } else if (geometry.type == "MultiPolygon") {
        for (let i = 0; i < geometry.coordinates.length; i++) {
          let coords = geometry.coordinates[i];
          let area = area_default({ type: "Polygon", coordinates: coords });
          if (area > biggestArea) {
            coordinates2 = coords;
            biggestArea = area;
          }
        }
      }
      if (coordinates2) {
        let center = (0, import_polylabel.default)(coordinates2);
        return { longitude: center[0], latitude: center[1] };
      }
    }
    return { longitude: 0, latitude: 0 };
  }
  _getTooltipPoint() {
    const series = this.series;
    if (series) {
      const projection2 = series.projection();
      if (projection2) {
        const geoPoint = this.visualCentroid();
        const xy = projection2([geoPoint.longitude, geoPoint.latitude]);
        if (xy) {
          return { x: xy[0], y: xy[1] };
        }
      }
    }
    return { x: 0, y: 0 };
  }
};
Object.defineProperty(MapPolygon, "className", {
  enumerable: true,
  configurable: true,
  writable: true,
  value: "MapPolygon"
});
Object.defineProperty(MapPolygon, "classNames", {
  enumerable: true,
  configurable: true,
  writable: true,
  value: Graphics.classNames.concat([MapPolygon.className])
});

// node_modules/@amcharts/amcharts5/.internal/charts/map/MapPolygonSeries.js
var MapPolygonSeries = class extends MapSeries {
  constructor() {
    super(...arguments);
    Object.defineProperty(this, "mapPolygons", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: this.addDisposer(new ListTemplate(Template.new({}), () => MapPolygon._new(this._root, {}, [this.mapPolygons.template])))
    });
    Object.defineProperty(this, "_types", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: ["Polygon", "MultiPolygon"]
    });
  }
  /**
   * @ignore
   */
  makeMapPolygon(dataItem) {
    const mapPolygon = this.children.push(this.mapPolygons.make());
    mapPolygon._setDataItem(dataItem);
    this.mapPolygons.push(mapPolygon);
    return mapPolygon;
  }
  /**
   * @ignore
   */
  markDirtyProjection() {
    each(this.dataItems, (dataItem) => {
      let mapPolygon = dataItem.get("mapPolygon");
      if (mapPolygon) {
        mapPolygon.markDirtyProjection();
      }
    });
  }
  _prepareChildren() {
    super._prepareChildren();
    if (this.isDirty("fill")) {
      this.mapPolygons.template.set("fill", this.get("fill"));
    }
    if (this.isDirty("stroke")) {
      this.mapPolygons.template.set("stroke", this.get("stroke"));
    }
  }
  processDataItem(dataItem) {
    super.processDataItem(dataItem);
    let mapPolygon = dataItem.get("mapPolygon");
    if (!mapPolygon) {
      mapPolygon = this.makeMapPolygon(dataItem);
    }
    dataItem.set("mapPolygon", mapPolygon);
    let geometry = dataItem.get("geometry");
    if (geometry) {
      if (this.get("reverseGeodata")) {
        const coordinates2 = geometry.coordinates;
        if (coordinates2) {
          for (let x = 0; x < geometry.coordinates.length; x++) {
            if (geometry.type == "MultiPolygon") {
              for (let y = 0; y < geometry.coordinates[x].length; y++) {
                geometry.coordinates[x][y].reverse();
              }
            } else {
              geometry.coordinates[x].reverse();
            }
          }
        }
      }
      mapPolygon.set("geometry", geometry);
    }
    mapPolygon.series = this;
    this._addGeometry(dataItem.get("geometry"), this);
  }
  /**
   * @ignore
   */
  disposeDataItem(dataItem) {
    super.disposeDataItem(dataItem);
    const mapPolygon = dataItem.get("mapPolygon");
    if (mapPolygon) {
      this.mapPolygons.removeValue(mapPolygon);
      mapPolygon.dispose();
    }
    this._removeGeometry(dataItem.get("geometry"));
  }
  /**
   * @ignore
   */
  _excludeDataItem(dataItem) {
    super._excludeDataItem(dataItem);
    const mapPolygon = dataItem.get("mapPolygon");
    if (mapPolygon) {
      mapPolygon.setPrivate("visible", false);
    }
  }
  /**
   * @ignore
   */
  _unexcludeDataItem(dataItem) {
    super._unexcludeDataItem(dataItem);
    const mapPolygon = dataItem.get("mapPolygon");
    if (mapPolygon) {
      mapPolygon.setPrivate("visible", true);
    }
  }
  /**
   * @ignore
   */
  _notIncludeDataItem(dataItem) {
    super._notIncludeDataItem(dataItem);
    const mapPolygon = dataItem.get("mapPolygon");
    if (mapPolygon) {
      mapPolygon.setPrivate("visible", false);
    }
  }
  /**
   * @ignore
   */
  _unNotIncludeDataItem(dataItem) {
    super._unNotIncludeDataItem(dataItem);
    const mapPolygon = dataItem.get("mapPolygon");
    if (mapPolygon) {
      mapPolygon.setPrivate("visible", true);
    }
  }
  /**
   * Forces a repaint of the element which relies on data.
   *
   * @since 5.0.21
   */
  markDirtyValues(dataItem) {
    super.markDirtyValues();
    if (dataItem) {
      const mapPolygon = dataItem.get("mapPolygon");
      if (mapPolygon) {
        mapPolygon.set("geometry", dataItem.get("geometry"));
      }
    }
  }
  /**
   * Centers and zooms in on the specific polygon.
   *
   * @param  dataItem  Target data item
   * @see {@link https://www.amcharts.com/docs/v5/charts/map-chart/map-pan-zoom/#Zooming_to_clicked_object} for more info
   * @param  rotate If it's true, the map will rotate so that this polygon would be in the center. Mostly usefull with geoOrthographic projection.
   */
  zoomToDataItem(dataItem, rotate) {
    const polygon = dataItem.get("mapPolygon");
    if (polygon) {
      const geometry = polygon.get("geometry");
      const chart = this.chart;
      if (geometry && chart) {
        if (rotate) {
          const centroid = getGeoCentroid(geometry);
          chart.rotate(-centroid.longitude, -centroid.latitude);
          return chart.zoomToGeoBounds(getGeoBounds(geometry), void 0, -centroid.longitude, -centroid.latitude);
        }
        return chart.zoomToGeoBounds(getGeoBounds(geometry));
      }
    }
  }
  /**
   * Zooms the map in so that all polygons in the array are visible.
   *
   * @param   dataItems  An array of data items to zoom to
   * @param   rotate     Rotate the map so it is centered on the selected items
   * @return             Animation
   * @since 5.9.0
   */
  zoomToDataItems(dataItems, rotate) {
    let left;
    let right;
    let top;
    let bottom;
    each(dataItems, (dataItem) => {
      const polygon = dataItem.get("mapPolygon");
      if (polygon) {
        const geometry = polygon.get("geometry");
        if (geometry) {
          let bounds = getGeoBounds(geometry);
          if (left == null) {
            left = bounds.left;
          }
          if (right == null) {
            right = bounds.right;
          }
          if (top == null) {
            top = bounds.top;
          }
          if (bottom == null) {
            bottom = bounds.bottom;
          }
          left = Math.min(bounds.left, left);
          right = Math.max(bounds.right, right);
          top = Math.max(bounds.top, top);
          bottom = Math.min(bounds.bottom, bottom);
        }
      }
    });
    if (left != null && right != null && top != null && bottom != null) {
      const chart = this.chart;
      if (chart) {
        if (rotate) {
          const rx = left + (right - left) / 2;
          const ry = bottom + (top - bottom) / 2;
          chart.rotate(-rx, -ry);
          return chart.zoomToGeoBounds({ left, right, top, bottom }, void 0, -rx, -ry);
        }
        return chart.zoomToGeoBounds({ left, right, top, bottom });
      }
    }
  }
  /**
   * Returns a [[MapPolygon]] that is under specific X/Y point.
   *
   * @since 5.9.8
   * @param   point  X/Y
   * @return         Polygon
   */
  getPolygonByPoint(point) {
    let found;
    const renderer = this._display._renderer;
    const displayObject = renderer.getObjectAtPoint(point);
    if (displayObject) {
      this.mapPolygons.each(function(polygon) {
        if (polygon._display == displayObject) {
          found = polygon;
        }
      });
      return found;
    }
  }
  getPolygonByGeoPoint(point) {
    return this.getPolygonByPoint(this.chart.convert(point));
  }
};
Object.defineProperty(MapPolygonSeries, "className", {
  enumerable: true,
  configurable: true,
  writable: true,
  value: "MapPolygonSeries"
});
Object.defineProperty(MapPolygonSeries, "classNames", {
  enumerable: true,
  configurable: true,
  writable: true,
  value: MapSeries.classNames.concat([MapPolygonSeries.className])
});

// node_modules/d3-hierarchy/src/hierarchy/count.js
function count2(node) {
  var sum2 = 0, children = node.children, i = children && children.length;
  if (!i) sum2 = 1;
  else while (--i >= 0) sum2 += children[i].value;
  node.value = sum2;
}
function count_default() {
  return this.eachAfter(count2);
}

// node_modules/d3-hierarchy/src/hierarchy/each.js
function each_default(callback, that) {
  let index2 = -1;
  for (const node of this) {
    callback.call(that, node, ++index2, this);
  }
  return this;
}

// node_modules/d3-hierarchy/src/hierarchy/eachBefore.js
function eachBefore_default(callback, that) {
  var node = this, nodes = [node], children, i, index2 = -1;
  while (node = nodes.pop()) {
    callback.call(that, node, ++index2, this);
    if (children = node.children) {
      for (i = children.length - 1; i >= 0; --i) {
        nodes.push(children[i]);
      }
    }
  }
  return this;
}

// node_modules/d3-hierarchy/src/hierarchy/eachAfter.js
function eachAfter_default(callback, that) {
  var node = this, nodes = [node], next = [], children, i, n, index2 = -1;
  while (node = nodes.pop()) {
    next.push(node);
    if (children = node.children) {
      for (i = 0, n = children.length; i < n; ++i) {
        nodes.push(children[i]);
      }
    }
  }
  while (node = next.pop()) {
    callback.call(that, node, ++index2, this);
  }
  return this;
}

// node_modules/d3-hierarchy/src/hierarchy/find.js
function find_default(callback, that) {
  let index2 = -1;
  for (const node of this) {
    if (callback.call(that, node, ++index2, this)) {
      return node;
    }
  }
}

// node_modules/d3-hierarchy/src/hierarchy/sum.js
function sum_default(value) {
  return this.eachAfter(function(node) {
    var sum2 = +value(node.data) || 0, children = node.children, i = children && children.length;
    while (--i >= 0) sum2 += children[i].value;
    node.value = sum2;
  });
}

// node_modules/d3-hierarchy/src/hierarchy/sort.js
function sort_default(compare) {
  return this.eachBefore(function(node) {
    if (node.children) {
      node.children.sort(compare);
    }
  });
}

// node_modules/d3-hierarchy/src/hierarchy/path.js
function path_default2(end) {
  var start = this, ancestor = leastCommonAncestor(start, end), nodes = [start];
  while (start !== ancestor) {
    start = start.parent;
    nodes.push(start);
  }
  var k = nodes.length;
  while (end !== ancestor) {
    nodes.splice(k, 0, end);
    end = end.parent;
  }
  return nodes;
}
function leastCommonAncestor(a2, b) {
  if (a2 === b) return a2;
  var aNodes = a2.ancestors(), bNodes = b.ancestors(), c2 = null;
  a2 = aNodes.pop();
  b = bNodes.pop();
  while (a2 === b) {
    c2 = a2;
    a2 = aNodes.pop();
    b = bNodes.pop();
  }
  return c2;
}

// node_modules/d3-hierarchy/src/hierarchy/ancestors.js
function ancestors_default() {
  var node = this, nodes = [node];
  while (node = node.parent) {
    nodes.push(node);
  }
  return nodes;
}

// node_modules/d3-hierarchy/src/hierarchy/descendants.js
function descendants_default() {
  return Array.from(this);
}

// node_modules/d3-hierarchy/src/hierarchy/leaves.js
function leaves_default() {
  var leaves = [];
  this.eachBefore(function(node) {
    if (!node.children) {
      leaves.push(node);
    }
  });
  return leaves;
}

// node_modules/d3-hierarchy/src/hierarchy/links.js
function links_default() {
  var root = this, links = [];
  root.each(function(node) {
    if (node !== root) {
      links.push({ source: node.parent, target: node });
    }
  });
  return links;
}

// node_modules/d3-hierarchy/src/hierarchy/iterator.js
function* iterator_default() {
  var node = this, current, next = [node], children, i, n;
  do {
    current = next.reverse(), next = [];
    while (node = current.pop()) {
      yield node;
      if (children = node.children) {
        for (i = 0, n = children.length; i < n; ++i) {
          next.push(children[i]);
        }
      }
    }
  } while (next.length);
}

// node_modules/d3-hierarchy/src/hierarchy/index.js
function hierarchy(data, children) {
  if (data instanceof Map) {
    data = [void 0, data];
    if (children === void 0) children = mapChildren;
  } else if (children === void 0) {
    children = objectChildren;
  }
  var root = new Node(data), node, nodes = [root], child, childs, i, n;
  while (node = nodes.pop()) {
    if ((childs = children(node.data)) && (n = (childs = Array.from(childs)).length)) {
      node.children = childs;
      for (i = n - 1; i >= 0; --i) {
        nodes.push(child = childs[i] = new Node(childs[i]));
        child.parent = node;
        child.depth = node.depth + 1;
      }
    }
  }
  return root.eachBefore(computeHeight);
}
function node_copy() {
  return hierarchy(this).eachBefore(copyData);
}
function objectChildren(d) {
  return d.children;
}
function mapChildren(d) {
  return Array.isArray(d) ? d[1] : null;
}
function copyData(node) {
  if (node.data.value !== void 0) node.value = node.data.value;
  node.data = node.data.data;
}
function computeHeight(node) {
  var height = 0;
  do
    node.height = height;
  while ((node = node.parent) && node.height < ++height);
}
function Node(data) {
  this.data = data;
  this.depth = this.height = 0;
  this.parent = null;
}
Node.prototype = hierarchy.prototype = {
  constructor: Node,
  count: count_default,
  each: each_default,
  eachAfter: eachAfter_default,
  eachBefore: eachBefore_default,
  find: find_default,
  sum: sum_default,
  sort: sort_default,
  path: path_default2,
  ancestors: ancestors_default,
  descendants: descendants_default,
  leaves: leaves_default,
  links: links_default,
  copy: node_copy,
  [Symbol.iterator]: iterator_default
};

// node_modules/d3-hierarchy/src/accessors.js
function optional(f) {
  return f == null ? null : required(f);
}
function required(f) {
  if (typeof f !== "function") throw new Error();
  return f;
}

// node_modules/d3-hierarchy/src/constant.js
function constantZero() {
  return 0;
}
function constant_default2(x) {
  return function() {
    return x;
  };
}

// node_modules/d3-hierarchy/src/lcg.js
var a = 1664525;
var c = 1013904223;
var m = 4294967296;
function lcg_default() {
  let s = 1;
  return () => (s = (a * s + c) % m) / m;
}

// node_modules/d3-hierarchy/src/array.js
function array_default(x) {
  return typeof x === "object" && "length" in x ? x : Array.from(x);
}
function shuffle(array2, random) {
  let m2 = array2.length, t, i;
  while (m2) {
    i = random() * m2-- | 0;
    t = array2[m2];
    array2[m2] = array2[i];
    array2[i] = t;
  }
  return array2;
}

// node_modules/d3-hierarchy/src/pack/enclose.js
function packEncloseRandom(circles, random) {
  var i = 0, n = (circles = shuffle(Array.from(circles), random)).length, B = [], p, e;
  while (i < n) {
    p = circles[i];
    if (e && enclosesWeak(e, p)) ++i;
    else e = encloseBasis(B = extendBasis(B, p)), i = 0;
  }
  return e;
}
function extendBasis(B, p) {
  var i, j;
  if (enclosesWeakAll(p, B)) return [p];
  for (i = 0; i < B.length; ++i) {
    if (enclosesNot(p, B[i]) && enclosesWeakAll(encloseBasis2(B[i], p), B)) {
      return [B[i], p];
    }
  }
  for (i = 0; i < B.length - 1; ++i) {
    for (j = i + 1; j < B.length; ++j) {
      if (enclosesNot(encloseBasis2(B[i], B[j]), p) && enclosesNot(encloseBasis2(B[i], p), B[j]) && enclosesNot(encloseBasis2(B[j], p), B[i]) && enclosesWeakAll(encloseBasis3(B[i], B[j], p), B)) {
        return [B[i], B[j], p];
      }
    }
  }
  throw new Error();
}
function enclosesNot(a2, b) {
  var dr = a2.r - b.r, dx = b.x - a2.x, dy = b.y - a2.y;
  return dr < 0 || dr * dr < dx * dx + dy * dy;
}
function enclosesWeak(a2, b) {
  var dr = a2.r - b.r + Math.max(a2.r, b.r, 1) * 1e-9, dx = b.x - a2.x, dy = b.y - a2.y;
  return dr > 0 && dr * dr > dx * dx + dy * dy;
}
function enclosesWeakAll(a2, B) {
  for (var i = 0; i < B.length; ++i) {
    if (!enclosesWeak(a2, B[i])) {
      return false;
    }
  }
  return true;
}
function encloseBasis(B) {
  switch (B.length) {
    case 1:
      return encloseBasis1(B[0]);
    case 2:
      return encloseBasis2(B[0], B[1]);
    case 3:
      return encloseBasis3(B[0], B[1], B[2]);
  }
}
function encloseBasis1(a2) {
  return {
    x: a2.x,
    y: a2.y,
    r: a2.r
  };
}
function encloseBasis2(a2, b) {
  var x12 = a2.x, y12 = a2.y, r1 = a2.r, x2 = b.x, y2 = b.y, r2 = b.r, x21 = x2 - x12, y21 = y2 - y12, r21 = r2 - r1, l = Math.sqrt(x21 * x21 + y21 * y21);
  return {
    x: (x12 + x2 + x21 / l * r21) / 2,
    y: (y12 + y2 + y21 / l * r21) / 2,
    r: (l + r1 + r2) / 2
  };
}
function encloseBasis3(a2, b, c2) {
  var x12 = a2.x, y12 = a2.y, r1 = a2.r, x2 = b.x, y2 = b.y, r2 = b.r, x3 = c2.x, y3 = c2.y, r3 = c2.r, a22 = x12 - x2, a3 = x12 - x3, b2 = y12 - y2, b3 = y12 - y3, c22 = r2 - r1, c3 = r3 - r1, d1 = x12 * x12 + y12 * y12 - r1 * r1, d2 = d1 - x2 * x2 - y2 * y2 + r2 * r2, d3 = d1 - x3 * x3 - y3 * y3 + r3 * r3, ab = a3 * b2 - a22 * b3, xa = (b2 * d3 - b3 * d2) / (ab * 2) - x12, xb = (b3 * c22 - b2 * c3) / ab, ya = (a3 * d2 - a22 * d3) / (ab * 2) - y12, yb = (a22 * c3 - a3 * c22) / ab, A = xb * xb + yb * yb - 1, B = 2 * (r1 + xa * xb + ya * yb), C = xa * xa + ya * ya - r1 * r1, r = -(Math.abs(A) > 1e-6 ? (B + Math.sqrt(B * B - 4 * A * C)) / (2 * A) : C / B);
  return {
    x: x12 + xa + xb * r,
    y: y12 + ya + yb * r,
    r
  };
}

// node_modules/d3-hierarchy/src/pack/siblings.js
function place(b, a2, c2) {
  var dx = b.x - a2.x, x, a22, dy = b.y - a2.y, y, b2, d2 = dx * dx + dy * dy;
  if (d2) {
    a22 = a2.r + c2.r, a22 *= a22;
    b2 = b.r + c2.r, b2 *= b2;
    if (a22 > b2) {
      x = (d2 + b2 - a22) / (2 * d2);
      y = Math.sqrt(Math.max(0, b2 / d2 - x * x));
      c2.x = b.x - x * dx - y * dy;
      c2.y = b.y - x * dy + y * dx;
    } else {
      x = (d2 + a22 - b2) / (2 * d2);
      y = Math.sqrt(Math.max(0, a22 / d2 - x * x));
      c2.x = a2.x + x * dx - y * dy;
      c2.y = a2.y + x * dy + y * dx;
    }
  } else {
    c2.x = a2.x + c2.r;
    c2.y = a2.y;
  }
}
function intersects(a2, b) {
  var dr = a2.r + b.r - 1e-6, dx = b.x - a2.x, dy = b.y - a2.y;
  return dr > 0 && dr * dr > dx * dx + dy * dy;
}
function score(node) {
  var a2 = node._, b = node.next._, ab = a2.r + b.r, dx = (a2.x * b.r + b.x * a2.r) / ab, dy = (a2.y * b.r + b.y * a2.r) / ab;
  return dx * dx + dy * dy;
}
function Node2(circle) {
  this._ = circle;
  this.next = null;
  this.previous = null;
}
function packSiblingsRandom(circles, random) {
  if (!(n = (circles = array_default(circles)).length)) return 0;
  var a2, b, c2, n, aa, ca, i, j, k, sj, sk;
  a2 = circles[0], a2.x = 0, a2.y = 0;
  if (!(n > 1)) return a2.r;
  b = circles[1], a2.x = -b.r, b.x = a2.r, b.y = 0;
  if (!(n > 2)) return a2.r + b.r;
  place(b, a2, c2 = circles[2]);
  a2 = new Node2(a2), b = new Node2(b), c2 = new Node2(c2);
  a2.next = c2.previous = b;
  b.next = a2.previous = c2;
  c2.next = b.previous = a2;
  pack: for (i = 3; i < n; ++i) {
    place(a2._, b._, c2 = circles[i]), c2 = new Node2(c2);
    j = b.next, k = a2.previous, sj = b._.r, sk = a2._.r;
    do {
      if (sj <= sk) {
        if (intersects(j._, c2._)) {
          b = j, a2.next = b, b.previous = a2, --i;
          continue pack;
        }
        sj += j._.r, j = j.next;
      } else {
        if (intersects(k._, c2._)) {
          a2 = k, a2.next = b, b.previous = a2, --i;
          continue pack;
        }
        sk += k._.r, k = k.previous;
      }
    } while (j !== k.next);
    c2.previous = a2, c2.next = b, a2.next = b.previous = b = c2;
    aa = score(a2);
    while ((c2 = c2.next) !== b) {
      if ((ca = score(c2)) < aa) {
        a2 = c2, aa = ca;
      }
    }
    b = a2.next;
  }
  a2 = [b._], c2 = b;
  while ((c2 = c2.next) !== b) a2.push(c2._);
  c2 = packEncloseRandom(a2, random);
  for (i = 0; i < n; ++i) a2 = circles[i], a2.x -= c2.x, a2.y -= c2.y;
  return c2.r;
}

// node_modules/d3-hierarchy/src/pack/index.js
function defaultRadius(d) {
  return Math.sqrt(d.value);
}
function pack_default() {
  var radius = null, dx = 1, dy = 1, padding = constantZero;
  function pack(root) {
    const random = lcg_default();
    root.x = dx / 2, root.y = dy / 2;
    if (radius) {
      root.eachBefore(radiusLeaf(radius)).eachAfter(packChildrenRandom(padding, 0.5, random)).eachBefore(translateChild(1));
    } else {
      root.eachBefore(radiusLeaf(defaultRadius)).eachAfter(packChildrenRandom(constantZero, 1, random)).eachAfter(packChildrenRandom(padding, root.r / Math.min(dx, dy), random)).eachBefore(translateChild(Math.min(dx, dy) / (2 * root.r)));
    }
    return root;
  }
  pack.radius = function(x) {
    return arguments.length ? (radius = optional(x), pack) : radius;
  };
  pack.size = function(x) {
    return arguments.length ? (dx = +x[0], dy = +x[1], pack) : [dx, dy];
  };
  pack.padding = function(x) {
    return arguments.length ? (padding = typeof x === "function" ? x : constant_default2(+x), pack) : padding;
  };
  return pack;
}
function radiusLeaf(radius) {
  return function(node) {
    if (!node.children) {
      node.r = Math.max(0, +radius(node) || 0);
    }
  };
}
function packChildrenRandom(padding, k, random) {
  return function(node) {
    if (children = node.children) {
      var children, i, n = children.length, r = padding(node) * k || 0, e;
      if (r) for (i = 0; i < n; ++i) children[i].r += r;
      e = packSiblingsRandom(children, random);
      if (r) for (i = 0; i < n; ++i) children[i].r -= r;
      node.r = e + r;
    }
  };
}
function translateChild(k) {
  return function(node) {
    var parent = node.parent;
    node.r *= k;
    if (parent) {
      node.x = parent.x + k * node.x;
      node.y = parent.y + k * node.y;
    }
  };
}

// node_modules/d3-hierarchy/src/treemap/dice.js
function dice_default(parent, x06, y06, x12, y12) {
  var nodes = parent.children, node, i = -1, n = nodes.length, k = parent.value && (x12 - x06) / parent.value;
  while (++i < n) {
    node = nodes[i], node.y0 = y06, node.y1 = y12;
    node.x0 = x06, node.x1 = x06 += node.value * k;
  }
}

// node_modules/d3-hierarchy/src/tree.js
function TreeNode(node, i) {
  this._ = node;
  this.parent = null;
  this.children = null;
  this.A = null;
  this.a = this;
  this.z = 0;
  this.m = 0;
  this.c = 0;
  this.s = 0;
  this.t = null;
  this.i = i;
}
TreeNode.prototype = Object.create(Node.prototype);

// node_modules/d3-hierarchy/src/treemap/slice.js
function slice_default(parent, x06, y06, x12, y12) {
  var nodes = parent.children, node, i = -1, n = nodes.length, k = parent.value && (y12 - y06) / parent.value;
  while (++i < n) {
    node = nodes[i], node.x0 = x06, node.x1 = x12;
    node.y0 = y06, node.y1 = y06 += node.value * k;
  }
}

// node_modules/d3-hierarchy/src/treemap/squarify.js
var phi = (1 + Math.sqrt(5)) / 2;
function squarifyRatio(ratio, parent, x06, y06, x12, y12) {
  var rows = [], nodes = parent.children, row, nodeValue, i0 = 0, i1 = 0, n = nodes.length, dx, dy, value = parent.value, sumValue, minValue, maxValue, newRatio, minRatio, alpha, beta;
  while (i0 < n) {
    dx = x12 - x06, dy = y12 - y06;
    do
      sumValue = nodes[i1++].value;
    while (!sumValue && i1 < n);
    minValue = maxValue = sumValue;
    alpha = Math.max(dy / dx, dx / dy) / (value * ratio);
    beta = sumValue * sumValue * alpha;
    minRatio = Math.max(maxValue / beta, beta / minValue);
    for (; i1 < n; ++i1) {
      sumValue += nodeValue = nodes[i1].value;
      if (nodeValue < minValue) minValue = nodeValue;
      if (nodeValue > maxValue) maxValue = nodeValue;
      beta = sumValue * sumValue * alpha;
      newRatio = Math.max(maxValue / beta, beta / minValue);
      if (newRatio > minRatio) {
        sumValue -= nodeValue;
        break;
      }
      minRatio = newRatio;
    }
    rows.push(row = { value: sumValue, dice: dx < dy, children: nodes.slice(i0, i1) });
    if (row.dice) dice_default(row, x06, y06, x12, value ? y06 += dy * sumValue / value : y12);
    else slice_default(row, x06, y06, value ? x06 += dx * sumValue / value : x12, y12);
    value -= sumValue, i0 = i1;
  }
  return rows;
}
var squarify_default = function custom(ratio) {
  function squarify(parent, x06, y06, x12, y12) {
    squarifyRatio(ratio, parent, x06, y06, x12, y12);
  }
  squarify.ratio = function(x) {
    return custom((x = +x) > 1 ? x : 1);
  };
  return squarify;
}(phi);

// node_modules/d3-hierarchy/src/treemap/resquarify.js
var resquarify_default = function custom2(ratio) {
  function resquarify(parent, x06, y06, x12, y12) {
    if ((rows = parent._squarify) && rows.ratio === ratio) {
      var rows, row, nodes, i, j = -1, n, m2 = rows.length, value = parent.value;
      while (++j < m2) {
        row = rows[j], nodes = row.children;
        for (i = row.value = 0, n = nodes.length; i < n; ++i) row.value += nodes[i].value;
        if (row.dice) dice_default(row, x06, y06, x12, value ? y06 += (y12 - y06) * row.value / value : y12);
        else slice_default(row, x06, y06, value ? x06 += (x12 - x06) * row.value / value : x12, y12);
        value -= row.value;
      }
    } else {
      parent._squarify = rows = squarifyRatio(ratio, parent, x06, y06, x12, y12);
      rows.ratio = ratio;
    }
  }
  resquarify.ratio = function(x) {
    return custom2((x = +x) > 1 ? x : 1);
  };
  return resquarify;
}(phi);

// node_modules/@amcharts/amcharts5/.internal/charts/map/ClusteredPointSeries.js
var ClusteredPointSeries = class extends MapPointSeries {
  constructor() {
    super(...arguments);
    Object.defineProperty(this, "_dataItem", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: this.makeDataItem({})
    });
    Object.defineProperty(this, "_clusterIndex", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 0
    });
    Object.defineProperty(this, "_clusters", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: []
    });
    Object.defineProperty(this, "clusteredDataItems", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: []
    });
    Object.defineProperty(this, "_scatterIndex", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 0
    });
    Object.defineProperty(this, "_scatters", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: []
    });
    Object.defineProperty(this, "_packLayout", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: pack_default()
    });
    Object.defineProperty(this, "_spiral", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: []
    });
    Object.defineProperty(this, "_clusterDP", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: void 0
    });
    Object.defineProperty(this, "_previousZL", {
      enumerable: true,
      configurable: true,
      writable: true,
      value: 0
    });
  }
  _afterNew() {
    this.fields.push("groupId");
    this._setRawDefault("groupIdField", "groupId");
    super._afterNew();
  }
  _afterDataChange() {
    super._afterDataChange();
    this._previousZL = 0;
  }
  _updateChildren() {
    super._updateChildren();
    if (this.isDirty("scatterRadius")) {
      this._spiral = spiralPoints(0, 0, 300, 300, 0, 3, 3, 0, 0);
    }
    const chart = this.chart;
    if (chart) {
      const zoomLevel = chart.get("zoomLevel", 1);
      if (zoomLevel != this._previousZL) {
        const clusterDelay = this.get("clusterDelay", 0);
        if (clusterDelay) {
          if (this._clusterDP) {
            this._clusterDP.dispose();
            this._clusterDP = this.setTimeout(() => {
              this._doTheCluster();
            }, clusterDelay);
          } else {
            this._doTheCluster();
            this._clusterDP = this.setTimeout(() => {
            }, 0);
          }
        } else {
          this._doTheCluster();
        }
        this._previousZL = zoomLevel;
      }
      each(this.clusteredDataItems, (dataItem) => {
        const bullet = dataItem.get("bullet");
        const longitude2 = dataItem.get("longitude", 0);
        const latitude = dataItem.get("latitude", 0);
        this._positionBulletReal(bullet, { type: "Point", coordinates: [longitude2, latitude] }, [longitude2, latitude]);
      });
    }
  }
  _doTheCluster() {
    const groups2 = {};
    each(this.dataItems, (dataItem) => {
      const groupId = dataItem.get("groupId", "_default");
      if (!groups2[groupId]) {
        groups2[groupId] = [];
      }
      groups2[groupId].push(dataItem);
    });
    this._scatterIndex = -1;
    this._scatters = [];
    this._clusterIndex = -1;
    this._clusters = [];
    each(this.clusteredDataItems, (dataItem) => {
      dataItem.setRaw("children", void 0);
    });
    each(this.dataItems, (dataItem) => {
      dataItem.setRaw("cluster", void 0);
    });
    each2(groups2, (_key, group2) => {
      this._scatterGroup(group2);
    });
    each2(groups2, (_key, group2) => {
      this._clusterGroup(group2);
    });
    each(this.dataItems, (dataItem) => {
      if (!dataItem.get("cluster")) {
        const bullets = dataItem.bullets;
        if (bullets) {
          each(bullets, (bullet) => {
            const sprite = bullet.get("sprite");
            if (sprite) {
              sprite.set("forceHidden", false);
            }
          });
        }
      }
    });
  }
  /**
   * Zooms to the area so that all clustered data items of a cluster would be
   * visible.
   *
   * Pass in `true` as a second parameter to rotate that map so that the group
   * is in the center. This is especially useful in the maps that use
   * Orthographic (globe) projection.
   *
   * @param  dataItem  Group data item
   * @param  rotate    Rotate the map so that group is in the center?
   * @see {@link https://www.amcharts.com/docs/v5/charts/map-chart/clustered-point-series/#Drill_down} for more info
   */
  zoomToCluster(dataItem, rotate) {
    this.zoomToDataItems(dataItem.get("children", []), rotate);
  }
  _clusterGroup(dataItems) {
    const chart = this.chart;
    if (chart && chart.get("zoomLevel", 1) >= chart.get("maxZoomLevel", 100) * this.get("stopClusterZoom", 0.95)) {
    } else {
      dataItems.sort((a2, b) => {
        const pointA = a2.get("point");
        const pointB = b.get("point");
        if (pointA && pointB) {
          return Math.hypot(pointA.x - pointB.x, pointA.y - pointB.y);
        }
        return 0;
      });
      while (dataItems.length > 0) {
        this._clusterIndex++;
        this._clusters[this._clusterIndex] = [];
        const cluster = this._clusters[this._clusterIndex];
        const dataItem = dataItems[0];
        cluster.push(dataItem);
        removeFirst(dataItems, dataItem);
        this._clusterDataItem(dataItem, dataItems);
      }
    }
    let i = 0;
    const bulletMethod = this.get("clusteredBullet");
    if (bulletMethod) {
      each(this._clusters, (cluster) => {
        let sumX = 0;
        let sumY = 0;
        let len = cluster.length;
        if (len > 1) {
          let clusteredDataItem = this.clusteredDataItems[i];
          if (!clusteredDataItem) {
            clusteredDataItem = new DataItem(this, void 0, {});
            const bullet2 = clusteredDataItem.set("bullet", bulletMethod(this._root, this, clusteredDataItem));
            if (bullet2) {
              const sprite = bullet2.get("sprite");
              if (sprite) {
                this.bulletsContainer.children.push(sprite);
                sprite._setDataItem(clusteredDataItem);
                this.root.events.once("frameended", () => {
                  if (sprite instanceof Container) {
                    sprite.walkChildren((child) => {
                      if (child instanceof Component) {
                        child.markDirtyValues();
                      }
                    });
                  }
                });
              }
            }
            this.clusteredDataItems.push(clusteredDataItem);
          }
          let groupId;
          each(cluster, (dataItem) => {
            dataItem.setRaw("cluster", clusteredDataItem);
            const point = dataItem.get("point");
            if (point) {
              sumX += point.x;
              sumY += point.y;
            }
            const bullets = dataItem.bullets;
            if (bullets) {
              each(bullets, (bullet2) => {
                const sprite = bullet2.get("sprite");
                if (sprite) {
                  sprite.set("forceHidden", true);
                }
              });
            }
            groupId = dataItem.get("groupId");
          });
          let averageX = sumX / len;
          let averageY = sumY / len;
          clusteredDataItem.setRaw("children", cluster);
          clusteredDataItem.setRaw("groupId", groupId);
          const prevLen = clusteredDataItem.get("value");
          clusteredDataItem.setRaw("value", len);
          const bullet = clusteredDataItem.get("bullet");
          if (bullet) {
            let geoPoint = this.chart.invert({ x: averageX, y: averageY });
            if (geoPoint) {
              clusteredDataItem.setAll({
                longitude: geoPoint.longitude,
                latitude: geoPoint.latitude
              });
            }
            this._positionBullets(clusteredDataItem);
            const sprite = bullet.get("sprite");
            if (sprite) {
              sprite.set("forceHidden", false);
              if (prevLen != len) {
                if (sprite instanceof Container) {
                  sprite.walkChildren((child) => {
                    if (child instanceof Label) {
                      child.text.markDirtyText();
                    }
                  });
                }
              }
            }
          }
          i++;
        }
      });
    }
    each(this.clusteredDataItems, (dataItem) => {
      let children = dataItem.get("children");
      if (!children || children.length == 0) {
        const bullet = dataItem.get("bullet");
        if (bullet) {
          const sprite = bullet.get("sprite");
          if (sprite) {
            sprite.set("forceHidden", true);
          }
        }
      }
    });
  }
  _onDataClear() {
    super._onDataClear();
    each(this.clusteredDataItems, (dataItem) => {
      const bullet = dataItem.get("bullet");
      if (bullet) {
        const sprite = bullet.get("sprite");
        if (sprite) {
          sprite.dispose();
        }
      }
    });
    this.clusteredDataItems = [];
  }
  _clusterDataItem(dataItem, dataItems) {
    const point = dataItem.get("point");
    if (point) {
      let minDistance = this.get("minDistance", 20);
      const cluster = this._clusters[this._clusterIndex];
      for (let i = dataItems.length - 1; i >= 0; i--) {
        const di = dataItems[i];
        if (di && !di.get("clipped")) {
          const diPoint = di.get("point");
          if (diPoint) {
            if (Math.hypot(diPoint.x - point.x, diPoint.y - point.y) < minDistance) {
              cluster.push(di);
              removeFirst(dataItems, di);
              this._clusterDataItem(di, dataItems);
            }
          }
        }
      }
    }
  }
  _scatterGroup(dataItems) {
    const chart = this.chart;
    if (chart && chart.get("zoomLevel", 1) >= chart.get("maxZoomLevel", 100) * this.get("stopClusterZoom", 0.95)) {
      while (dataItems.length > 0) {
        this._scatterIndex++;
        this._scatters[this._scatterIndex] = [];
        const scatter = this._scatters[this._scatterIndex];
        const dataItem = dataItems[0];
        scatter.push(dataItem);
        remove(dataItems, dataItem);
        this._scatterDataItem(dataItem, dataItems);
      }
      each(this._scatters, (scatter) => {
        let len = scatter.length;
        if (len > 1) {
          let previousCircles = [];
          let s = 0;
          let radius = this.get("scatterRadius", 8);
          each(scatter, (dataItem) => {
            let spiralPoint = this._spiral[s];
            let intersects2 = true;
            if (previousCircles.length > 0) {
              while (intersects2) {
                each(previousCircles, (previousCircle) => {
                  intersects2 = false;
                  while (circlesOverlap({ x: spiralPoint.x, y: spiralPoint.y, radius }, previousCircle)) {
                    s++;
                    if (this._spiral[s] == void 0) {
                      intersects2 = false;
                    } else {
                      intersects2 = true;
                      spiralPoint = this._spiral[s];
                    }
                  }
                });
              }
            }
            const dx = spiralPoint.x;
            const dy = spiralPoint.y;
            previousCircles.push({ x: dx, y: dy, radius });
            dataItem.set("dx", dx);
            dataItem.set("dy", dy);
            const bullets = dataItem.bullets;
            if (bullets) {
              each(bullets, (bullet) => {
                const sprite = bullet.get("sprite");
                if (sprite) {
                  sprite.setAll({ dx, dy });
                }
              });
            }
          });
        }
      });
    }
  }
  _scatterDataItem(dataItem, dataItems) {
    const point = dataItem.get("point");
    if (point) {
      const scatterDistance = this.get("scatterDistance", 5);
      const scatter = this._scatters[this._scatterIndex];
      each(dataItems, (di) => {
        if (di && !di.get("clipped")) {
          const diPoint = di.get("point");
          if (diPoint) {
            if (Math.hypot(diPoint.x - point.x, diPoint.y - point.y) < scatterDistance) {
              scatter.push(di);
              removeFirst(dataItems, di);
              this._scatterDataItem(di, dataItems);
            }
          }
        }
      });
    }
  }
};
Object.defineProperty(ClusteredPointSeries, "className", {
  enumerable: true,
  configurable: true,
  writable: true,
  value: "ClusteredPointSeries"
});
Object.defineProperty(ClusteredPointSeries, "classNames", {
  enumerable: true,
  configurable: true,
  writable: true,
  value: MapPointSeries.classNames.concat([ClusteredPointSeries.className])
});

// node_modules/@amcharts/amcharts5/.internal/charts/map/ZoomControl.js
var ZoomControl = class extends ZoomTools {
  _afterNew() {
    super._afterNew();
    this.addTag("zoomtools");
  }
  _prepareChildren() {
    super._prepareChildren();
    if (this.isPrivateDirty("chart")) {
      this.set("target", this.getPrivate("chart"));
    }
  }
};
Object.defineProperty(ZoomControl, "className", {
  enumerable: true,
  configurable: true,
  writable: true,
  value: "ZoomControl"
});
Object.defineProperty(ZoomControl, "classNames", {
  enumerable: true,
  configurable: true,
  writable: true,
  value: ZoomTools.classNames.concat([ZoomControl.className])
});
export {
  ClusteredPointSeries,
  MapChartDefaultTheme as DefaultTheme,
  GraticuleSeries,
  MapChart,
  MapLine,
  MapLineSeries,
  MapPointSeries,
  MapPolygon,
  MapPolygonSeries,
  MapSeries,
  ZoomControl,
  albersUsa_default as geoAlbersUsa,
  equalEarth_default as geoEqualEarth,
  equirectangular_default as geoEquirectangular,
  mercator_default as geoMercator,
  naturalEarth1_default as geoNaturalEarth1,
  orthographic_default as geoOrthographic,
  getGeoArea,
  getGeoBounds,
  getGeoCentroid,
  getGeoCircle,
  getGeoRectangle,
  normalizeGeoPoint
};
//# sourceMappingURL=@amcharts_amcharts5_map.js.map
