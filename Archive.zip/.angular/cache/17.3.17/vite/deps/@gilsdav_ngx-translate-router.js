import {
  ALWAYS_SET_PREFIX,
  CACHE_MECHANISM,
  CACHE_NAME,
  COOKIE_FORMAT,
  CacheMechanism,
  DEFAULT_LANG_FUNCTION,
  DummyLocalizeParser,
  GilsdavReuseStrategy,
  INITIAL_NAVIGATION,
  LOCALIZE_ROUTER_FORROOT_GUARD,
  LocalizeNgModuleFactory,
  LocalizeParser,
  LocalizeRouterModule,
  LocalizeRouterPipe,
  LocalizeRouterService,
  LocalizeRouterSettings,
  LocalizedRouter,
  ManualParserLoader,
  ParserInitializer,
  RAW_ROUTES,
  USE_CACHED_LANG,
  getAppInitializer,
  provideForRootGuard,
  standardizeConfig,
  translateModule,
  withLocalizeRouter,
  wrapIntoObservable
} from "./chunk-NJHX4NLE.js";
import "./chunk-B2NWSZPO.js";
import "./chunk-V4VXQCYH.js";
import "./chunk-6L3DKKWU.js";
import "./chunk-QFNOSN6A.js";
import "./chunk-26O3BCNQ.js";
import "./chunk-5BURAC2Z.js";
import "./chunk-EC6BZIDR.js";
import "./chunk-W5SOQY2G.js";
import "./chunk-CJ77FWBK.js";
import "./chunk-ZA2DQWUL.js";
import "./chunk-KZQQXEH6.js";
export {
  ALWAYS_SET_PREFIX,
  CACHE_MECHANISM,
  CACHE_NAME,
  COOKIE_FORMAT,
  CacheMechanism,
  DEFAULT_LANG_FUNCTION,
  DummyLocalizeParser,
  GilsdavReuseStrategy,
  INITIAL_NAVIGATION,
  LOCALIZE_ROUTER_FORROOT_GUARD,
  LocalizeNgModuleFactory,
  LocalizeParser,
  LocalizeRouterModule,
  LocalizeRouterPipe,
  LocalizeRouterService,
  LocalizeRouterSettings,
  LocalizedRouter,
  ManualParserLoader,
  ParserInitializer,
  RAW_ROUTES,
  USE_CACHED_LANG,
  getAppInitializer,
  provideForRootGuard,
  standardizeConfig,
  translateModule,
  withLocalizeRouter,
  wrapIntoObservable
};
//# sourceMappingURL=@gilsdav_ngx-translate-router.js.map
