import {
  LocalizeParser
} from "./chunk-NJHX4NLE.js";
import "./chunk-B2NWSZPO.js";
import "./chunk-V4VXQCYH.js";
import "./chunk-6L3DKKWU.js";
import "./chunk-QFNOSN6A.js";
import "./chunk-26O3BCNQ.js";
import "./chunk-5BURAC2Z.js";
import "./chunk-EC6BZIDR.js";
import "./chunk-W5SOQY2G.js";
import "./chunk-CJ77FWBK.js";
import "./chunk-ZA2DQWUL.js";
import "./chunk-KZQQXEH6.js";

// node_modules/@gilsdav/ngx-translate-router-http-loader/fesm2020/gilsdav-ngx-translate-router-http-loader.mjs
var LocalizeRouterHttpLoader = class extends LocalizeParser {
  /**
   * CTOR
   * @param translate
   * @param location
   * @param settings
   * @param http
   * @param path
   */
  constructor(translate, location, settings, http, path = "assets/locales.json") {
    super(translate, location, settings);
    this.http = http;
    this.path = path;
  }
  /**
   * Initialize or append routes
   * @param routes
   */
  load(routes) {
    return new Promise((resolve) => {
      this.http.get(`${this.path}`).subscribe((data) => {
        this.locales = data.locales;
        this.prefix = data.prefix || "";
        this.escapePrefix = data.escapePrefix || "";
        this.init(routes).then(resolve);
      });
    });
  }
};
export {
  LocalizeRouterHttpLoader
};
//# sourceMappingURL=@gilsdav_ngx-translate-router-http-loader.js.map
