export interface Social {
    id: number;
    name: string;
    link: string;
}