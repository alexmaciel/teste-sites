export class Paging {
    search_string: string = '';
    post_id?: number;
    category_id?: number;
}