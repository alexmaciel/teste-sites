export interface Email {
    clientFirstName: string;
    clientLastName: string;
    clientEmail: string;
    clientPhone: string;
    clientAddress?: string;
    clientMessage?: string;
    clientInvestment?: string;
    projects?: string;
}