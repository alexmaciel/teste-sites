export interface Language {
    languageid: number;
    language_cod: string;
    language: string;
    name: string;
    flag: string;
    active: number;
}