export interface Goals {
    id: number;
    name: string;
    description: string;
    order: number;
    language?: string;
}