import { NgModule } from '@angular/core';
import { JsonLdService } from './json-ld.service';

@NgModule({
  providers: [
    JsonLdService,
  ],
})
export class JsonLdModule { }