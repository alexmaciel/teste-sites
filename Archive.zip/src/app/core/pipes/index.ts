export { TruncatetextPipe } from './truncatetext.pipe';
export { DateLocalePipe } from './date-locale.pipe';
export { SafePipe } from './safe.pipe';