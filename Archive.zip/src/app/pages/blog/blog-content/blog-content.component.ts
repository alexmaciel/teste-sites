import { Component } from '@angular/core';

@Component({
  selector: 'app-blog-content',
  templateUrl: './blog-content.component.html'
})
export class BlogContentComponent {

}
