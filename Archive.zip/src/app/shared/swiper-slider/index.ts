export * from './swiper.component';
export * from './swiper.module';