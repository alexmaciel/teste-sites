export const environment = {
    production: true,
    appVersion: '0.0.1',
    apiUrl: 'https://metabixbiotech.com/api',  
    cookieDomain: 'metabixbiotech.com'     
};