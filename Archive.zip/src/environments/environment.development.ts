export const environment = {
    production: false,
    appVersion: '0.0.1',
    apiUrl: 'http://localhost/metabix/api',
    cookieDomain: 'localhost'      
};

